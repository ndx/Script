/*
 * Copyright (C) Niklaus F.Schen.
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<assert.h>
#include"ncpl_lex.h"
#include"ncpl_tool.h"

static int ncpl_fix_type(int type1, int type2);

int ncpl_calc_type_result(int type1, int type2)
{
    if( type1==type2 ) return type1;
    if( ncpl_isfile(type1) && ncpl_isfile(type2) ) return FFILE;
    if( ncpl_isinteger(type1) && ncpl_isfloat(type2) ) return FLOAT;
    if( ncpl_isfloat(type1) && ncpl_isinteger(type2) ) return FLOAT;
    if( ncpl_ischar(type1) && ncpl_ischar(type2) ) return CHAR;
    if( ncpl_isstring(type1) && ncpl_isstring(type2) ) return STR;
    if( ncpl_isinteger(type1) && ncpl_isinteger(type2) ) return ncpl_fix_type(type1, type2);
    return -1;
}

int ncpl_type_legal(int left, int right)
{
    if( left==right ) return left;
    if( ncpl_isfile(left) && ncpl_isfile(right) ) return FFILE;
    if( ncpl_ischar(left) && ncpl_ischar(right) ) return CHAR;
    if( ncpl_isstring(left) && ncpl_isstring(right) ) return STR;
    if( ncpl_isnumeral(left) && ncpl_isnumeral(right) ) return left;
    return -1;
}

static int ncpl_fix_type(int type1, int type2)
{
    if( type1==INUM && type2==INUM ) return LONG;
    else {
        if( type1==LONG || type2==LONG ) return LONG;
        else if( type1==INT || type2==INT ) return INT;
        else if( type1==SHORT || type2==SHORT ) return SHORT;
        else return CHAR;
    }
    assert(0);
}

int ncpl_isnumeral(int type)
{
    if( type==INUM || type==FNUM || \
        type==INT || type==SHORT || \
        type==LONG || type==FLOAT || \
        type==CHAR )
        return 1;
    return 0;
}

int ncpl_isinteger(int type)
{
    if( type==INUM || type==INT || \
        type==SHORT || type==LONG || \
        type==CHAR )
        return 1;
    return 0;
}

int ncpl_issint1(int type)
{
    if( type==INUM || type==INT || \
        type==SHORT || type==CHAR)
        return 1;
    return 0;
}

int ncpl_issint2(int type)
{
    if( type==INUM || type==SHORT || \
        type==CHAR )
        return 1;
    return 0;
}

int ncpl_issint3(int type)
{
    if( type==INUM || type==CHAR )
        return 1;
    return 0;
}

int ncpl_islint1(int type)
{
    if( type==INUM || type==INT || \
        type==SHORT || type==LONG )
        return 1;
    return 0;
}

int ncpl_islint2(int type)
{
    if( type==INUM || type==INT || \
        type==LONG)
        return 1;
    return 0;
}

int ncpl_islint3(int type)
{
    if( type==INUM || type==LONG ) return 1;
    return 0;
}

int ncpl_isstring(int type)
{
    if( type==STR || type==STRING || type==NUL )
        return 1;
    return 0;
}

int ncpl_ischar(int type)
{
    if( type==CHAR || type==CHARAC )
        return 1;
    return 0;
}

int ncpl_isfloat(int type)
{
    if( type==FLOAT ) return 1;
    return 0;
}

int ncpl_isfile(int type)
{
    if( type==FFILE || type==FERR ) return 1;
    return 0;
}

int ncpl_isshort(int type)
{
    if( type==INUM || type==SHORT ) return 1;
    return 0;
}

int ncpl_islong(int type)
{
    if( type==INUM || type==LONG ) return 1;
    return 0;
}

int ncpl_isint(int type)
{
    if( type==INUM || type==INT ) return 1;
    return 0;
}

