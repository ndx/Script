/*
 * Copyright (C) Niklaus F.Schen.
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<assert.h>
#include<errno.h>
#include<unistd.h>
#include"ncpl_parser.h"
#include"ncpl_tool.h"

static unsigned int ncpl_calc_real_nr_param(NCPL_exp *ex);
static int ncpl_check_function_type(NCPL_ENV *env, \
NCPL_exp *ex, char *func_name, int is_restrict);
static void ncpl_push_query(NCPL_PARSER *p);
static void ncpl_push_fopen(NCPL_PARSER *p);
static void ncpl_push_fclose(NCPL_PARSER *p);
static void ncpl_push_print(NCPL_PARSER *p);
static void ncpl_init_new_var(NCPL_PARSER *p, NCPL_VALUE *val, int type);
static int ncpl_check_strfmt(NCPL_PARSER *p, NCPL_exp *ex);
static int ncpl_copy_strfmt(NCPL_PARSER *p, NCPL_exp *ex, char *buf);

char query_str[] = "query";
char fopen_str[] = "fopen";
char fclose_str[] = "fclose";
char print_str[] = "print";

/*------------visit--------------*/

static NCPL_RETVAL *ncpl_new_retval(NCPL_PARSER *p)
{
    NCPL_RETVAL *rv = (NCPL_RETVAL *)niffic_alloc(p->pool, sizeof(NCPL_RETVAL));
    assert(rv); return rv;
}

static void ncpl_free_retval(NCPL_RETVAL *rv)
{
    niffic_free(rv);
}

NCPL_RETVAL *ncpl_lex_visit(NCPL_PARSER *p, NCPL_LEX *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) {rv->type = -1; return rv;}
 //   printf("[%s]\n", ptr->content);
    rv->factor_str = ptr->content;
    rv->factor_type = rv->type = ptr->type; return rv;
}

NCPL_RETVAL *ncpl_start_visit(NCPL_PARSER *p, NCPL_start *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    ptr->val = NULL;
    ncpl_push_mark(&(p->env), "<mark_START>", DOMAINMARK);
    switch( ptr->type ) {
        case 0: {
            NCPL_RETVAL *rv_0_0 = ncpl_stm_visit(p, ptr->u.start_0.ncpl_0_0);
            if( rv_0_0==NULL ) return NULL;
            if( rv_0_0->type>=0 ) ptr->line = ptr->u.start_0.ncpl_0_0->line;
            if( rv_0_0!=NULL ) ncpl_free_retval(rv_0_0);
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    ncpl_pop_until_mark(&(p->env));
    return rv;
}

NCPL_RETVAL *ncpl_stmlist_visit(NCPL_PARSER *p, NCPL_stmlist *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    ptr->val = NULL;
    switch( ptr->type ) {
        case 2: {
            NCPL_RETVAL *rv_2_1 = ncpl_stm_visit(p, ptr->u.stmlist_2.ncpl_2_1);
            if( rv_2_1==NULL ) return NULL;
            if( rv_2_1->type>=0 ) ptr->line = ptr->u.stmlist_2.ncpl_2_1->line;
            if( rv_2_1!=NULL ) ncpl_free_retval(rv_2_1);
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_stm_visit(NCPL_PARSER *p, NCPL_stm *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    ptr->val = NULL;
    switch( ptr->type ) {
        case 3: {
            NCPL_RETVAL *rv_3_0 = ncpl_ctlexp_visit(p, ptr->u.stm_3.ncpl_3_0);
            if( rv_3_0==NULL ) return NULL;
            if( rv_3_0->type>=0 ) ptr->line = ptr->u.stm_3.ncpl_3_0->line;
            if( rv_3_0!=NULL ) ncpl_free_retval(rv_3_0);
            if( p->pass_tychk && p->ctlmark ) break;
            NCPL_RETVAL *rv_3_1 = ncpl_stmlist_visit(p, ptr->u.stm_3.ncpl_3_1);
            if( rv_3_1==NULL ) return NULL;
            if( rv_3_1->type>=0 ) ptr->line = ptr->u.stm_3.ncpl_3_1->line;
            if( rv_3_1!=NULL ) ncpl_free_retval(rv_3_1);
            break;
        }
        case 4: {
            NCPL_RETVAL *rv_4_0 = ncpl_tydecl_visit(p, ptr->u.stm_4.ncpl_4_0);
            if( rv_4_0==NULL ) return NULL;
            if( rv_4_0->type>=0 ) ptr->line = ptr->u.stm_4.ncpl_4_0->line;
            if( rv_4_0!=NULL ) ncpl_free_retval(rv_4_0);
            if( p->pass_tychk && p->ctlmark ) break;
            NCPL_RETVAL *rv_4_1 = ncpl_stmlist_visit(p, ptr->u.stm_4.ncpl_4_1);
            if( rv_4_1==NULL ) return NULL;
            if( rv_4_1->type>=0 ) ptr->line = ptr->u.stm_4.ncpl_4_1->line;
            if( rv_4_1!=NULL ) ncpl_free_retval(rv_4_1);
            break;
        }
        case 5: {
            NCPL_RETVAL *rv_5_0 = ncpl_select_exp_visit(p, ptr->u.stm_5.ncpl_5_0);
            if( rv_5_0==NULL ) return NULL;
            if( rv_5_0->type>=0 ) ptr->line = ptr->u.stm_5.ncpl_5_0->line;
            if( rv_5_0!=NULL ) ncpl_free_retval(rv_5_0);
            if( p->pass_tychk && p->ctlmark ) break;
            NCPL_RETVAL *rv_5_1 = ncpl_stmlist_visit(p, ptr->u.stm_5.ncpl_5_1);
            if( rv_5_1==NULL ) return NULL;
            if( rv_5_1->type>=0 ) ptr->line = ptr->u.stm_5.ncpl_5_1->line;
            if( rv_5_1!=NULL ) ncpl_free_retval(rv_5_1);
            break;
        }
        case 6: {
            NCPL_RETVAL *rv_6_0 = ncpl_loop_exp_visit(p, ptr->u.stm_6.ncpl_6_0);
            if( rv_6_0==NULL ) return NULL;
            if( rv_6_0->type>=0 ) ptr->line = ptr->u.stm_6.ncpl_6_0->line;
            if( rv_6_0!=NULL ) ncpl_free_retval(rv_6_0);
            if( p->pass_tychk && p->ctlmark ) break;
            NCPL_RETVAL *rv_6_1 = ncpl_stmlist_visit(p, ptr->u.stm_6.ncpl_6_1);
            if( rv_6_1==NULL ) return NULL;
            if( rv_6_1->type>=0 ) ptr->line = ptr->u.stm_6.ncpl_6_1->line;
            if( rv_6_1!=NULL ) ncpl_free_retval(rv_6_1);
            break;
        }
        case 7: {
            NCPL_RETVAL *rv_7_0 = ncpl_func_decl_visit(p, ptr->u.stm_7.ncpl_7_0);
            if( rv_7_0==NULL ) return NULL;
            if( rv_7_0->type>=0 ) ptr->line = ptr->u.stm_7.ncpl_7_0->line;
            if( rv_7_0!=NULL ) ncpl_free_retval(rv_7_0);
            if( p->pass_tychk && p->ctlmark ) break;
            NCPL_RETVAL *rv_7_1 = ncpl_stmlist_visit(p, ptr->u.stm_7.ncpl_7_1);
            if( rv_7_1==NULL ) return NULL;
            if( rv_7_1->type>=0 ) ptr->line = ptr->u.stm_7.ncpl_7_1->line;
            if( rv_7_1!=NULL ) ncpl_free_retval(rv_7_1);
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_ctlexp_visit(NCPL_PARSER *p, NCPL_ctlexp *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    ptr->val = NULL;
    switch( ptr->type ) {
        case 9: {
            NCPL_RETVAL *rv_9_0 = ncpl_lex_visit(p, ptr->u.ctlexp_9.ncpl_9_0);
            if( rv_9_0==NULL ) return NULL;
            if( rv_9_0->type>=0 ) ptr->line = ptr->u.ctlexp_9.ncpl_9_0->line;
            if( rv_9_0!=NULL ) ncpl_free_retval(rv_9_0);
            NCPL_SYM *sym = ncpl_get_sym(&(p->env), "<mark_WHILE>");
            if( sym==NULL ) {
lp1:            memset(p->log, 0, p->log_len);
                snprintf(p->log, p->log_len, "%s:%d: %s not in 'while'.", \
                p->pls.file, ptr->line, ptr->u.ctlexp_9.ncpl_9_0->content);
                return NULL;
            }
            NCPL_ENVVAR *var = ncpl_get_var(&(p->env), sym);
            if( var==NULL ) goto lp1;
            if( p->pass_tychk ) p->ctlmark = _N_C_CONTINUE;
            break;
        }
        case 10: {
            NCPL_RETVAL *rv_10_0 = ncpl_lex_visit(p, ptr->u.ctlexp_10.ncpl_10_0);
            if( rv_10_0==NULL ) return NULL;
            if( rv_10_0->type>=0 ) ptr->line = ptr->u.ctlexp_10.ncpl_10_0->line;
            if( rv_10_0!=NULL ) ncpl_free_retval(rv_10_0);
            NCPL_SYM *sym = ncpl_get_sym(&(p->env), "<mark_WHILE>");
            if( sym==NULL ) {
lp2:            memset(p->log, 0, p->log_len);
                snprintf(p->log, p->log_len, "%s:%d: %s not in 'while'.", \
                p->pls.file, ptr->line, ptr->u.ctlexp_10.ncpl_10_0->content);
                return NULL;
            }
            NCPL_ENVVAR *var = ncpl_get_var(&(p->env), sym);
            if( var==NULL ) goto lp2;
            if( p->pass_tychk ) p->ctlmark = _N_C_BREAK;
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_tydecl_visit(NCPL_PARSER *p, NCPL_tydecl *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    ptr->val = NULL;
    NCPL_ENVVAR *new_var = NULL;
    switch( ptr->type ) {
        case 11: {
            int ty_type, factor_type;
            NCPL_RETVAL *rv_11_0 = ncpl_ty_visit(p, ptr->u.tydecl_11.ncpl_11_0);
            if( rv_11_0==NULL ) return NULL;
            if( rv_11_0->type>=0 ) ptr->line = ptr->u.tydecl_11.ncpl_11_0->line;
            ty_type = rv_11_0->type;
            if( rv_11_0!=NULL ) ncpl_free_retval(rv_11_0);

            NCPL_RETVAL *rv_11_1 = ncpl_factor_visit(p, ptr->u.tydecl_11.ncpl_11_1);
            if( rv_11_1==NULL ) return NULL;
            if( rv_11_1->type>=0 ) ptr->line = ptr->u.tydecl_11.ncpl_11_1->line;
            factor_type = rv_11_1->type;
            if( rv_11_1!=NULL ) ncpl_free_retval(rv_11_1);
            if( factor_type!=ID ) { /*must be ID*/
                memset(p->log, 0, p->log_len);
                snprintf(p->log, p->log_len, "%s:%d: Invalid variable definition.", \
                p->pls.file, ptr->line); return NULL;
            }
            NCPL_SYM *sym;
            NCPL_ENVVAR *var;
            /*is declaration or assignment statement*/
            if( ty_type>0 ) {
                sym = ncpl_get_sym(&(p->env), \
                    ptr->u.tydecl_11.ncpl_11_1->u.factor_34.ncpl_34_0->content);
                if( sym!=NULL ) {
                    var = ncpl_get_var(&(p->env), sym);
                    if( var!=NULL && ncpl_check_var_repeat(&(p->env), sym) ) {
                        memset(p->log, 0, p->log_len);
                        snprintf(p->log, p->log_len, \
                        "%s:%d: Variable '%s' redeclared.", p->pls.file, ptr->line, \
                        ptr->u.tydecl_11.ncpl_11_1->u.factor_34.ncpl_34_0->content);
                        return NULL;
                    }
                }
                new_var = ncpl_push_new_variable(&(p->env), \
                    ptr->u.tydecl_11.ncpl_11_1->u.factor_34.ncpl_34_0->content, \
                    ty_type, 0);
                ncpl_init_new_var(p, new_var->val, ty_type);
            } else {
                sym = ncpl_get_sym(&(p->env), \
                      ptr->u.tydecl_11.ncpl_11_1->u.factor_34.ncpl_34_0->content);
                if( sym==NULL ) {
err:                memset(p->log, 0, p->log_len);
                    snprintf(p->log, p->log_len, "%s:%d: Undefined symbol '%s'.", p->pls.file, ptr->line,\
                    ptr->u.tydecl_11.ncpl_11_1->u.factor_34.ncpl_34_0->content);
                    return NULL;
                }
                var = ncpl_get_var(&(p->env), sym);
                if( var==NULL ) goto err;
            }
            /*type check*/
            int val_type, ret;
            NCPL_VALUE *val;

            NCPL_RETVAL *rv_11_2 = ncpl_assign_visit(p, ptr->u.tydecl_11.ncpl_11_2);
            if( rv_11_2==NULL ) return NULL;
            if( rv_11_2->type>=0 ) ptr->line = ptr->u.tydecl_11.ncpl_11_2->line;
            val_type = rv_11_2->type; val = rv_11_2->val;
            if( rv_11_2!=NULL ) ncpl_free_retval(rv_11_2);
            if( val_type<0 ) {/*no assignment part*/
                if( ty_type>0 ) {
                    rv->type = ptr->retval = ty_type;
                } else {
                    int var_type = ncpl_get_var_type(&(p->env), \
                    ptr->u.tydecl_11.ncpl_11_1->u.factor_34.ncpl_34_0->content);
                    assert(var_type>0);
                    rv->type = ptr->retval = var_type;
                }
                return rv;
            }
            if( ty_type>0 ) {
                if( (ret = ncpl_type_legal(ty_type, val_type))<0 ) {
                    memset(p->log, 0, p->log_len);
                    snprintf(p->log, p->log_len, "%s:%d: Type conflict.", p->pls.file, ptr->line);
                    return NULL;
                }
                rv->type = ptr->retval = ret; ncpl_equal_value(p->env.pool, new_var->val, val);
            } else {
                ret = ncpl_get_var_type(&(p->env), \
                ptr->u.tydecl_11.ncpl_11_1->u.factor_34.ncpl_34_0->content);
                assert(ret>0);
                if( (ret = ncpl_type_legal(ret, val_type))<0 ) {
                    memset(p->log, 0, p->log_len);
                    snprintf(p->log, p->log_len, "%s:%d: Type conflict.", p->pls.file, ptr->line);
                    return NULL;
                }
                NCPL_SYM *tsym = ncpl_get_sym(&(p->env), \
                ptr->u.tydecl_11.ncpl_11_1->u.factor_34.ncpl_34_0->content);
                new_var = ncpl_get_var(&(p->env), tsym);
                rv->type = ptr->retval = ret; ncpl_equal_value(p->env.pool, new_var->val, val);
            }
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

static void ncpl_init_new_var(NCPL_PARSER *p, NCPL_VALUE *val, int type)
{
    if( ncpl_isfile(type) ) {
        int tfd = -1; ncpl_assign_value(p->env.pool, val, _N_NUMERIC, _N_V_FILE, &tfd);
    } else if( ncpl_isstring(type) ) {
        ncpl_assign_value(p->env.pool, val, _N_NUMERIC, _N_V_STRING, NULL);
    } else if( ncpl_ischar(type) ) {
        char c = 0; ncpl_assign_value(p->env.pool, val, _N_NUMERIC, _N_V_CHAR, &c);
    } else if( ncpl_isfloat(type) ) {
        float f = 0; ncpl_assign_value(p->env.pool, val, _N_NUMERIC, _N_V_FLOAT, &f);
    } else if( ncpl_isshort(type) ) {
        short sh = 0; ncpl_assign_value(p->env.pool, val, _N_NUMERIC, _N_V_SHORT, &sh);
    } else if( ncpl_islong(type) ) {
    #ifdef __x86_64
        long l = 0;
    #else
        long long = 0;
    #endif
        ncpl_assign_value(p->env.pool, val, _N_NUMERIC, _N_V_LONG, &l);
    } else if( ncpl_isint(type) ) {
        int i = 0; ncpl_assign_value(p->env.pool, val, _N_NUMERIC, _N_V_INT, &i);
    } else {
        fprintf(stderr, "%s(): shouldn't be here. %d.\n", __FUNCTION__, type);
        assert(0);
    }
}

NCPL_RETVAL *ncpl_ty_visit(NCPL_PARSER *p, NCPL_ty *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    ptr->val = NULL;
    switch( ptr->type ) {
        case 12: {
            NCPL_RETVAL *rv_12_0 = ncpl_lex_visit(p, ptr->u.ty_12.ncpl_12_0);
            if( rv_12_0==NULL ) return NULL;
            if( rv_12_0->type>=0 ) ptr->line = ptr->u.ty_12.ncpl_12_0->line;
            rv->type = ptr->retval = rv_12_0->type;
            if( rv_12_0!=NULL ) ncpl_free_retval(rv_12_0);
            break;
        }
        case 13: {
            NCPL_RETVAL *rv_13_0 = ncpl_lex_visit(p, ptr->u.ty_13.ncpl_13_0);
            if( rv_13_0==NULL ) return NULL;
            if( rv_13_0->type>=0 ) ptr->line = ptr->u.ty_13.ncpl_13_0->line;
            rv->type = ptr->retval = rv_13_0->type;
            if( rv_13_0!=NULL ) ncpl_free_retval(rv_13_0);
            break;
        }
        case 14: {
            NCPL_RETVAL *rv_14_0 = ncpl_lex_visit(p, ptr->u.ty_14.ncpl_14_0);
            if( rv_14_0==NULL ) return NULL;
            if( rv_14_0->type>=0 ) ptr->line = ptr->u.ty_14.ncpl_14_0->line;
            rv->type = ptr->retval = rv_14_0->type;
            if( rv_14_0!=NULL ) ncpl_free_retval(rv_14_0);
            break;
        }
        case 15: {
            NCPL_RETVAL *rv_15_0 = ncpl_lex_visit(p, ptr->u.ty_15.ncpl_15_0);
            if( rv_15_0==NULL ) return NULL;
            if( rv_15_0->type>=0 ) ptr->line = ptr->u.ty_15.ncpl_15_0->line;
            rv->type = ptr->retval = rv_15_0->type;
            if( rv_15_0!=NULL ) ncpl_free_retval(rv_15_0);
            break;
        }
        case 16: {
            NCPL_RETVAL *rv_16_0 = ncpl_lex_visit(p, ptr->u.ty_16.ncpl_16_0);
            if( rv_16_0==NULL ) return NULL;
            if( rv_16_0->type>=0 ) ptr->line = ptr->u.ty_16.ncpl_16_0->line;
            rv->type = ptr->retval = rv_16_0->type;
            if( rv_16_0!=NULL ) ncpl_free_retval(rv_16_0);
            break;
        }
        case 17: {
            NCPL_RETVAL *rv_17_0 = ncpl_lex_visit(p, ptr->u.ty_17.ncpl_17_0);
            if( rv_17_0==NULL ) return NULL;
            if( rv_17_0->type>=0 ) ptr->line = ptr->u.ty_17.ncpl_17_0->line;
            rv->type = ptr->retval = rv_17_0->type;
            if( rv_17_0!=NULL ) ncpl_free_retval(rv_17_0);
            break;
        }
        case 18: {
            NCPL_RETVAL *rv_18_0 = ncpl_lex_visit(p, ptr->u.ty_18.ncpl_18_0);
            if( rv_18_0==NULL ) return NULL;
            if( rv_18_0->type>=0 ) ptr->line = ptr->u.ty_18.ncpl_18_0->line;
            rv->type = ptr->retval = rv_18_0->type;
            if( rv_18_0!=NULL ) ncpl_free_retval(rv_18_0);
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_assign_visit(NCPL_PARSER *p, NCPL_assign *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    if( ptr->val!=NULL ) {ncpl_free_value(ptr->val); ptr->val = NULL;}
    switch( ptr->type ) {
        case 20: {
            NCPL_RETVAL *rv_20_0 = ncpl_lex_visit(p, ptr->u.assign_20.ncpl_20_0);
            if( rv_20_0==NULL ) return NULL;
            if( rv_20_0->type>=0 ) ptr->line = ptr->u.assign_20.ncpl_20_0->line;
            if( rv_20_0!=NULL ) ncpl_free_retval(rv_20_0);
            NCPL_RETVAL *rv_20_1 = ncpl_exp_visit(p, ptr->u.assign_20.ncpl_20_1);
            if( rv_20_1==NULL ) return NULL;
            if( rv_20_1->type>=0 ) ptr->line = ptr->u.assign_20.ncpl_20_1->line;
            rv->type = ptr->retval = rv_20_1->type;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_20_1->val);
            rv->val = ptr->val;
            if( rv_20_1!=NULL ) ncpl_free_retval(rv_20_1);
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_select_exp_visit(NCPL_PARSER *p, NCPL_select_exp *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    ptr->val = NULL;
    switch( ptr->type ) {
        case 22: {
            NCPL_RETVAL *rv_22_2 = ncpl_exp_visit(p, ptr->u.select_exp_22.ncpl_22_2);
            if( rv_22_2==NULL ) return NULL;
            if( rv_22_2->type>=0 ) ptr->line = ptr->u.select_exp_22.ncpl_22_2->line;
            int istrue = ncpl_value_istrue(rv_22_2->val);
            if( rv_22_2!=NULL ) ncpl_free_retval(rv_22_2);
            if( !(p->pass_tychk) || istrue ) {
                ncpl_push_mark(&(p->env), "<mark_IF>", DOMAINMARK);
                NCPL_RETVAL *rv_22_5 = ncpl_stm_visit(p, ptr->u.select_exp_22.ncpl_22_5);
                if( rv_22_5==NULL ) return NULL;
                if( rv_22_5->type>=0 ) ptr->line = ptr->u.select_exp_22.ncpl_22_5->line;
                rv->type = ptr->retval = rv_22_5->type;
                if( rv_22_5!=NULL ) ncpl_free_retval(rv_22_5);
                ncpl_pop_until_mark(&(p->env));
                if( !(p->pass_tychk) ) {
                    NCPL_RETVAL *rv_22_7 = ncpl_elsee_visit(p, ptr->u.select_exp_22.ncpl_22_7);
                    if( rv_22_7==NULL ) return NULL;
                    if( rv_22_7->type>=0 ) ptr->line = ptr->u.select_exp_22.ncpl_22_7->line;
                    if( rv_22_7!=NULL ) ncpl_free_retval(rv_22_7);
                }
            } else {
                NCPL_RETVAL *rv_22_7 = ncpl_elsee_visit(p, ptr->u.select_exp_22.ncpl_22_7);
                if( rv_22_7==NULL ) return NULL;
                if( rv_22_7->type>=0 ) ptr->line = ptr->u.select_exp_22.ncpl_22_7->line;
                if( rv_22_7!=NULL ) ncpl_free_retval(rv_22_7);
            }
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_elsee_visit(NCPL_PARSER *p, NCPL_elsee *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    ptr->val = NULL;
    switch( ptr->type ) {
        case 23: {
            ncpl_push_mark(&(p->env), "<mark_ELSE>", DOMAINMARK);
            NCPL_RETVAL *rv_23_2 = ncpl_stm_visit(p, ptr->u.elsee_23.ncpl_23_2);
            if( rv_23_2==NULL ) return NULL;
            if( rv_23_2->type>=0 ) ptr->line = ptr->u.elsee_23.ncpl_23_2->line;
            if( rv_23_2!=NULL ) ncpl_free_retval(rv_23_2);
            ncpl_pop_until_mark(&(p->env));
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_loop_exp_visit(NCPL_PARSER *p, NCPL_loop_exp *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    ptr->val = NULL;
    switch( ptr->type ) {
        case 25: {
            NCPL_RETVAL *rv_25_2, *rv_25_5;
            int istrue;
lp:         ncpl_push_mark(&(p->env), "<mark_WHILE>", DOMAINMARK);

            rv_25_2 = ncpl_exp_visit(p, ptr->u.loop_exp_25.ncpl_25_2);
            if( rv_25_2==NULL ) return NULL;
            if( rv_25_2->type>=0 ) ptr->line = ptr->u.loop_exp_25.ncpl_25_2->line;
            if( rv_25_2->type==VOID ) {
                memset(p->log, 0, p->log_len);
                snprintf(p->log, p->log_len, "%s:%d: 'while' expression shouldn't be 'void'.", \
                p->pls.file, ptr->line); return NULL;
            }
            istrue = ncpl_value_istrue(rv_25_2->val);
            if( rv_25_2!=NULL ) ncpl_free_retval(rv_25_2);
            if( p->pass_tychk && !istrue ) break;

            rv_25_5 = ncpl_stm_visit(p, ptr->u.loop_exp_25.ncpl_25_5);
            if( rv_25_5==NULL ) return NULL;
            if( rv_25_5->type>=0 ) ptr->line = ptr->u.loop_exp_25.ncpl_25_5->line;
            if( rv_25_5!=NULL ) ncpl_free_retval(rv_25_5);
            ncpl_pop_until_mark(&(p->env));
            if( p->pass_tychk ) {
                if( p->ctlmark==_N_C_BREAK ) { p->ctlmark = 0; break;}
                else if( p->ctlmark==_N_C_CONTINUE ) { p->ctlmark = 0; goto lp;}
                else goto lp;
            }
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_func_decl_visit(NCPL_PARSER *p, NCPL_func_decl *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    if( ptr->val!=NULL ) ncpl_free_value(ptr->val); ptr->val = NULL;
    rv->factor_type = ptr->factor_type = EXPTYPE;
    switch( ptr->type ) {
        case 26: {
            ncpl_push_mark(&(p->env), "<mark_QUERY>", FUNCMARK);
            NCPL_RETVAL *rv_26_0 = ncpl_lex_visit(p, ptr->u.func_decl_26.ncpl_26_0);
            if( rv_26_0==NULL ) return NULL;
            if( rv_26_0->type>=0 ) ptr->line = ptr->u.func_decl_26.ncpl_26_0->line;
            if( rv_26_0!=NULL ) ncpl_free_retval(rv_26_0);
            NCPL_RETVAL *rv_26_2 = ncpl_exp_visit(p, ptr->u.func_decl_26.ncpl_26_2);
            if( rv_26_2==NULL ) return NULL;
            if( rv_26_2->type>=0 ) ptr->line = ptr->u.func_decl_26.ncpl_26_2->line;
            if( rv_26_2!=NULL ) ncpl_free_retval(rv_26_2);
            ptr->retval = rv->type = INT; int nr_prm;
            nr_prm = ncpl_check_function_type(&(p->env), ptr->u.func_decl_26.ncpl_26_2, query_str, 0);
            if( nr_prm==1 ) {
                memset(p->log, 0, p->log_len);
                snprintf(p->log, p->log_len, "%s:%d: Too few parameters in function 'query'.", \
                p->pls.file, ptr->line); return NULL;
            } else if( nr_prm==2 ) {
                memset(p->log, 0, p->log_len);
                snprintf(p->log, p->log_len, "%s:%d: Too many parameters in function 'query'.", \
                p->pls.file, ptr->line); return NULL;
            } else if( nr_prm<0 ) {
                memset(p->log, 0, p->log_len);
                snprintf(p->log, p->log_len, "%s:%d: Parameter %d error.", \
                p->pls.file, ptr->line, -nr_prm); return NULL;
            }
            int err = ncpl_check_strfmt(p, ptr->u.func_decl_26.ncpl_26_2);
            if( err<0 ) {
                memset(p->log, 0, p->log_len);
                snprintf(p->log, p->log_len, "%s:%d: %s", p->pls.file, ptr->line, ncpl_value_strerror(err));
                return NULL;
            }
            if( p->pass_tychk ) {
                char *buf = (char *)niffic_alloc(p->env.pool, err);
                assert(buf);
                err = ncpl_copy_strfmt(p, ptr->u.func_decl_26.ncpl_26_2, buf);
                if( err<0 ) {
                    niffic_free(buf);
                    memset(p->log, 0, p->log_len);
                    snprintf(p->log, p->log_len, "%s:%d: %s", p->pls.file, ptr->line, ncpl_value_strerror(err));
                    return NULL;
                }
                /*@chg*/ niffic_free(buf);
                int i = 0;
                ptr->val = ncpl_new_value(p->env.pool);
                ncpl_assign_value(p->env.pool, ptr->val, _N_NUMERIC, _N_V_INT, &i);
            } else {
                ptr->val = ncpl_new_value(p->env.pool); int i = -1;
                ncpl_assign_value(p->env.pool, ptr->val, _N_NUMERIC, _N_V_INT, &i);
            }
            rv->val = ptr->val;
            break;
        }
        case 27: {
            ncpl_push_mark(&(p->env), "<mark_FOPEN>", FUNCMARK);
            NCPL_RETVAL *rv_27_0 = ncpl_lex_visit(p, ptr->u.func_decl_27.ncpl_27_0);
            if( rv_27_0==NULL ) return NULL;
            if( rv_27_0->type>=0 ) ptr->line = ptr->u.func_decl_27.ncpl_27_0->line;
            if( rv_27_0!=NULL ) ncpl_free_retval(rv_27_0);
            NCPL_RETVAL *rv_27_2 = ncpl_exp_visit(p, ptr->u.func_decl_27.ncpl_27_2);
            if( rv_27_2==NULL ) return NULL;
            if( rv_27_2->type>=0 ) ptr->line = ptr->u.func_decl_27.ncpl_27_2->line;
            NCPL_VALUE *param_val = rv_27_2->val;
            if( rv_27_2!=NULL ) ncpl_free_retval(rv_27_2);

            ptr->retval = rv->type = FFILE; int nr_prm;
            nr_prm = ncpl_check_function_type(&(p->env), ptr->u.func_decl_27.ncpl_27_2, fopen_str, 1);
            if( nr_prm==1 ) {
                memset(p->log, 0, p->log_len);
                snprintf(p->log, p->log_len, "%s:%d: Too few parameters in function 'fopen'.", \
                p->pls.file, ptr->line); return NULL;
            } else if( nr_prm==2 ) {
                memset(p->log, 0, p->log_len);
                snprintf(p->log, p->log_len, "%s:%d: Too many parameters in function 'fopen'.", \
                p->pls.file, ptr->line); return NULL;
            } else if( nr_prm<0 ) {
                memset(p->log, 0, p->log_len);
                snprintf(p->log, p->log_len, "%s:%d: Parameter %d error.", \
                p->pls.file, ptr->line, -nr_prm); return NULL;
            }
            ptr->val = ncpl_new_value(p->env.pool);
            if( !(p->pass_tychk) || ncpl_value_file_open(p->env.pool, ptr->val, param_val)<0 ) {
                int err_fd = -1;
                ncpl_assign_value(p->env.pool, ptr->val, _N_NUMERIC, _N_V_FILE, &err_fd);
            } else {
                int fd = ncpl_get_file_desc(ptr->val);
                NCPL_FD *nfd = ncpl_new_fd(p->pool, fd);
                ncpl_add_fd(nfd, p->fdhash);
            }
            rv->val = ptr->val;
            break;
        }
        case 28: {
            ncpl_push_mark(&(p->env), "<mark_FCLOSE>", FUNCMARK);
            NCPL_RETVAL *rv_28_0 = ncpl_lex_visit(p, ptr->u.func_decl_28.ncpl_28_0);
            if( rv_28_0==NULL ) return NULL;
            if( rv_28_0->type>=0 ) ptr->line = ptr->u.func_decl_28.ncpl_28_0->line;
            if( rv_28_0!=NULL ) ncpl_free_retval(rv_28_0);
            NCPL_RETVAL *rv_28_2 = ncpl_exp_visit(p, ptr->u.func_decl_28.ncpl_28_2);
            if( rv_28_2==NULL ) return NULL;
            if( rv_28_2->type>=0 ) ptr->line = ptr->u.func_decl_28.ncpl_28_2->line;
            NCPL_VALUE *file_val = rv_28_2->val;
            if( rv_28_2!=NULL ) ncpl_free_retval(rv_28_2);

            ptr->retval = rv->type = VOID; int nr_prm;
            nr_prm = ncpl_check_function_type(&(p->env), ptr->u.func_decl_28.ncpl_28_2, fclose_str, 1);
            if( nr_prm==1 ) {
                memset(p->log, 0, p->log_len);
                snprintf(p->log, p->log_len, "%s:%d: Too few parameters in function 'fclose'.", \
                p->pls.file, ptr->line); return NULL;
            } else if( nr_prm==2 ) {
                memset(p->log, 0, p->log_len);
                snprintf(p->log, p->log_len, "%s:%d: Too many parameters in function 'fclose'.", \
                p->pls.file, ptr->line); return NULL;
            } else if( nr_prm<0 ) {
                memset(p->log, 0, p->log_len);
                snprintf(p->log, p->log_len, "%s:%d: Parameter %d error.", \
                p->pls.file, ptr->line, -nr_prm); return NULL;
            }
            int fd = ncpl_get_file_desc(file_val);
            if( fd<0 ) break;  /*if fopen error, then no need to delete and free NCPL_FD*/
            NCPL_FD *nfd = ncpl_get_fd(fd, p->fdhash);
            assert(nfd);
            ncpl_value_file_close(p->env.pool, file_val);
            ncpl_del_fd(nfd, p->fdhash);
            ncpl_free_fd(nfd, 0);
            break;
        }
        case 29: {
            ncpl_push_mark(&(p->env), "<mark_PRINT>", FUNCMARK);
            NCPL_RETVAL *rv_29_0 = ncpl_lex_visit(p, ptr->u.func_decl_29.ncpl_29_0);
            if( rv_29_0==NULL ) return NULL;
            if( rv_29_0->type>=0 ) ptr->line = ptr->u.func_decl_29.ncpl_29_0->line;
            if( rv_29_0!=NULL ) ncpl_free_retval(rv_29_0);
            NCPL_RETVAL *rv_29_2 = ncpl_exp_visit(p, ptr->u.func_decl_29.ncpl_29_2);
            if( rv_29_2==NULL ) return NULL;
            if( rv_29_2->type>=0 ) ptr->line = ptr->u.func_decl_29.ncpl_29_2->line;
            if( rv_29_2!=NULL ) ncpl_free_retval(rv_29_2);
            ptr->retval = rv->type = STR; int nr_prm;
            nr_prm = ncpl_check_function_type(&(p->env), ptr->u.func_decl_29.ncpl_29_2, print_str, 0);
            if( nr_prm==1 ) {
                memset(p->log, 0, p->log_len);
                snprintf(p->log, p->log_len, "%s:%d: Too few parameters in function 'query'.", \
                p->pls.file, ptr->line); return NULL;
            } else if( nr_prm==2 ) {
                memset(p->log, 0, p->log_len);
                snprintf(p->log, p->log_len, "%s:%d: Too many parameters in function 'query'.", \
                p->pls.file, ptr->line); return NULL;
            } else if( nr_prm<0 ) {
                memset(p->log, 0, p->log_len);
                snprintf(p->log, p->log_len, "%s:%d: Parameter %d error.", \
                p->pls.file, ptr->line, -nr_prm); return NULL;
            }
            int err = ncpl_check_strfmt(p, ptr->u.func_decl_29.ncpl_29_2);
            if( err<0 ) {
                memset(p->log, 0, p->log_len);
                snprintf(p->log, p->log_len, "%s:%d: %s", p->pls.file, ptr->line, ncpl_value_strerror(err));
                return NULL;
            }
            if( p->pass_tychk ) {
                char *buf = (char *)niffic_alloc(p->env.pool, err);
                assert(buf);
                err = ncpl_copy_strfmt(p, ptr->u.func_decl_29.ncpl_29_2, buf);
                if( err<0 ) {
                    niffic_free(buf);
                    memset(p->log, 0, p->log_len);
                    snprintf(p->log, p->log_len, "%s:%d: %s", p->pls.file, ptr->line, ncpl_value_strerror(err));
                    return NULL;
                }
                ptr->val = ncpl_new_value(p->env.pool);
                ncpl_assign_value(p->env.pool, ptr->val, _N_NUMERIC, _N_V_STRING, buf);
                printf("%s", buf); fflush(stdout); niffic_free(buf);
            } else {
                ptr->val = ncpl_new_value(p->env.pool);
                ncpl_assign_value(p->env.pool, ptr->val, _N_NUMERIC, _N_V_STRING, NULL);
            }
            rv->val = ptr->val;
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    ncpl_pop_until_mark(&(p->env));
    return rv;
}

static int ncpl_check_strfmt(NCPL_PARSER *p, NCPL_exp *ex)
{
    char *s = ex->val->u.num.u.s.s;
    NCPL_explist *epl;
    NCPL_exp *e = ex;
    int cnt = 0;
    for(; *s!=0; s++) {
        if( *s=='%' ) {
            s++;
            if( *s=='d' ) {
                if( e->type==32 ) epl = e->u.exp_32.ncpl_32_1;
                else epl = e->u.exp_33.ncpl_33_1;
                if( epl==NULL ) return E_N_PRM_TYPE;
                e = epl->u.explist_31.ncpl_31_1;
                if( !ncpl_isnumeral(e->retval) && !ncpl_isfile(e->retval) )
                    return E_N_PRM_TYPE;
                cnt += N_NUMLEN;
            } else if( *s=='c' ) {
                if( e->type==32 ) epl = e->u.exp_32.ncpl_32_1;
                else epl = e->u.exp_33.ncpl_33_1;
                if( epl==NULL ) return E_N_PRM_TYPE;
                e = epl->u.explist_31.ncpl_31_1;
                if( !ncpl_ischar(e->retval) && !ncpl_isfile(e->retval) )
                    return E_N_PRM_TYPE;
                cnt++;
            } else if( *s=='f' ) {
                if( e->type==32 ) epl = e->u.exp_32.ncpl_32_1;
                else epl = e->u.exp_33.ncpl_33_1;
                if( epl==NULL ) return E_N_PRM_TYPE;
                e = epl->u.explist_31.ncpl_31_1;
                if( !ncpl_isfloat(e->retval) && !ncpl_isfile(e->retval) )
                    return E_N_PRM_TYPE;
                cnt += N_NUMLEN;
            } else if( *s=='s' ) {
                if( e->type==32 ) epl = e->u.exp_32.ncpl_32_1;
                else epl = e->u.exp_33.ncpl_33_1;
                if( epl==NULL ) return E_N_PRM_TYPE;
                e = epl->u.explist_31.ncpl_31_1;
                if( !ncpl_isstring(e->retval) && !ncpl_isfile(e->retval) )
                    return E_N_PRM_TYPE;
                cnt += _N_V_BUFLEN;
            } else if( *s=='e' ) {
                cnt += strlen(p->log);
            } else if( *s=='%' ) {
                cnt++;
            } else {
                return E_N_STR_FMT;
            }
        } else cnt++;
    }
    return cnt+1;
}

#define N_GetValue(v,e,s,env); \
    if( ncpl_isfile((e)->retval) ) {\
        NCPL_SYM *sym = ncpl_get_sym((env),(s));\
        assert(sym);\
        NCPL_ENVVAR *var = ncpl_get_var((env),sym);\
        assert(var);\
        (v) = var->val;\
    } else {\
        (v) = (e)->val;\
    }


static int ncpl_copy_strfmt(NCPL_PARSER *p, NCPL_exp *ex, char *buf)
{
    char *s = ex->val->u.num.u.s.s;
    NCPL_explist *epl;
    NCPL_exp *e = ex;
    int len, error = 0;
    NCPL_VALUE *val;
    for(; *s!=0; s++) {
        if( *s=='%' ) {
            s++;
            if( *s=='d' ) {
                if( e->type==32 ) epl = e->u.exp_32.ncpl_32_1;
                else epl = e->u.exp_33.ncpl_33_1;
                if( epl==NULL ) return E_N_PRM_TYPE;
                e = epl->u.explist_31.ncpl_31_1;
                N_GetValue(val, e, e->factor_str, &(p->env));
            #ifdef __x86_64
                long l = ncpl_get_integer_value(val, &error);
                if( error ) return error;
                len = sprintf(buf, "%ld", l);
            #else
                long long l = ncpl_get_integer_value(val, &error);
                if( error ) return error;
                len = sprintf(buf, "%lld", l);
            #endif
                assert(len<=N_NUMLEN); buf += len;
            } else if( *s=='c' ) {
                if( e->type==32 ) epl = e->u.exp_32.ncpl_32_1;
                else epl = e->u.exp_33.ncpl_33_1;
                if( epl==NULL ) return E_N_PRM_TYPE;
                e = epl->u.explist_31.ncpl_31_1;
                N_GetValue(val, e, e->factor_str, &(p->env));
                char c = ncpl_get_char_value(val, &error);
                if( error ) return error;
                len = sprintf(buf, "%c", c);
                buf += len;
            } else if( *s=='f' ) {
                if( e->type==32 ) epl = e->u.exp_32.ncpl_32_1;
                else epl = e->u.exp_33.ncpl_33_1;
                if( epl==NULL ) return E_N_PRM_TYPE;
                e = epl->u.explist_31.ncpl_31_1;
                N_GetValue(val, e, e->factor_str, &(p->env));
                float f = ncpl_get_float_value(val, &error);
                if( error ) return error;
                len = sprintf(buf, "%f", f);
                assert(len<=N_NUMLEN); buf += len;
            } else if( *s=='s' ) {
                if( e->type==32 ) epl = e->u.exp_32.ncpl_32_1;
                else epl = e->u.exp_33.ncpl_33_1;
                if( epl==NULL ) return E_N_PRM_TYPE;
                e = epl->u.explist_31.ncpl_31_1;
                N_GetValue(val, e, e->factor_str, &(p->env));
                char *s = ncpl_get_string_value(val, &error);
                if( error ) return error;
                len = sprintf(buf, "%s", s);
                assert(len<=_N_V_BUFLEN); buf += len;
            } else if( *s=='e' ) {
                len = sprintf(buf, "%s", p->log); buf += len;
            } else if( *s=='%' ) {
                *buf++ = *s;
            } else {
                assert(0);
            }
        } else {
            *buf++ = *s;
        }
    }
    return 0;
}

static unsigned int ncpl_calc_real_nr_param(NCPL_exp *ex)
{
    unsigned int sum = 0;
    NCPL_explist *epl;
    while( 1 ) {
        if( ex!=NULL ) sum++;
        if( ex->type==32 ) epl = ex->u.exp_32.ncpl_32_1;
        else {
            assert(ex->type==33);
            epl = ex->u.exp_33.ncpl_33_1;
        }
        if( epl==NULL ) break;
        ex = epl->u.explist_31.ncpl_31_1;
    }
    return sum;
}

static int ncpl_check_function_type(NCPL_ENV *env, \
NCPL_exp *ex, char *func_name, int is_restrict)
{
    NCPL_SYM *sym = ncpl_get_sym(env, func_name);
    assert(sym);
    NCPL_ENVVAR *var = ncpl_get_var(env, sym);
    assert(var);
    NCPL_ENVTYLIST *list = var->u.func.formal;
    unsigned int nr_decl_prm = ncpl_get_nr_param(list);
    unsigned int nr_real_prm = ncpl_calc_real_nr_param(ex);
    if( is_restrict ) {
        if( nr_decl_prm>nr_real_prm ) return 1;
        if( nr_decl_prm<nr_real_prm ) return 2;
    } else {
        if( nr_real_prm<nr_decl_prm ) return 1;
    }
    unsigned int i;
    NCPL_explist *epl;
    for(i = 0; i<nr_decl_prm; i++) {
        if( list->typ->type!=VOID && ncpl_type_legal(list->typ->type, ex->retval)<0 )
            return -i;
        list = list->next;
        if( ex->type==32 ) {
            epl = ex->u.exp_32.ncpl_32_1;
            if( epl==NULL ) continue;
            ex = epl->u.explist_31.ncpl_31_1;
        } else {
            assert(ex->type==33);
            epl = ex->u.exp_33.ncpl_33_1;
            if( epl==NULL ) continue;
            ex = epl->u.explist_31.ncpl_31_1;
        }
    }
    return 0;
}

NCPL_RETVAL *ncpl_explist_visit(NCPL_PARSER *p, NCPL_explist *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    ptr->val = NULL;
    switch( ptr->type ) {
        case 31: {
            NCPL_RETVAL *rv_31_1 = ncpl_exp_visit(p, ptr->u.explist_31.ncpl_31_1);
            if( rv_31_1==NULL ) return NULL;
            if( rv_31_1->type>=0 ) ptr->line = ptr->u.explist_31.ncpl_31_1->line;
            rv->type = ptr->retval = rv_31_1->type;
            rv->factor_type = ptr->factor_type = rv_31_1->factor_type;
            rv->factor_str = ptr->factor_str = rv_31_1->factor_str;
            if( rv_31_1!=NULL ) ncpl_free_retval(rv_31_1);
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_exp_visit(NCPL_PARSER *p, NCPL_exp *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    if( ptr->val!=NULL ) {ncpl_free_value(ptr->val); ptr->val = NULL;}
    switch( ptr->type ) {
        case 32: {
            NCPL_RETVAL *rv_32_0 = ncpl_func_decl_visit(p, ptr->u.exp_32.ncpl_32_0);
            if( rv_32_0==NULL ) return NULL;
            if( rv_32_0->type>=0 ) ptr->line = ptr->u.exp_32.ncpl_32_0->line;
            rv->type = ptr->retval = rv_32_0->type;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_32_0->val);
            rv->val = ptr->val;
            rv->factor_type = ptr->factor_type = rv_32_0->factor_type;
            rv->factor_str = ptr->factor_str = rv_32_0->factor_str;
            if( rv_32_0!=NULL ) ncpl_free_retval(rv_32_0);
            NCPL_RETVAL *rv_32_1 = ncpl_explist_visit(p, ptr->u.exp_32.ncpl_32_1);
            if( rv_32_1==NULL ) return NULL;
            if( rv_32_1->type>=0 ) ptr->line = ptr->u.exp_32.ncpl_32_1->line;
            if( rv_32_1!=NULL ) ncpl_free_retval(rv_32_1);
            break;
        }
        case 33: {
            NCPL_RETVAL *rv_33_0 = ncpl_assignexp_visit(p, ptr->u.exp_33.ncpl_33_0);
            if( rv_33_0==NULL ) return NULL;
            if( rv_33_0->type>=0 ) ptr->line = ptr->u.exp_33.ncpl_33_0->line;
            rv->type = ptr->retval = rv_33_0->type;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_33_0->val);
            rv->val = ptr->val;
            rv->factor_type = ptr->factor_type = rv_33_0->factor_type;
            rv->factor_str = ptr->factor_str = rv_33_0->factor_str;
            if( rv_33_0!=NULL ) ncpl_free_retval(rv_33_0);
            NCPL_RETVAL *rv_33_1 = ncpl_explist_visit(p, ptr->u.exp_33.ncpl_33_1);
            if( rv_33_1==NULL ) return NULL;
            if( rv_33_1->type>=0 ) ptr->line = ptr->u.exp_33.ncpl_33_1->line;
            if( rv_33_1!=NULL ) ncpl_free_retval(rv_33_1);
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_factor_visit(NCPL_PARSER *p, NCPL_factor *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    if( ptr->val!=NULL ) ncpl_free_value(ptr->val); ptr->val = NULL;
    switch( ptr->type ) {
        case 34: {
            NCPL_RETVAL *rv_34_0 = ncpl_lex_visit(p, ptr->u.factor_34.ncpl_34_0);
            if( rv_34_0==NULL ) return NULL;
            if( rv_34_0->type>=0 ) ptr->line = ptr->u.factor_34.ncpl_34_0->line;
            rv->type = ptr->retval = rv_34_0->type;
            rv->factor_type = ptr->factor_type = rv_34_0->factor_type;
            rv->factor_str = ptr->factor_str = rv_34_0->factor_str;
            if( rv_34_0!=NULL ) ncpl_free_retval(rv_34_0);
            break;
        }
        case 35: {
            NCPL_RETVAL *rv_35_0 = ncpl_lex_visit(p, ptr->u.factor_35.ncpl_35_0);
            if( rv_35_0==NULL ) return NULL;
            if( rv_35_0->type>=0 ) ptr->line = ptr->u.factor_35.ncpl_35_0->line;
            NCPL_ENVVAR *var = ncpl_push_new_variable(&(p->env), \
            ptr->u.factor_35.ncpl_35_0->content, rv_35_0->type, 0);
            #ifdef __x86_64
            long l = atol(ptr->u.factor_35.ncpl_35_0->content);
            #else
            long long l = atoll(ptr->u.factor_35.ncpl_35_0->content);
            #endif
            ncpl_assign_value(p->env.pool, var->val, _N_NUMERIC, _N_V_LONG, &l);
            rv->type = ptr->retval = rv_35_0->type;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, var->val);
            rv->val = ptr->val;
            rv->factor_type = ptr->factor_type = rv_35_0->factor_type;
            rv->factor_str = ptr->factor_str = rv_35_0->factor_str;
            if( rv_35_0!=NULL ) ncpl_free_retval(rv_35_0);
            break;
        }
        case 36: {
            NCPL_RETVAL *rv_36_0 = ncpl_lex_visit(p, ptr->u.factor_36.ncpl_36_0);
            if( rv_36_0==NULL ) return NULL;
            if( rv_36_0->type>=0 ) ptr->line = ptr->u.factor_36.ncpl_36_0->line;
            NCPL_ENVVAR *var = ncpl_push_new_variable(&(p->env), \
            ptr->u.factor_36.ncpl_36_0->content, rv_36_0->type, 0);
            float f = atof(ptr->u.factor_36.ncpl_36_0->content);
            ncpl_assign_value(p->env.pool, var->val, _N_NUMERIC, _N_V_FLOAT, &f);
            rv->type = ptr->retval = rv_36_0->type;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, var->val);
            rv->val = ptr->val;
            rv->factor_type = ptr->factor_type = rv_36_0->factor_type;
            rv->factor_str = ptr->factor_str = rv_36_0->factor_str;
            if( rv_36_0!=NULL ) ncpl_free_retval(rv_36_0);
            break;
        }
        case 37: {
            NCPL_RETVAL *rv_37_0 = ncpl_lex_visit(p, ptr->u.factor_37.ncpl_37_0);
            if( rv_37_0==NULL ) return NULL;
            if( rv_37_0->type>=0 ) ptr->line = ptr->u.factor_37.ncpl_37_0->line;
            NCPL_ENVVAR *var = ncpl_push_new_variable(&(p->env), \
            ptr->u.factor_37.ncpl_37_0->content, rv_37_0->type, 0);
            char c = *(ptr->u.factor_37.ncpl_37_0->content);
            ncpl_assign_value(p->env.pool, var->val, _N_NUMERIC, _N_V_CHAR, &c);
            rv->type = ptr->retval = rv_37_0->type;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, var->val);
            rv->val = ptr->val;
            rv->factor_type = ptr->factor_type = rv_37_0->factor_type;
            rv->factor_str = ptr->factor_str = rv_37_0->factor_str;
            if( rv_37_0!=NULL ) ncpl_free_retval(rv_37_0);
            break;
        }
        case 38: {
            NCPL_RETVAL *rv_38_0 = ncpl_lex_visit(p, ptr->u.factor_38.ncpl_38_0);
            if( rv_38_0==NULL ) return NULL;
            if( rv_38_0->type>=0 ) ptr->line = ptr->u.factor_38.ncpl_38_0->line;
            NCPL_ENVVAR *var = ncpl_push_new_variable(&(p->env), \
            ptr->u.factor_38.ncpl_38_0->content, rv_38_0->type, 0);
            char *s = ptr->u.factor_38.ncpl_38_0->content;
            ncpl_assign_value(p->env.pool, var->val, _N_NUMERIC, _N_V_STRING, s);
            rv->type = ptr->retval = rv_38_0->type;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, var->val);
            rv->val = ptr->val;
            rv->factor_type = ptr->factor_type = rv_38_0->factor_type;
            rv->factor_str = ptr->factor_str = rv_38_0->factor_str;
            if( rv_38_0!=NULL ) ncpl_free_retval(rv_38_0);
            break;
        }
        case 39: {
            NCPL_RETVAL *rv_39_0 = ncpl_lex_visit(p, ptr->u.factor_39.ncpl_39_0);
            if( rv_39_0==NULL ) return NULL;
            if( rv_39_0->type>=0 ) ptr->line = ptr->u.factor_39.ncpl_39_0->line;
            NCPL_ENVVAR *var = ncpl_push_new_variable(&(p->env), \
            ptr->u.factor_39.ncpl_39_0->content, rv_39_0->type, 0);
            ncpl_assign_value(p->env.pool, var->val, _N_NUMERIC, _N_V_STRING, NULL);
            rv->type = ptr->retval = rv_39_0->type;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, var->val);
            rv->val = ptr->val;
            rv->factor_type = ptr->factor_type = rv_39_0->factor_type;
            rv->factor_str = ptr->factor_str = rv_39_0->factor_str;
            if( rv_39_0!=NULL ) ncpl_free_retval(rv_39_0);
            break;
        }
        case 40: {
            NCPL_RETVAL *rv_40_0 = ncpl_lex_visit(p, ptr->u.factor_40.ncpl_40_0);
            if( rv_40_0==NULL ) return NULL;
            if( rv_40_0->type>=0 ) ptr->line = ptr->u.factor_40.ncpl_40_0->line;
            NCPL_ENVVAR *var = ncpl_push_new_variable(&(p->env), \
            ptr->u.factor_40.ncpl_40_0->content, rv_40_0->type, 0);
            int fd = -1;
            ncpl_assign_value(p->env.pool, var->val, _N_NUMERIC, _N_V_FILE, &fd);
            rv->type = ptr->retval = rv_40_0->type;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, var->val);
            rv->val = ptr->val;
            rv->factor_type = ptr->factor_type = rv_40_0->factor_type;
            rv->factor_str = ptr->factor_str = rv_40_0->factor_str;
            if( rv_40_0!=NULL ) ncpl_free_retval(rv_40_0);
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_parenexp_visit(NCPL_PARSER *p, NCPL_parenexp *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    if( ptr->val!=NULL ) ncpl_free_value(ptr->val); ptr->val = NULL;
    switch( ptr->type ) {
        case 41: {
            NCPL_RETVAL *rv_41_0 = ncpl_factor_visit(p, ptr->u.parenexp_41.ncpl_41_0);
            if( rv_41_0==NULL ) return NULL;
            if( rv_41_0->type>=0 ) ptr->line = ptr->u.parenexp_41.ncpl_41_0->line;
            int type = rv_41_0->type;
            rv->factor_type = ptr->factor_type = rv_41_0->factor_type;
            rv->factor_str = ptr->factor_str = rv_41_0->factor_str;
            if( type==ID ) {
                if( rv_41_0!=NULL ) ncpl_free_retval(rv_41_0);
                NCPL_SYM *sym = ncpl_get_sym(&(p->env), \
                ptr->u.parenexp_41.ncpl_41_0->u.factor_34.ncpl_34_0->content);
                if( sym==NULL ) {
err:                memset(p->log, 0, p->log_len);
                    snprintf(p->log, p->log_len, "%s:%d: Undefined symbol '%s'.", \
                    p->pls.file, ptr->line, \
                    ptr->u.parenexp_41.ncpl_41_0->u.factor_34.ncpl_34_0->content);
                    return NULL;
                }
                NCPL_ENVVAR *var = ncpl_get_var(&(p->env), sym);
                if( var==NULL ) goto err;
                int ret = ncpl_get_var_type(&(p->env), \
                ptr->u.parenexp_41.ncpl_41_0->u.factor_34.ncpl_34_0->content);
                assert(ret>0);
                ptr->val = ncpl_new_value(p->env.pool);
                ncpl_equal_value(p->env.pool, ptr->val, var->val);
                rv->type = ptr->retval = ret;
                rv->val = ptr->val;
            } else {
                ptr->val = ncpl_new_value(p->env.pool);
                ncpl_equal_value(p->env.pool, ptr->val, rv_41_0->val);
                if( rv_41_0!=NULL ) ncpl_free_retval(rv_41_0);
                rv->type = ptr->retval = type;
                rv->val = ptr->val;
            }
            break;
        }
        case 42: {
            NCPL_RETVAL *rv_42_1 = ncpl_exp_visit(p, ptr->u.parenexp_42.ncpl_42_1);
            if( rv_42_1==NULL ) return NULL;
            if( rv_42_1->type>=0 ) ptr->line = ptr->u.parenexp_42.ncpl_42_1->line;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_42_1->val);
            rv->type = ptr->retval = rv_42_1->type;
            rv->val = ptr->val;
            rv->factor_type = ptr->factor_type = rv_42_1->factor_type;
            rv->factor_str = ptr->factor_str = rv_42_1->factor_str;
            if( rv_42_1!=NULL ) ncpl_free_retval(rv_42_1);
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_unary_opr_visit(NCPL_PARSER *p, NCPL_unary_opr *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    ptr->val = NULL;
    switch( ptr->type ) {
        case 43: {
            NCPL_RETVAL *rv_43_0 = ncpl_lex_visit(p, ptr->u.unary_opr_43.ncpl_43_0);
            if( rv_43_0==NULL ) return NULL;
            if( rv_43_0->type>=0 ) ptr->line = ptr->u.unary_opr_43.ncpl_43_0->line;
            rv->type = ptr->retval = rv_43_0->type;
            if( rv_43_0!=NULL ) ncpl_free_retval(rv_43_0);
            break;
        }
        case 44: {
            NCPL_RETVAL *rv_44_0 = ncpl_lex_visit(p, ptr->u.unary_opr_44.ncpl_44_0);
            if( rv_44_0==NULL ) return NULL;
            if( rv_44_0->type>=0 ) ptr->line = ptr->u.unary_opr_44.ncpl_44_0->line;
            rv->type = ptr->retval = rv_44_0->type;
            if( rv_44_0!=NULL ) ncpl_free_retval(rv_44_0);
            break;
        }
        case 45: {
            NCPL_RETVAL *rv_45_0 = ncpl_lex_visit(p, ptr->u.unary_opr_45.ncpl_45_0);
            if( rv_45_0==NULL ) return NULL;
            if( rv_45_0->type>=0 ) ptr->line = ptr->u.unary_opr_45.ncpl_45_0->line;
            rv->type = ptr->retval = rv_45_0->type;
            if( rv_45_0!=NULL ) ncpl_free_retval(rv_45_0);
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_castexp_visit(NCPL_PARSER *p, NCPL_castexp *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    if( ptr->val!=NULL ) ncpl_free_value(ptr->val); ptr->val = NULL;
    switch( ptr->type ) {
        case 46: {
            NCPL_RETVAL *rv_46_0 = ncpl_parenexp_visit(p, ptr->u.castexp_46.ncpl_46_0);
            if( rv_46_0==NULL ) return NULL;
            if( rv_46_0->type>=0 ) ptr->line = ptr->u.castexp_46.ncpl_46_0->line;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_46_0->val);
            rv->val = ptr->val;
            rv->type = ptr->retval = rv_46_0->type;
            rv->factor_type = ptr->factor_type = rv_46_0->factor_type;
            rv->factor_str = ptr->factor_str = rv_46_0->factor_str;
            if( rv_46_0!=NULL ) ncpl_free_retval(rv_46_0);
            break;
        }
        case 47: {
            int casttype;
            NCPL_RETVAL *rv_47_0 = ncpl_unary_opr_visit(p, ptr->u.castexp_47.ncpl_47_0);
            if( rv_47_0==NULL ) return NULL;
            if( rv_47_0->type>=0 ) ptr->line = ptr->u.castexp_47.ncpl_47_0->line;
            casttype = rv_47_0->type;
            if( rv_47_0!=NULL ) ncpl_free_retval(rv_47_0);

            NCPL_RETVAL *rv_47_1 = ncpl_parenexp_visit(p, ptr->u.castexp_47.ncpl_47_1);
            if( rv_47_1==NULL ) return NULL;
            if( rv_47_1->type>=0 ) ptr->line = ptr->u.castexp_47.ncpl_47_1->line;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_47_1->val);
            int ret;
            if( casttype==NEGATE ) {
                ret = ncpl_calc_value(p->env.pool, ptr->val, NULL, _N_O_NEGATE);
            } else if( casttype==EXCL ) {
                ret = ncpl_calc_value(p->env.pool, ptr->val, NULL, _N_O_EXCL);
            } else {
                ret = ncpl_calc_value(p->env.pool, ptr->val, NULL, _N_O_SSUB);
            }
            if( ret<0 ) {
                memset(p->log, 0, p->log_len);
                snprintf(p->log, p->log_len, \
                "%s:%d: '!', '~', '-' argument expression type error.", \
                p->pls.file, ptr->line); return NULL;
            }
            rv->val = ptr->val;
            rv->type = ptr->retval = rv_47_1->type;
            rv->factor_type = ptr->factor_type = EXPTYPE;
            if( rv_47_1!=NULL ) ncpl_free_retval(rv_47_1);
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_multiexp_visit(NCPL_PARSER *p, NCPL_multiexp *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    if( ptr->val!=NULL ) ncpl_free_value(ptr->val); ptr->val = NULL;
    switch( ptr->type ) {
        case 48: {
            NCPL_RETVAL *rv_48_0 = ncpl_castexp_visit(p, ptr->u.multiexp_48.ncpl_48_0);
            if( rv_48_0==NULL ) return NULL;
            if( rv_48_0->type>=0 ) ptr->line = ptr->u.multiexp_48.ncpl_48_0->line;
            NCPL_RETVAL *rv_48_1 = ncpl_multiexp_prime_visit(p, ptr->u.multiexp_48.ncpl_48_1);
            if( rv_48_1==NULL ) return NULL;
            if( rv_48_1->type>=0 ) ptr->line = ptr->u.multiexp_48.ncpl_48_1->line;
            int ret, type1 = rv_48_0->type, type2 = rv_48_1->type;
            ptr->val = ncpl_new_value(p->env.pool);
            rv->factor_type = ptr->factor_type = rv_48_0->factor_type;
            rv->factor_str = ptr->factor_str = rv_48_0->factor_str;
            ncpl_equal_value(p->env.pool, ptr->val, rv_48_0->val);
            NCPL_VALUE *srcval = rv_48_1->val;;
            if( rv_48_0!=NULL ) ncpl_free_retval(rv_48_0);
            if( rv_48_1!=NULL ) ncpl_free_retval(rv_48_1);
            if( type2>0 ) {
                if( ncpl_isfile(type1) || ncpl_isstring(type1) ) {
                    memset(p->log, 0, p->log_len);
                    snprintf(p->log, p->log_len, \
                    "%s:%d: '*', '/', '%%' parameter cannot be type 'file' or 'string'.", \
                    p->pls.file, ptr->line); return NULL;
                }
                if( ncpl_isfile(type2) || ncpl_isstring(type2) ) {
                    memset(p->log, 0, p->log_len);
                    snprintf(p->log, p->log_len, \
                    "%s:%d: '*', '/', '%%' parameter cannot be type 'file' or 'string'.", \
                    p->pls.file, ptr->line); return NULL;
                }
                ret = ncpl_calc_type_result(type1, type2);
                if( ret<0 ) {
                    memset(p->log, 0, p->log_len);
                    snprintf(p->log, p->log_len, "%s:%d: type conflict.", p->pls.file, ptr->line);
                    return NULL;
                }
                int retval;
                if( ptr->u.multiexp_48.ncpl_48_1->type==49 ) {
                    retval = ncpl_calc_value(p->env.pool, ptr->val, srcval, _N_O_MUL);
                } else if( ptr->u.multiexp_48.ncpl_48_1->type==50 ) {
                    retval = ncpl_calc_value(p->env.pool, ptr->val, srcval, _N_O_DIV);
                } else {
                    retval = ncpl_calc_value(p->env.pool, ptr->val, srcval, _N_O_PERC);
                }
                if( retval<0 ) {
                    memset(p->log, 0, p->log_len);
                    snprintf(p->log, p->log_len, "%s:%d: '*', '/', '%%' argument expression error.", \
                    p->pls.file, ptr->line); return NULL;
                }
                rv->factor_type = ptr->factor_type = EXPTYPE;
                rv->val = ptr->val; rv->type = ptr->retval = ret; return rv;
            }
            rv->val = ptr->val;
            rv->type = ptr->retval = type1;
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_multiexp_prime_visit(NCPL_PARSER *p, NCPL_multiexp_prime *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    if( ptr->val!=NULL ) ncpl_free_value(ptr->val); ptr->val = NULL;
    switch( ptr->type ) {
        case 49: {
            NCPL_RETVAL *rv_49_0 = ncpl_lex_visit(p, ptr->u.multiexp_prime_49.ncpl_49_0);
            if( rv_49_0==NULL ) return NULL;
            if( rv_49_0->type>=0 ) ptr->line = ptr->u.multiexp_prime_49.ncpl_49_0->line;
            if( rv_49_0!=NULL ) ncpl_free_retval(rv_49_0);
            NCPL_RETVAL *rv_49_1 = ncpl_multiexp_visit(p, ptr->u.multiexp_prime_49.ncpl_49_1);
            if( rv_49_1==NULL ) return NULL;
            if( rv_49_1->type>=0 ) ptr->line = ptr->u.multiexp_prime_49.ncpl_49_1->line;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_49_1->val);
            rv->val = ptr->val;
            rv->type = ptr->retval = rv_49_1->type;
            rv->factor_type = ptr->factor_type = rv_49_1->factor_type;
            rv->factor_str = ptr->factor_str = rv_49_1->factor_str;
            if( rv_49_1!=NULL ) ncpl_free_retval(rv_49_1);
            break;
        }
        case 50: {
            NCPL_RETVAL *rv_50_0 = ncpl_lex_visit(p, ptr->u.multiexp_prime_50.ncpl_50_0);
            if( rv_50_0==NULL ) return NULL;
            if( rv_50_0->type>=0 ) ptr->line = ptr->u.multiexp_prime_50.ncpl_50_0->line;
            if( rv_50_0!=NULL ) ncpl_free_retval(rv_50_0);
            NCPL_RETVAL *rv_50_1 = ncpl_multiexp_visit(p, ptr->u.multiexp_prime_50.ncpl_50_1);
            if( rv_50_1==NULL ) return NULL;
            if( rv_50_1->type>=0 ) ptr->line = ptr->u.multiexp_prime_50.ncpl_50_1->line;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_50_1->val);
            rv->val = ptr->val;
            rv->type = ptr->retval = rv_50_1->type;
            rv->factor_type = ptr->factor_type = rv_50_1->factor_type;
            rv->factor_str = ptr->factor_str = rv_50_1->factor_str;
            if( rv_50_1!=NULL ) ncpl_free_retval(rv_50_1);
            break;
        }
        case 51: {
            NCPL_RETVAL *rv_51_0 = ncpl_lex_visit(p, ptr->u.multiexp_prime_51.ncpl_51_0);
            if( rv_51_0==NULL ) return NULL;
            if( rv_51_0->type>=0 ) ptr->line = ptr->u.multiexp_prime_51.ncpl_51_0->line;
            if( rv_51_0!=NULL ) ncpl_free_retval(rv_51_0);
            NCPL_RETVAL *rv_51_1 = ncpl_multiexp_visit(p, ptr->u.multiexp_prime_51.ncpl_51_1);
            if( rv_51_1==NULL ) return NULL;
            if( rv_51_1->type>=0 ) ptr->line = ptr->u.multiexp_prime_51.ncpl_51_1->line;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_51_1->val);
            rv->val = ptr->val;
            rv->type = ptr->retval = rv_51_1->type;
            rv->factor_type = ptr->factor_type = rv_51_1->factor_type;
            rv->factor_str = ptr->factor_str = rv_51_1->factor_str;
            if( rv_51_1!=NULL ) ncpl_free_retval(rv_51_1);
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_addexp_visit(NCPL_PARSER *p, NCPL_addexp *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    if( ptr->val!=NULL ) ncpl_free_value(ptr->val); ptr->val = NULL;
    int type1, type2;
    switch( ptr->type ) {
        case 53: {
            NCPL_RETVAL *rv_53_0 = ncpl_multiexp_visit(p, ptr->u.addexp_53.ncpl_53_0);
            if( rv_53_0==NULL ) return NULL;
            if( rv_53_0->type>=0 ) ptr->line = ptr->u.addexp_53.ncpl_53_0->line;
            type1 = rv_53_0->type;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_53_0->val);
            rv->factor_type = ptr->factor_type = rv_53_0->factor_type;
            rv->factor_str = ptr->factor_str = rv_53_0->factor_str;
            if( rv_53_0!=NULL ) ncpl_free_retval(rv_53_0);

            NCPL_RETVAL *rv_53_1 = ncpl_addexp_prime_visit(p, ptr->u.addexp_53.ncpl_53_1);
            if( rv_53_1==NULL ) return NULL;
            if( rv_53_1->type>=0 ) ptr->line = ptr->u.addexp_53.ncpl_53_1->line;
            type2 = rv_53_1->type;
            NCPL_VALUE *srcval = rv_53_1->val;
            if( rv_53_1!=NULL ) ncpl_free_retval(rv_53_1);
            if( type2>0 ) {
                if( ncpl_isfile(type1) || ncpl_isfile(type2) ) {
                    memset(p->log, 0, p->log_len);
                    snprintf(p->log, p->log_len, "%s:%d: '+', '-' parameter cannot be type 'file'.", \
                    p->pls.file, ptr->line); return NULL;
                }
                int ret = ncpl_calc_type_result(type1, type2);
                if( ret<0 ) {
                    memset(p->log, 0, p->log_len);
                    snprintf(p->log, p->log_len, "%s:%d: type conflict.", p->pls.file, ptr->line);
                    return NULL;
                }
                int retval;
                if( ptr->u.addexp_53.ncpl_53_1->type==54 ) {
                    retval = ncpl_calc_value(p->env.pool, ptr->val, srcval, _N_O_ADD);
                } else {
                    retval = ncpl_calc_value(p->env.pool, ptr->val, srcval, _N_O_SUB);
                }
                if( retval<0 ) {
                    memset(p->log, 0, p->log_len);
                    snprintf(p->log, p->log_len, "%s:%d: '+', '-' argument expression error.", \
                    p->pls.file, ptr->line); return NULL;
                }
                rv->factor_type = ptr->factor_type = EXPTYPE;
                rv->val = ptr->val; rv->type = ptr->retval = ret; return rv;
            }
            rv->val = ptr->val;
            rv->type = ptr->retval = type1;
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_addexp_prime_visit(NCPL_PARSER *p, NCPL_addexp_prime *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    if( ptr->val!=NULL ) ncpl_free_value(ptr->val); ptr->val = NULL;
    switch( ptr->type ) {
        case 54: {
            NCPL_RETVAL *rv_54_0 = ncpl_lex_visit(p, ptr->u.addexp_prime_54.ncpl_54_0);
            if( rv_54_0==NULL ) return NULL;
            if( rv_54_0->type>=0 ) ptr->line = ptr->u.addexp_prime_54.ncpl_54_0->line;
            if( rv_54_0!=NULL ) ncpl_free_retval(rv_54_0);
            NCPL_RETVAL *rv_54_1 = ncpl_addexp_visit(p, ptr->u.addexp_prime_54.ncpl_54_1);
            if( rv_54_1==NULL ) return NULL;
            if( rv_54_1->type>=0 ) ptr->line = ptr->u.addexp_prime_54.ncpl_54_1->line;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_54_1->val);
            rv->val = ptr->val;
            rv->type = ptr->retval = rv_54_1->type;
            rv->factor_type = ptr->factor_type = rv_54_1->factor_type;
            rv->factor_str = ptr->factor_str = rv_54_1->factor_str;
            if( rv_54_1!=NULL ) ncpl_free_retval(rv_54_1);
            break;
        }
        case 55: {
            NCPL_RETVAL *rv_55_0 = ncpl_lex_visit(p, ptr->u.addexp_prime_55.ncpl_55_0);
            if( rv_55_0==NULL ) return NULL;
            if( rv_55_0->type>=0 ) ptr->line = ptr->u.addexp_prime_55.ncpl_55_0->line;
            if( rv_55_0!=NULL ) ncpl_free_retval(rv_55_0);
            NCPL_RETVAL *rv_55_1 = ncpl_addexp_visit(p, ptr->u.addexp_prime_55.ncpl_55_1);
            if( rv_55_1==NULL ) return NULL;
            if( rv_55_1->type>=0 ) ptr->line = ptr->u.addexp_prime_55.ncpl_55_1->line;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_55_1->val);
            rv->val = ptr->val;
            rv->type = ptr->retval = rv_55_1->type;
            rv->factor_type = ptr->factor_type = rv_55_1->factor_type;
            rv->factor_str = ptr->factor_str = rv_55_1->factor_str;
            if( rv_55_1!=NULL ) ncpl_free_retval(rv_55_1);
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_logicexp_visit(NCPL_PARSER *p, NCPL_logicexp *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    if( ptr->val!=NULL ) ncpl_free_value(ptr->val); ptr->val = NULL;
    int type1, type2;
    switch( ptr->type ) {
        case 57: {
            NCPL_RETVAL *rv_57_0 = ncpl_addexp_visit(p, ptr->u.logicexp_57.ncpl_57_0);
            if( rv_57_0==NULL ) return NULL;
            if( rv_57_0->type>=0 ) ptr->line = ptr->u.logicexp_57.ncpl_57_0->line;
            type1 = rv_57_0->type;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_57_0->val);
            rv->factor_type = ptr->factor_type = rv_57_0->factor_type;
            rv->factor_str = ptr->factor_str = rv_57_0->factor_str;
            if( rv_57_0!=NULL ) ncpl_free_retval(rv_57_0);

            NCPL_RETVAL *rv_57_1 = ncpl_logic_prime_visit(p, ptr->u.logicexp_57.ncpl_57_1);
            if( rv_57_1==NULL ) return NULL;
            if( rv_57_1->type>=0 ) ptr->line = ptr->u.logicexp_57.ncpl_57_1->line;
            NCPL_VALUE *srcval = rv_57_1->val;
            type2 = rv_57_1->type;
            if( rv_57_1!=NULL ) ncpl_free_retval(rv_57_1);

            if( type2>0 ) {
                if( ncpl_isfile(type1) || ncpl_isstring(type1) || ncpl_isfloat(type1) ) {
                    memset(p->log, 0, p->log_len);
                    snprintf(p->log, p->log_len, \
                    "%s:%d: '^', '&', '|' parameter cannot be type 'file', 'string' or 'float'.", \
                    p->pls.file, ptr->line); return NULL;
                }
                if( ncpl_isfile(type2) || ncpl_isstring(type2) || ncpl_isfloat(type2) ) {
                    memset(p->log, 0, p->log_len);
                    snprintf(p->log, p->log_len, \
                    "%s:%d: '^', '&', '|' parameter cannot be type 'file', 'string' or 'float'.", \
                    p->pls.file, ptr->line); return NULL;
                }
                int ret = ncpl_calc_type_result(type1, type2);
                if( ret<0 ) {
                    memset(p->log, 0, p->log_len);
                    snprintf(p->log, p->log_len, "%s:%d: type conflict.", p->pls.file, ptr->line);
                    return NULL;
                }
                int retval;
                if( ptr->u.logicexp_57.ncpl_57_1->type==58 ) {
                    retval = ncpl_calc_value(p->env.pool, ptr->val, srcval, _N_O_XOR);
                } else if( ptr->u.logicexp_57.ncpl_57_1->type==59 ) {
                    retval = ncpl_calc_value(p->env.pool, ptr->val, srcval, _N_O_AND);
                } else {
                    retval = ncpl_calc_value(p->env.pool, ptr->val, srcval, _N_O_OR);
                }
                if( retval<0 ) {
                    memset(p->log, 0, p->log_len);
                    snprintf(p->log, p->log_len, "%s:%d: '^', '&', '|' argument expression error.", \
                    p->pls.file, ptr->line); return NULL;
                }
                rv->factor_type = ptr->factor_type = EXPTYPE;
                rv->val = ptr->val; rv->type = ptr->retval = ret; return rv;
            }
            rv->val = ptr->val;
            rv->type = ptr->retval = type1;
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_logic_prime_visit(NCPL_PARSER *p, NCPL_logic_prime *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    if( ptr->val!=NULL ) ncpl_free_value(ptr->val); ptr->val = NULL;
    switch( ptr->type ) {
        case 58: {
            NCPL_RETVAL *rv_58_0 = ncpl_lex_visit(p, ptr->u.logic_prime_58.ncpl_58_0);
            if( rv_58_0==NULL ) return NULL;
            if( rv_58_0->type>=0 ) ptr->line = ptr->u.logic_prime_58.ncpl_58_0->line;
            if( rv_58_0!=NULL ) ncpl_free_retval(rv_58_0);
            NCPL_RETVAL *rv_58_1 = ncpl_logicexp_visit(p, ptr->u.logic_prime_58.ncpl_58_1);
            if( rv_58_1==NULL ) return NULL;
            if( rv_58_1->type>=0 ) ptr->line = ptr->u.logic_prime_58.ncpl_58_1->line;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_58_1->val);
            rv->val = ptr->val;
            rv->type = ptr->retval = rv_58_1->type;
            rv->factor_type = ptr->factor_type = rv_58_1->factor_type;
            rv->factor_str = ptr->factor_str = rv_58_1->factor_str;
            if( rv_58_1!=NULL ) ncpl_free_retval(rv_58_1);
            break;
        }
        case 59: {
            NCPL_RETVAL *rv_59_0 = ncpl_lex_visit(p, ptr->u.logic_prime_59.ncpl_59_0);
            if( rv_59_0==NULL ) return NULL;
            if( rv_59_0->type>=0 ) ptr->line = ptr->u.logic_prime_59.ncpl_59_0->line;
            if( rv_59_0!=NULL ) ncpl_free_retval(rv_59_0);
            NCPL_RETVAL *rv_59_1 = ncpl_logicexp_visit(p, ptr->u.logic_prime_59.ncpl_59_1);
            if( rv_59_1==NULL ) return NULL;
            if( rv_59_1->type>=0 ) ptr->line = ptr->u.logic_prime_59.ncpl_59_1->line;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_59_1->val);
            rv->val = ptr->val;
            rv->type = ptr->retval = rv_59_1->type;
            rv->factor_type = ptr->factor_type = rv_59_1->factor_type;
            rv->factor_str = ptr->factor_str = rv_59_1->factor_str;
            if( rv_59_1!=NULL ) ncpl_free_retval(rv_59_1);
            break;
        }
        case 60: {
            NCPL_RETVAL *rv_60_0 = ncpl_lex_visit(p, ptr->u.logic_prime_60.ncpl_60_0);
            if( rv_60_0==NULL ) return NULL;
            if( rv_60_0->type>=0 ) ptr->line = ptr->u.logic_prime_60.ncpl_60_0->line;
            if( rv_60_0!=NULL ) ncpl_free_retval(rv_60_0);
            NCPL_RETVAL *rv_60_1 = ncpl_logicexp_visit(p, ptr->u.logic_prime_60.ncpl_60_1);
            if( rv_60_1==NULL ) return NULL;
            if( rv_60_1->type>=0 ) ptr->line = ptr->u.logic_prime_60.ncpl_60_1->line;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_60_1->val);
            rv->val = ptr->val;
            rv->type = ptr->retval = rv_60_1->type;
            rv->factor_type = ptr->factor_type = rv_60_1->factor_type;
            rv->factor_str = ptr->factor_str = rv_60_1->factor_str;
            if( rv_60_1!=NULL ) ncpl_free_retval(rv_60_1);
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_relatexp_visit(NCPL_PARSER *p, NCPL_relatexp *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    if( ptr->val!=NULL ) ncpl_free_value(ptr->val); ptr->val = NULL;
    int type1, type2;
    switch( ptr->type ) {
        case 62: {
            NCPL_RETVAL *rv_62_0 = ncpl_logicexp_visit(p, ptr->u.relatexp_62.ncpl_62_0);
            if( rv_62_0==NULL ) return NULL;
            if( rv_62_0->type>=0 ) ptr->line = ptr->u.relatexp_62.ncpl_62_0->line;
            type1 = rv_62_0->type;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_62_0->val);
            rv->factor_type = ptr->factor_type = rv_62_0->factor_type;
            rv->factor_str = ptr->factor_str = rv_62_0->factor_str;
            if( rv_62_0!=NULL ) ncpl_free_retval(rv_62_0);

            NCPL_RETVAL *rv_62_1 = ncpl_relatexp_prime_visit(p, ptr->u.relatexp_62.ncpl_62_1);
            if( rv_62_1==NULL ) return NULL;
            if( rv_62_1->type>=0 ) ptr->line = ptr->u.relatexp_62.ncpl_62_1->line;
            type2 = rv_62_1->type;
            NCPL_VALUE *srcval = rv_62_1->val;
            if( rv_62_1!=NULL ) ncpl_free_retval(rv_62_1);

            if( type2>0 ) {
                if( (ncpl_isfile(type1) || ncpl_isfile(type2)) ) {
                    int opr_type = ptr->u.relatexp_62.ncpl_62_1->type;
                    if( opr_type!=65 && opr_type!=66 ) {
                        memset(p->log, 0, p->log_len);
                        snprintf(p->log, p->log_len, "%s:%d: '&&', '||', '!=', \
'==', '>', '<', '>=', '<=' parameter cannot be type 'file'.", \
                        p->pls.file, ptr->line); return NULL;
                    }
                }
                int ret = ncpl_calc_type_result(type1, type2);
                if( ret<0 ) {
                    memset(p->log, 0, p->log_len);
                    snprintf(p->log, p->log_len, "%s:%d: type conflict.", p->pls.file, ptr->line);
                    return NULL;
                }
                int retval;
                if( ptr->u.relatexp_62.ncpl_62_1->type==63 ) {
                    retval = ncpl_calc_value(p->env.pool, ptr->val, srcval, _N_O_RAND);
                } else if( ptr->u.relatexp_62.ncpl_62_1->type==64 ) {
                    retval = ncpl_calc_value(p->env.pool, ptr->val, srcval, _N_O_ROR);
                } else if( ptr->u.relatexp_62.ncpl_62_1->type==65 ) {
                    retval = ncpl_calc_value(p->env.pool, ptr->val, srcval, _N_O_NEQUAL);
                } else if( ptr->u.relatexp_62.ncpl_62_1->type==66 ) {
                    retval = ncpl_calc_value(p->env.pool, ptr->val, srcval, _N_O_EQUAL);
                } else if( ptr->u.relatexp_62.ncpl_62_1->type==67 ) {
                    retval = ncpl_calc_value(p->env.pool, ptr->val, srcval, _N_O_LESS);
                } else if( ptr->u.relatexp_62.ncpl_62_1->type==68 ) {
                    retval = ncpl_calc_value(p->env.pool, ptr->val, srcval, _N_O_GREA);
                } else if( ptr->u.relatexp_62.ncpl_62_1->type==69 ) {
                    retval = ncpl_calc_value(p->env.pool, ptr->val, srcval, _N_O_GEQUAL);
                } else {
                    retval = ncpl_calc_value(p->env.pool, ptr->val, srcval, _N_O_LEQUAL);
                }
                if( retval<0 ) {
                    memset(p->log, 0, p->log_len);
                    snprintf(p->log, p->log_len, \
                    "%s:%d: '&&', '||', '!=', '==', '<', '>', '<=', '>=' argument expression error.", \
                    p->pls.file, ptr->line); return NULL;
                }
                rv->factor_type = ptr->factor_type = EXPTYPE;
                rv->val = ptr->val; rv->type = ptr->retval = ret; return rv;
            }
            rv->val = ptr->val;
            rv->type = ptr->retval = type1;
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_relatexp_prime_visit(NCPL_PARSER *p, NCPL_relatexp_prime *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    if( ptr->val!=NULL ) ncpl_free_value(ptr->val); ptr->val = NULL;
    switch( ptr->type ) {
        case 63: {
            NCPL_RETVAL *rv_63_0 = ncpl_lex_visit(p, ptr->u.relatexp_prime_63.ncpl_63_0);
            if( rv_63_0==NULL ) return NULL;
            if( rv_63_0->type>=0 ) ptr->line = ptr->u.relatexp_prime_63.ncpl_63_0->line;
            if( rv_63_0!=NULL ) ncpl_free_retval(rv_63_0);
            NCPL_RETVAL *rv_63_1 = ncpl_relatexp_visit(p, ptr->u.relatexp_prime_63.ncpl_63_1);
            if( rv_63_1==NULL ) return NULL;
            if( rv_63_1->type>=0 ) ptr->line = ptr->u.relatexp_prime_63.ncpl_63_1->line;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_63_1->val);
            rv->val = ptr->val;
            rv->type = ptr->retval = rv_63_1->type;
            rv->factor_type = ptr->factor_type = rv_63_1->factor_type;
            rv->factor_str = ptr->factor_str = rv_63_1->factor_str;
            if( rv_63_1!=NULL ) ncpl_free_retval(rv_63_1);
            break;
        }
        case 64: {
            NCPL_RETVAL *rv_64_0 = ncpl_lex_visit(p, ptr->u.relatexp_prime_64.ncpl_64_0);
            if( rv_64_0==NULL ) return NULL;
            if( rv_64_0->type>=0 ) ptr->line = ptr->u.relatexp_prime_64.ncpl_64_0->line;
            if( rv_64_0!=NULL ) ncpl_free_retval(rv_64_0);
            NCPL_RETVAL *rv_64_1 = ncpl_relatexp_visit(p, ptr->u.relatexp_prime_64.ncpl_64_1);
            if( rv_64_1==NULL ) return NULL;
            if( rv_64_1->type>=0 ) ptr->line = ptr->u.relatexp_prime_64.ncpl_64_1->line;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_64_1->val);
            rv->val = ptr->val;
            rv->type = ptr->retval = rv_64_1->type;
            rv->factor_type = ptr->factor_type = rv_64_1->factor_type;
            rv->factor_str = ptr->factor_str = rv_64_1->factor_str;
            if( rv_64_1!=NULL ) ncpl_free_retval(rv_64_1);
            break;
        }
        case 65: {
            NCPL_RETVAL *rv_65_0 = ncpl_lex_visit(p, ptr->u.relatexp_prime_65.ncpl_65_0);
            if( rv_65_0==NULL ) return NULL;
            if( rv_65_0->type>=0 ) ptr->line = ptr->u.relatexp_prime_65.ncpl_65_0->line;
            if( rv_65_0!=NULL ) ncpl_free_retval(rv_65_0);
            NCPL_RETVAL *rv_65_1 = ncpl_relatexp_visit(p, ptr->u.relatexp_prime_65.ncpl_65_1);
            if( rv_65_1==NULL ) return NULL;
            if( rv_65_1->type>=0 ) ptr->line = ptr->u.relatexp_prime_65.ncpl_65_1->line;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_65_1->val);
            rv->val = ptr->val;
            rv->type = ptr->retval = rv_65_1->type;
            rv->factor_type = ptr->factor_type = rv_65_1->factor_type;
            rv->factor_str = ptr->factor_str = rv_65_1->factor_str;
            if( rv_65_1!=NULL ) ncpl_free_retval(rv_65_1);
            break;
        }
        case 66: {
            NCPL_RETVAL *rv_66_0 = ncpl_lex_visit(p, ptr->u.relatexp_prime_66.ncpl_66_0);
            if( rv_66_0==NULL ) return NULL;
            if( rv_66_0->type>=0 ) ptr->line = ptr->u.relatexp_prime_66.ncpl_66_0->line;
            if( rv_66_0!=NULL ) ncpl_free_retval(rv_66_0);
            NCPL_RETVAL *rv_66_1 = ncpl_relatexp_visit(p, ptr->u.relatexp_prime_66.ncpl_66_1);
            if( rv_66_1==NULL ) return NULL;
            if( rv_66_1->type>=0 ) ptr->line = ptr->u.relatexp_prime_66.ncpl_66_1->line;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_66_1->val);
            rv->val = ptr->val;
            rv->type = ptr->retval = rv_66_1->type;
            rv->factor_type = ptr->factor_type = rv_66_1->factor_type;
            rv->factor_str = ptr->factor_str = rv_66_1->factor_str;
            if( rv_66_1!=NULL ) ncpl_free_retval(rv_66_1);
            break;
        }
        case 67: {
            NCPL_RETVAL *rv_67_0 = ncpl_lex_visit(p, ptr->u.relatexp_prime_67.ncpl_67_0);
            if( rv_67_0==NULL ) return NULL;
            if( rv_67_0->type>=0 ) ptr->line = ptr->u.relatexp_prime_67.ncpl_67_0->line;
            if( rv_67_0!=NULL ) ncpl_free_retval(rv_67_0);
            NCPL_RETVAL *rv_67_1 = ncpl_relatexp_visit(p, ptr->u.relatexp_prime_67.ncpl_67_1);
            if( rv_67_1==NULL ) return NULL;
            if( rv_67_1->type>=0 ) ptr->line = ptr->u.relatexp_prime_67.ncpl_67_1->line;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_67_1->val);
            rv->val = ptr->val;
            rv->type = ptr->retval = rv_67_1->type;
            rv->factor_type = ptr->factor_type = rv_67_1->factor_type;
            rv->factor_str = ptr->factor_str = rv_67_1->factor_str;
            if( rv_67_1!=NULL ) ncpl_free_retval(rv_67_1);
            break;
        }
        case 68: {
            NCPL_RETVAL *rv_68_0 = ncpl_lex_visit(p, ptr->u.relatexp_prime_68.ncpl_68_0);
            if( rv_68_0==NULL ) return NULL;
            if( rv_68_0->type>=0 ) ptr->line = ptr->u.relatexp_prime_68.ncpl_68_0->line;
            if( rv_68_0!=NULL ) ncpl_free_retval(rv_68_0);
            NCPL_RETVAL *rv_68_1 = ncpl_relatexp_visit(p, ptr->u.relatexp_prime_68.ncpl_68_1);
            if( rv_68_1==NULL ) return NULL;
            if( rv_68_1->type>=0 ) ptr->line = ptr->u.relatexp_prime_68.ncpl_68_1->line;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_68_1->val);
            rv->val = ptr->val;
            rv->type = ptr->retval = rv_68_1->type;
            rv->factor_type = ptr->factor_type = rv_68_1->factor_type;
            rv->factor_str = ptr->factor_str = rv_68_1->factor_str;
            if( rv_68_1!=NULL ) ncpl_free_retval(rv_68_1);
            break;
        }
        case 69: {
            NCPL_RETVAL *rv_69_0 = ncpl_lex_visit(p, ptr->u.relatexp_prime_69.ncpl_69_0);
            if( rv_69_0==NULL ) return NULL;
            if( rv_69_0->type>=0 ) ptr->line = ptr->u.relatexp_prime_69.ncpl_69_0->line;
            if( rv_69_0!=NULL ) ncpl_free_retval(rv_69_0);
            NCPL_RETVAL *rv_69_1 = ncpl_relatexp_visit(p, ptr->u.relatexp_prime_69.ncpl_69_1);
            if( rv_69_1==NULL ) return NULL;
            if( rv_69_1->type>=0 ) ptr->line = ptr->u.relatexp_prime_69.ncpl_69_1->line;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_69_1->val);
            rv->val = ptr->val;
            rv->type = ptr->retval = rv_69_1->type;
            rv->factor_type = ptr->factor_type = rv_69_1->factor_type;
            rv->factor_str = ptr->factor_str = rv_69_1->factor_str;
            if( rv_69_1!=NULL ) ncpl_free_retval(rv_69_1);
            break;
        }
        case 70: {
            NCPL_RETVAL *rv_70_0 = ncpl_lex_visit(p, ptr->u.relatexp_prime_70.ncpl_70_0);
            if( rv_70_0==NULL ) return NULL;
            if( rv_70_0->type>=0 ) ptr->line = ptr->u.relatexp_prime_70.ncpl_70_0->line;
            if( rv_70_0!=NULL ) ncpl_free_retval(rv_70_0);
            NCPL_RETVAL *rv_70_1 = ncpl_relatexp_visit(p, ptr->u.relatexp_prime_70.ncpl_70_1);
            if( rv_70_1==NULL ) return NULL;
            if( rv_70_1->type>=0 ) ptr->line = ptr->u.relatexp_prime_70.ncpl_70_1->line;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_70_1->val);
            rv->val = ptr->val;
            rv->type = ptr->retval = rv_70_1->type;
            rv->factor_type = ptr->factor_type = rv_70_1->factor_type;
            rv->factor_str = ptr->factor_str = rv_70_1->factor_str;
            if( rv_70_1!=NULL ) ncpl_free_retval(rv_70_1);
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_assignexp_visit(NCPL_PARSER *p, NCPL_assignexp *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    if( ptr->val!=NULL ) ncpl_free_value(ptr->val); ptr->val = NULL;
    int type1, type2;
    switch( ptr->type ) {
        case 72: {
            NCPL_RETVAL *rv_72_0 = ncpl_relatexp_visit(p, ptr->u.assignexp_72.ncpl_72_0);
            if( rv_72_0==NULL ) return NULL;
            if( rv_72_0->type>=0 ) ptr->line = ptr->u.assignexp_72.ncpl_72_0->line;
            type1 = rv_72_0->type;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_72_0->val);
            rv->factor_type = ptr->factor_type = rv_72_0->factor_type;
            rv->factor_str = ptr->factor_str = rv_72_0->factor_str;
            if( rv_72_0!=NULL ) ncpl_free_retval(rv_72_0);

            NCPL_RETVAL *rv_72_1 = ncpl_assignexp_prime_visit(p, ptr->u.assignexp_72.ncpl_72_1);
            if( rv_72_1==NULL ) return NULL;
            if( rv_72_1->type>=0 ) ptr->line = ptr->u.assignexp_72.ncpl_72_1->line;
            NCPL_VALUE *srcval = rv_72_1->val;
            type2 = rv_72_1->type;
            if( rv_72_1!=NULL ) ncpl_free_retval(rv_72_1);

            if( type2>0 ) {
                int ret = ncpl_type_legal(type1, type2);
                if( ret<0 ) {
                    memset(p->log, 0, p->log_len);
                    snprintf(p->log, p->log_len, "%s:%d: type conflict.", p->pls.file, ptr->line);
                    return NULL;
                }
                if( rv->factor_type==ID ) {
                    NCPL_SYM *sym = ncpl_get_sym(&(p->env), rv->factor_str);
                    if( sym==NULL ) {
err:                    memset(p->log, 0, p->log_len);
                        snprintf(p->log, p->log_len, "%s:%d: No such symbol '%s'.", \
                        p->pls.file, ptr->line, rv->factor_str); return NULL;
                    }
                    NCPL_ENVVAR *var = ncpl_get_var(&(p->env), sym);
                    if( var==NULL ) goto err;
                    int retval = ncpl_calc_value(p->env.pool, var->val, srcval, _N_O_EQ);
                    if( retval<0 ) {
                        memset(p->log, 0, p->log_len);
                        snprintf(p->log, p->log_len, "%s:%d: '=' argument expression error.", \
                        p->pls.file, ptr->line); return NULL;
                    }
                    ncpl_equal_value(p->env.pool, ptr->val, var->val);
                } else {
                    int retval = ncpl_calc_value(p->env.pool, ptr->val, srcval, _N_O_EQ);
                    if( retval<0 ) {
                        memset(p->log, 0, p->log_len);
                        snprintf(p->log, p->log_len, "%s:%d: '=' argument expression error.", \
                        p->pls.file, ptr->line); return NULL;
                    }
                }
                rv->val = ptr->val; rv->type = ptr->retval = ret; return rv;
            }
            rv->val = ptr->val; rv->type = ptr->retval = type1;
            rv->factor_type = ptr->factor_type = EXPTYPE;
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

NCPL_RETVAL *ncpl_assignexp_prime_visit(NCPL_PARSER *p, NCPL_assignexp_prime *ptr)
{
    NCPL_RETVAL *rv = ncpl_new_retval(p);
    if( ptr==NULL ) { rv->type = -1; return rv;}
    if( ptr->val!=NULL ) ncpl_free_value(ptr->val); ptr->val = NULL;
    switch( ptr->type ) {
        case 73: {
            NCPL_RETVAL *rv_73_0 = ncpl_lex_visit(p, ptr->u.assignexp_prime_73.ncpl_73_0);
            if( rv_73_0==NULL ) return NULL;
            if( rv_73_0->type>=0 ) ptr->line = ptr->u.assignexp_prime_73.ncpl_73_0->line;
            if( rv_73_0!=NULL ) ncpl_free_retval(rv_73_0);
            NCPL_RETVAL *rv_73_1 = ncpl_assignexp_visit(p, ptr->u.assignexp_prime_73.ncpl_73_1);
            if( rv_73_1==NULL ) return NULL;
            if( rv_73_1->type>=0 ) ptr->line = ptr->u.assignexp_prime_73.ncpl_73_1->line;
            ptr->val = ncpl_new_value(p->env.pool);
            ncpl_equal_value(p->env.pool, ptr->val, rv_73_1->val);
            rv->val = ptr->val;
            rv->type = ptr->retval = rv_73_1->type;
            rv->factor_type = ptr->factor_type = rv_73_1->factor_type;
            rv->factor_str = ptr->factor_str = rv_73_1->factor_str;
            if( rv_73_1!=NULL ) ncpl_free_retval(rv_73_1);
            break;
        }
        default: fprintf(stdout, "%s(): fatal error.\n", __FUNCTION__); exit(1);
    }
    return rv;
}

int ncpl_visit(NCPL_PARSER *p)
{
    if( !(p->pass_tychk) ) {
        ncpl_push_query(p);
        ncpl_push_fopen(p);
        ncpl_push_fclose(p);
        ncpl_push_print(p);
    }
    NCPL_RETVAL *rv = ncpl_start_visit(p, p->ptr);
    if( rv==NULL ) return -1; ncpl_free_retval(rv); return 0;
}

/*push functions env*/
static void ncpl_push_query(NCPL_PARSER *p)
{
    NCPL_SYM *sym = ncpl_get_sym(&(p->env), query_str);
    if( sym==NULL ) sym = ncpl_new_sym(&(p->env), query_str);
    NCPL_ENVTY *retty = ncpl_create_envty(&(p->env), INT, sym);
    NCPL_ENVTYLIST *tylist = ncpl_create_envtylist(&(p->env), \
                         ncpl_create_envty(&(p->env), STR, NULL));
    ncpl_push_new_function(&(p->env), query_str, retty, tylist);
}

static void ncpl_push_fopen(NCPL_PARSER *p)
{
    NCPL_SYM *sym = ncpl_get_sym(&(p->env), fopen_str);
    if( sym==NULL ) sym = ncpl_new_sym(&(p->env), fopen_str);
    NCPL_ENVTY *retty = ncpl_create_envty(&(p->env), FFILE, sym);
    NCPL_ENVTYLIST *tylist = ncpl_create_envtylist(&(p->env), \
                         ncpl_create_envty(&(p->env), STR, NULL));
    ncpl_push_new_function(&(p->env), fopen_str, retty, tylist);
}

static void ncpl_push_fclose(NCPL_PARSER *p)
{
    NCPL_SYM *sym = ncpl_get_sym(&(p->env), fclose_str);
    if( sym==NULL ) sym = ncpl_new_sym(&(p->env), fclose_str);
    NCPL_ENVTY *retty = ncpl_create_envty(&(p->env), VOID, sym);
    NCPL_ENVTYLIST *tylist = ncpl_create_envtylist(&(p->env), \
                         ncpl_create_envty(&(p->env), FFILE, NULL));
    ncpl_push_new_function(&(p->env), fclose_str, retty, tylist);
}

static void ncpl_push_print(NCPL_PARSER *p)
{
    NCPL_SYM *sym = ncpl_get_sym(&(p->env), print_str);
    if( sym==NULL ) sym = ncpl_new_sym(&(p->env), print_str);
    NCPL_ENVTY *retty = ncpl_create_envty(&(p->env), STR, sym);
    NCPL_ENVTYLIST *tylist = ncpl_create_envtylist(&(p->env), \
                         ncpl_create_envty(&(p->env), STR, NULL));
    ncpl_push_new_function(&(p->env), print_str, retty, tylist);
}

/*---------------NCPL_FD-------------------------------*/
NCPL_FD *ncpl_new_fd(niffic_pool_t *pool, int fd)
{
    NCPL_FD *f = (NCPL_FD *)niffic_alloc(pool, sizeof(NCPL_FD));
    assert(f);
    f->fd = fd;
    return f;
}

void ncpl_free_fd(NCPL_FD *f, int need_close)
{
    if( need_close ) close(f->fd);
    niffic_free(f);
}

void ncpl_add_fd(NCPL_FD *f, NCPL_FD **tbl)
{
    int hash = f->fd%FDHASH;
    if( tbl[hash]==NULL ) tbl[hash] = f;
    else {
        f->next = tbl[hash];
        (tbl[hash])->prev = f;
        tbl[hash] = f;
    }
}

void ncpl_del_fd(NCPL_FD *f, NCPL_FD **tbl)
{
    int hash = f->fd%FDHASH;
    if( f==tbl[hash] ) {
        tbl[hash] = f->next;
        if( f->next!=NULL ) f->next->prev = NULL;
    } else {
        f->prev->next = f->next;
        if( f->next!=NULL ) f->next->prev = f->prev;
    }
    f->next = f->prev = NULL;
}

void ncpl_close_all_fd(NCPL_FD **tbl)
{
    int i;
    NCPL_FD *f, *fr;
    for(i = 0; i<FDHASH; i++) {
        f = tbl[i];
        while( f!=NULL ) {
            fr = f; f = f->next;
            ncpl_free_fd(fr, 1);
        }
        tbl[i] = NULL;
    }
}

NCPL_FD *ncpl_get_fd(int fd, NCPL_FD **tbl)
{
    int hash = fd%FDHASH;
    NCPL_FD *f = tbl[hash];
    for(; f!=NULL; f = f->next) {
        if( f->fd==fd ) return f;
    }
    return NULL;
}

