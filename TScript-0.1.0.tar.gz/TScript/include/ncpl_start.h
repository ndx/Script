/*
 * Copyright (C) Niklaus F.Schen.
 */

#ifndef __NCPL_START
#define __NCPL_START

extern int ncpl_script(char *sfile, char *buf, int len);

#endif

