/*
 * Copyright (C) Niklaus F.Schen.
 */

#ifndef __NCPL_VALUE_H
#define __NCPL_VALUE_H

#include"niffic_alloc.h"

#define _N_V_BUFLEN 1024
#define _N_V_ERRLEN 64

typedef struct {
    char *s;
    int len;
}NCPL_STRING_VALUE;

typedef struct {
    int fd;
    int status;
    int rd_pos;
    int wr_pos;
    int rd_sum;
    char *rd_buf;
    char *wr_buf;
}NCPL_FILE_VALUE;

/*NCPL_NUMERIC*/
#define _N_V_SHORT 1
#define _N_V_INT 2
#define _N_V_LONG 3
#define _N_V_FLOAT 4
#define _N_V_CHAR 5
#define _N_V_STRING 6
#define _N_V_FILE 7
typedef struct {
    int type;
    union {
        short sh;
        int i;
#ifdef __x86_64
        long l;
#else
        long long l;
#endif
        float f;
        char c;
        NCPL_STRING_VALUE s;
        NCPL_FILE_VALUE file;
    }u;
}NCPL_NUMERIC;

/*NCPL_VALUE*/
#define _N_NONE 0
#define _N_NUMERIC 1
#define _N_CONTROL 2
/*ctl*/
#define _N_C_BREAK 1
#define _N_C_CONTINUE 2
typedef struct {
    int type;
    union {
        int ctl;
        NCPL_NUMERIC num;
    }u;
}NCPL_VALUE;

/*operator types*/
#define _N_O_NEGATE 0
#define _N_O_EXCL 1
#define _N_O_SSUB 2
#define _N_O_MUL 3
#define _N_O_DIV 4
#define _N_O_PERC 5
#define _N_O_ADD 6
#define _N_O_SUB 7
#define _N_O_XOR 8
#define _N_O_AND 9
#define _N_O_OR 10
#define _N_O_RAND 11
#define _N_O_ROR 12
#define _N_O_NEQUAL 13
#define _N_O_EQUAL 14
#define _N_O_LESS 15
#define _N_O_GREA 16
#define _N_O_GEQUAL 17
#define _N_O_LEQUAL 18
#define _N_O_EQ 19
#define OPR_TYPE_TBLLEN 20
typedef int (*NCPL_OPR_VALUE)(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);

/*error*/
#define E_N_PRM_TYPE -1
#define E_N_END_FILE -2
#define E_N_INVALID_TYPE -3
#define E_N_FILE_FMT -4
#define E_N_STR_FMT -5
#define E_N_READ_FILE -6

extern NCPL_VALUE *ncpl_new_value(niffic_pool_t *pool);
extern void ncpl_free_value(NCPL_VALUE *v);
extern void ncpl_assign_value(niffic_pool_t *pool, NCPL_VALUE *v, int ntype, int vtype, void *val);
extern void ncpl_equal_value(niffic_pool_t *pool, NCPL_VALUE *left, NCPL_VALUE *right);
extern int ncpl_value_istrue(NCPL_VALUE *val);
extern int ncpl_calc_value(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src, int ctype);
extern void ncpl_print_value(NCPL_VALUE *v);
extern int ncpl_value_file_open(niffic_pool_t *pool, NCPL_VALUE *ret, NCPL_VALUE *param);
extern void ncpl_value_file_close(niffic_pool_t *pool, NCPL_VALUE *v);
extern int ncpl_get_file_desc(NCPL_VALUE *v);
extern char ncpl_get_char_value(NCPL_VALUE *v, int *error);
#ifdef __x86_64
extern long ncpl_get_integer_value(NCPL_VALUE *v, int *error);
#else
extern long long ncpl_get_integer_value(NCPL_VALUE *v, int *error);
#endif
extern float ncpl_get_float_value(NCPL_VALUE *v, int *error);
extern char *ncpl_get_string_value(NCPL_VALUE *v, int *error);
extern char *ncpl_value_strerror(int err);

#endif

