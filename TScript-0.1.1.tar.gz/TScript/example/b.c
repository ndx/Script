file fp = fopen("ddd");
print("%f\n", fp);
fclose(fp);
