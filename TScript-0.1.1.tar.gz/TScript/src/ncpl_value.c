/*
 * Copyright (C) Niklaus F.Schen.
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<assert.h>
#include<unistd.h>
#include<errno.h>
#include<fcntl.h>
#include"ncpl_value.h"
#include"ncpl_tool.h"

static void ncpl_assign_value_numeric(niffic_pool_t *pool, NCPL_VALUE *v, void *val);

static int ncpl_calc_value_negate(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_excl(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_ssub(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
/*mul*/
static int ncpl_calc_value_mul(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_mul_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_mul_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_mul_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_mul_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_mul_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
/*div*/
static int ncpl_calc_value_div(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_div_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_div_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_div_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_div_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_div_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
/*perc*/
static int ncpl_calc_value_perc(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_perc_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_perc_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_perc_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_perc_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
/*add*/
static int ncpl_calc_value_add(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_add_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_add_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_add_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_add_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_add_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_add_string(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
/*sub*/
static int ncpl_calc_value_sub(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_sub_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_sub_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_sub_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_sub_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_sub_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_sub_string(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
/*xor*/
static int ncpl_calc_value_xor(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_xor_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_xor_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_xor_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_xor_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
/*and*/
static int ncpl_calc_value_and(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_and_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_and_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_and_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_and_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
/*or*/
static int ncpl_calc_value_or(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_or_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_or_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_or_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_or_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
/*rand*/
static int ncpl_calc_value_rand(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_rand_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_rand_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_rand_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_rand_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_rand_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_rand_string(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
/*ror*/
static int ncpl_calc_value_ror(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_ror_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_ror_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_ror_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_ror_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_ror_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_ror_string(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
/*nequal*/
static int ncpl_calc_value_NEQUAL(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_nequal_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_nequal_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_nequal_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_nequal_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_nequal_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_nequal_string(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_nequal_file(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
/*equal*/
static int ncpl_calc_value_EQUAL(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_equal_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_equal_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_equal_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_equal_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_equal_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_equal_string(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_equal_file(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
/*less*/
static int ncpl_calc_value_LESS(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_less_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_less_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_less_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_less_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_less_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_less_string(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
/*grea*/
static int ncpl_calc_value_GREA(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_grea_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_grea_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_grea_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_grea_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_grea_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_grea_string(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
/*gequal*/
static int ncpl_calc_value_GEQUAL(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_gequal_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_gequal_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_gequal_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_gequal_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_gequal_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_gequal_string(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
/*lequal*/
static int ncpl_calc_value_LEQUAL(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_lequal_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_lequal_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_lequal_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_lequal_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_lequal_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_lequal_string(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
/*eq*/
static int ncpl_calc_value_EQ(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_eq_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_eq_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_eq_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_eq_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_eq_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_eq_string(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
static int ncpl_calc_value_eq_file(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src);
/*get_value*/

NCPL_OPR_VALUE opr_value_tbl[OPR_TYPE_TBLLEN] = {
ncpl_calc_value_negate, ncpl_calc_value_excl,\
ncpl_calc_value_ssub, ncpl_calc_value_mul,\
ncpl_calc_value_div, ncpl_calc_value_perc,\
ncpl_calc_value_add, ncpl_calc_value_sub,\
ncpl_calc_value_xor, ncpl_calc_value_and,\
ncpl_calc_value_or, ncpl_calc_value_rand,\
ncpl_calc_value_ror, ncpl_calc_value_NEQUAL,\
ncpl_calc_value_EQUAL, ncpl_calc_value_LESS,\
ncpl_calc_value_GREA, ncpl_calc_value_GEQUAL,\
ncpl_calc_value_LEQUAL, ncpl_calc_value_EQ
};

/*error*/
char err_tbl[][_N_V_ERRLEN] = {
"Parameter type error.",
"End of file.",
"Invalid type.",
"File format error.",
"String format error.",
"Read file error."
};
char noerr[] = "Succeed.";

NCPL_VALUE *ncpl_new_value(niffic_pool_t *pool)
{
    NCPL_VALUE *v = (NCPL_VALUE *)niffic_alloc(pool, sizeof(NCPL_VALUE));
    assert(v);
    return v;
}

void ncpl_free_value(NCPL_VALUE *v)
{
    if( v->type==_N_NUMERIC ) {
        if( v->u.num.type==_N_V_STRING && v->u.num.u.s.s!=NULL )
            niffic_free(v->u.num.u.s.s);
        else if( v->u.num.type==_N_V_FILE ) {
            NCPL_NUMERIC *num = &(v->u.num);
            if( num->u.file.rd_buf!=NULL )
                niffic_free(num->u.file.rd_buf);
            if( num->u.file.wr_buf!=NULL )
                niffic_free(num->u.file.wr_buf);
        }
    }
    niffic_free(v);
}

void ncpl_assign_value(niffic_pool_t *pool, \
NCPL_VALUE *v, int ntype, int vtype, void *val)
{
    if( v->type==_N_NUMERIC ) {
        if( v->u.num.type==_N_V_STRING && v->u.num.u.s.s!=NULL )
            niffic_free(v->u.num.u.s.s);
        else if( v->u.num.type==_N_V_FILE ) {
            NCPL_NUMERIC *num = &(v->u.num);
            if( num->u.file.rd_buf!=NULL )
                niffic_free(num->u.file.rd_buf);
            if( num->u.file.wr_buf!=NULL )
                niffic_free(num->u.file.wr_buf);
        }
    }
    memset(v, 0, sizeof(NCPL_VALUE));
    v->type = ntype;
    switch( ntype ) {
        case _N_CONTROL:
            v->u.ctl = *((int *)val);
            break;
        case _N_NUMERIC:
            v->u.num.type = vtype;
            ncpl_assign_value_numeric(pool, v, val);
            break;
        case _N_NONE:
            break;
        default:
            fprintf(stderr, "%s(): Shouldn't be here. %d.\n", \
            __FUNCTION__, ntype); exit(1);
    }
}

static void ncpl_assign_value_numeric(niffic_pool_t *pool, NCPL_VALUE *v, void *val)
{
    NCPL_NUMERIC *num = &(v->u.num);
    switch( num->type ) {
        case _N_V_SHORT:
            num->u.sh = *((short *)val);
            break;
        case _N_V_INT:
            num->u.i = *((int *)val);
            break;
        case _N_V_LONG:
#ifdef __x86_64
            num->u.l = *((long *)val);
#else
            num->u.l = *((long long *)val);
#endif
            break;
        case _N_V_FLOAT:
            num->u.f = *((float *)val);
            break;
        case _N_V_CHAR:
            num->u.c = *((char *)val);
            break;
        case _N_V_STRING: {
            if( val!=NULL ) {
                num->u.s.len = strlen((char *)val);
                num->u.s.s = (char *)niffic_alloc(pool, num->u.s.len+1);
                assert(num->u.s.s);
                strncpy(num->u.s.s, (char *)val, num->u.s.len);
            } else {
                num->u.s.len = 0; num->u.s.s = NULL;
            }
            break;
        }
        case _N_V_FILE:
            num->u.file.fd = *((int *)val);
            num->u.file.rd_buf = (char *)niffic_alloc(pool, _N_V_BUFLEN);
            assert(num->u.file.rd_buf);
            num->u.file.wr_buf = (char *)niffic_alloc(pool, _N_V_BUFLEN);
            assert(num->u.file.wr_buf);
            break;
        default:
            fprintf(stderr, "%s(): Shouldn't be here. %d.\n", \
            __FUNCTION__, num->type); exit(1);
    }
}

void ncpl_equal_value(niffic_pool_t *pool, NCPL_VALUE *left, NCPL_VALUE *right)
{
    int vtype = 0;
    switch( right->type ) {
        case _N_NUMERIC: {
            NCPL_NUMERIC *num = &(right->u.num);
            vtype = num->type;
            switch( vtype ) {
                case _N_V_SHORT:
                    ncpl_assign_value(pool, left, right->type, vtype, &(num->u.sh));
                    break;
                case _N_V_INT:
                    ncpl_assign_value(pool, left, right->type, vtype, &(num->u.i));
                    break;
                case _N_V_LONG:
                    ncpl_assign_value(pool, left, right->type, vtype, &(num->u.l));
                    break;
                case _N_V_FLOAT:
                    ncpl_assign_value(pool, left, right->type, vtype, &(num->u.f));
                    break;
                case _N_V_CHAR:
                    ncpl_assign_value(pool, left, right->type, vtype, &(num->u.c));
                    break;
                case _N_V_STRING:
                    ncpl_assign_value(pool, left, right->type, vtype, num->u.s.s);
                    break;
                case _N_V_FILE: {
                    ncpl_assign_value(pool, left, right->type, vtype, &(num->u.file.fd));
                    NCPL_NUMERIC *num_left = &(left->u.num);
                    num_left->u.file.rd_pos = num->u.file.rd_pos;
                    num_left->u.file.wr_pos = num->u.file.wr_pos;
                    num_left->u.file.status = num->u.file.status;
                    num_left->u.file.rd_sum = num->u.file.rd_sum;
                    memcpy(num_left->u.file.rd_buf, num->u.file.rd_buf, _N_V_BUFLEN);
                    memcpy(num_left->u.file.wr_buf, num->u.file.wr_buf, _N_V_BUFLEN);
                    break;
                }
                default:
                    fprintf(stderr, "%s(): Shouldn't be here. %d.\n", \
                    __FUNCTION__, vtype); exit(1);
            }
            break;
        }
        case _N_CONTROL: {
            int ctl = right->u.ctl;
            ncpl_assign_value(pool, left, right->type, vtype, &ctl);
            break;
        }
        case _N_NONE:
            break;
        default:
            fprintf(stderr, "%s(): Shouldn't be here. %d.\n", \
            __FUNCTION__, right->type); exit(1);
    }
}

int ncpl_value_istrue(NCPL_VALUE *val)
{
    assert(val->type==_N_NUMERIC);
    NCPL_NUMERIC *num = &(val->u.num);
    int i;
    switch( num->type ) {
        case _N_V_SHORT:
            i = (num->u.sh)?1:0; break;
        case _N_V_INT:
            i = (num->u.i)?1:0; break;
        case _N_V_LONG:
            i = (num->u.l)?1:0; break;
        case _N_V_FLOAT:
            i = (num->u.f)?1:0; break;
        case _N_V_CHAR:
            i = (num->u.c)?1:0; break;
        case _N_V_STRING:
            i = (num->u.s.len)?1:0; break;
        case _N_V_FILE:
            i = (num->u.file.fd>=0)?1:0; break;
        default:
            fprintf(stderr, "%s(): Shouldn't be here. %d.\n", \
            __FUNCTION__, num->type); exit(1);
    }
    return i;
}

int ncpl_calc_value(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src, int ctype)
{
    assert(ctype<OPR_TYPE_TBLLEN);
    return opr_value_tbl[ctype](pool, dest, src);
}

static int ncpl_calc_value_negate(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    assert(dest->type==_N_NUMERIC);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_dest->type ) {
        case _N_V_SHORT:
            num_dest->u.sh = ~(num_dest->u.sh);
            break;
        case _N_V_INT:
            num_dest->u.i = ~(num_dest->u.i);
            break;
        case _N_V_LONG:
            num_dest->u.l = ~(num_dest->u.l);
            break;
        case _N_V_CHAR:
            num_dest->u.c = ~(num_dest->u.c);
            break;
        case _N_V_FLOAT:
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_dest->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_excl(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    assert(dest->type==_N_NUMERIC);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_dest->type ) {
        case _N_V_SHORT:
            num_dest->u.sh = !(num_dest->u.sh);
            break;
        case _N_V_INT:
            num_dest->u.i = !(num_dest->u.i);
            break;
        case _N_V_LONG:
            num_dest->u.l = !(num_dest->u.l);
            break;
        case _N_V_FLOAT:
            num_dest->u.f = !(num_dest->u.f);
            break;
        case _N_V_CHAR:
            num_dest->u.c = !(num_dest->u.c);
            break;
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_dest->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_ssub(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    assert(dest->type==_N_NUMERIC);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_dest->type ) {
        case _N_V_SHORT:
            num_dest->u.sh = -(num_dest->u.sh);
            break;
        case _N_V_INT:
            num_dest->u.i = -(num_dest->u.i);
            break;
        case _N_V_LONG:
            num_dest->u.l = -(num_dest->u.l);
            break;
        case _N_V_FLOAT:
            num_dest->u.f = -(num_dest->u.f);
            break;
        case _N_V_CHAR:
            num_dest->u.c = -(num_dest->u.c);
            break;
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_dest->type); exit(1);
    }
    return 0;
}

/*MUL------------------------------------------------------------------------*/
static int ncpl_calc_value_mul(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    assert(dest->type==_N_NUMERIC);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    assert(src->type==_N_NUMERIC);
    switch( num_dest->type ) {
        case _N_V_SHORT:
            return ncpl_calc_value_mul_short(pool, dest, src);
        case _N_V_INT:
            return ncpl_calc_value_mul_int(pool, dest, src);
        case _N_V_LONG:
            return ncpl_calc_value_mul_long(pool, dest, src);
        case _N_V_FLOAT:
            return ncpl_calc_value_mul_float(pool, dest, src);
        case _N_V_CHAR:
            return ncpl_calc_value_mul_char(pool, dest, src);
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_dest->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_mul_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            num_dest->u.sh = num_dest->u.sh * num_src->u.sh;
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.sh * num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.sh * num_src->u.l;
#else
            long long l = num_dest->u.sh * num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.sh * num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            short sh = num_dest->u.sh * num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_mul_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            int i = num_dest->u.i * num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_INT: {
            num_dest->u.i = num_dest->u.i * num_src->u.i;
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.i * num_src->u.l;
#else
            long long l = num_dest->u.i * num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.i * num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            int i = num_dest->u.i * num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_mul_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
#ifdef __x86_64
    long l;
#else
    long long l;
#endif
    switch( num_src->type ) {
        case _N_V_SHORT: {
            l = num_dest->u.l * num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_INT: {
            l = num_dest->u.l * num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_LONG: {
            num_dest->u.l = num_dest->u.l * num_src->u.l;
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.l * num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            l = num_dest->u.l * num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_mul_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    float f;
    switch( num_src->type ) {
        case _N_V_SHORT: {
            f = num_dest->u.f * num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_INT: {
            f = num_dest->u.f * num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_LONG: {
            f = num_dest->u.f * num_src->u.l;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_FLOAT: {
            num_dest->u.f = num_dest->u.f * num_src->u.f;
            break;
        }
        case _N_V_CHAR: {
            f = num_dest->u.f * num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_mul_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            short sh = num_dest->u.c * num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.c * num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.c * num_src->u.l;
#else
            long long l = num_dest->u.c * num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.c * num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            num_dest->u.c = num_dest->u.c * num_src->u.c;
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

/*end-------------------------------------------------------------------*/

/*div-------------------------------------------------------------------*/
static int ncpl_calc_value_div(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    assert(dest->type==_N_NUMERIC);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    assert(src->type==_N_NUMERIC);
    switch( num_dest->type ) {
        case _N_V_SHORT:
            return ncpl_calc_value_div_short(pool, dest, src);
        case _N_V_INT:
            return ncpl_calc_value_div_int(pool, dest, src);
        case _N_V_LONG:
            return ncpl_calc_value_div_long(pool, dest, src);
        case _N_V_FLOAT:
            return ncpl_calc_value_div_float(pool, dest, src);
        case _N_V_CHAR:
            return ncpl_calc_value_div_char(pool, dest, src);
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_dest->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_div_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            num_dest->u.sh = num_dest->u.sh / num_src->u.sh;
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.sh / num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.sh / num_src->u.l;
#else
            long long l = num_dest->u.sh / num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.sh / num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            short sh = num_dest->u.sh / num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_div_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            int i = num_dest->u.i / num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_INT: {
            num_dest->u.i = num_dest->u.i / num_src->u.i;
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.i / num_src->u.l;
#else
            long long l = num_dest->u.i / num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.i / num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            int i = num_dest->u.i / num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_div_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
#ifdef __x86_64
    long l;
#else
    long long l;
#endif
    switch( num_src->type ) {
        case _N_V_SHORT: {
            l = num_dest->u.l / num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_INT: {
            l = num_dest->u.l / num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_LONG: {
            num_dest->u.l = num_dest->u.l / num_src->u.l;
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.l / num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            l = num_dest->u.l / num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_div_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    float f;
    switch( num_src->type ) {
        case _N_V_SHORT: {
            f = num_dest->u.f / num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_INT: {
            f = num_dest->u.f / num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_LONG: {
            f = num_dest->u.f / num_src->u.l;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_FLOAT: {
            num_dest->u.f = num_dest->u.f / num_src->u.f;
            break;
        }
        case _N_V_CHAR: {
            f = num_dest->u.f / num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_div_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            short sh = num_dest->u.c / num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.c / num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.c / num_src->u.l;
#else
            long long l = num_dest->u.c / num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.c / num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            num_dest->u.c = num_dest->u.c / num_src->u.c;
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

/*end-------------------------------------------------------------------*/

/*perc-------------------------------------------------------------------*/
static int ncpl_calc_value_perc(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    assert(dest->type==_N_NUMERIC);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    assert(src->type==_N_NUMERIC);
    switch( num_dest->type ) {
        case _N_V_SHORT:
            return ncpl_calc_value_perc_short(pool, dest, src);
        case _N_V_INT:
            return ncpl_calc_value_perc_int(pool, dest, src);
        case _N_V_LONG:
            return ncpl_calc_value_perc_long(pool, dest, src);
        case _N_V_CHAR:
            return ncpl_calc_value_perc_char(pool, dest, src);
        case _N_V_FLOAT:
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_dest->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_perc_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            num_dest->u.sh = num_dest->u.sh % num_src->u.sh;
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.sh % num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.sh % num_src->u.l;
#else
            long long l = num_dest->u.sh % num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            return E_N_PRM_TYPE;
        }
        case _N_V_CHAR: {
            short sh = num_dest->u.sh % num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_perc_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            int i = num_dest->u.i % num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_INT: {
            num_dest->u.i = num_dest->u.i % num_src->u.i;
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.i % num_src->u.l;
#else
            long long l = num_dest->u.i % num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            return E_N_PRM_TYPE;
        }
        case _N_V_CHAR: {
            int i = num_dest->u.i % num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_perc_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
#ifdef __x86_64
    long l;
#else
    long long l;
#endif
    switch( num_src->type ) {
        case _N_V_SHORT: {
            l = num_dest->u.l % num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_INT: {
            l = num_dest->u.l % num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_LONG: {
            num_dest->u.l = num_dest->u.l % num_src->u.l;
            break;
        }
        case _N_V_FLOAT: {
            return E_N_PRM_TYPE;
        }
        case _N_V_CHAR: {
            l = num_dest->u.l % num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_perc_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            short sh = num_dest->u.c % num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.c % num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.c % num_src->u.l;
#else
            long long l = num_dest->u.c % num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            return E_N_PRM_TYPE;
        }
        case _N_V_CHAR: {
            num_dest->u.c = num_dest->u.c % num_src->u.c;
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

/*end-------------------------------------------------------------------*/

/*add-------------------------------------------------------------------*/
static int ncpl_calc_value_add(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    assert(dest->type==_N_NUMERIC);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    assert(src->type==_N_NUMERIC);
    switch( num_dest->type ) {
        case _N_V_SHORT:
            return ncpl_calc_value_add_short(pool, dest, src);
        case _N_V_INT:
            return ncpl_calc_value_add_int(pool, dest, src);
        case _N_V_LONG:
            return ncpl_calc_value_add_long(pool, dest, src);
        case _N_V_FLOAT:
            return ncpl_calc_value_add_char(pool, dest, src);
        case _N_V_CHAR:
            return ncpl_calc_value_add_float(pool, dest, src);
        case _N_V_STRING:
            return ncpl_calc_value_add_string(pool, dest, src);
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_dest->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_add_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            num_dest->u.sh = num_dest->u.sh + num_src->u.sh;
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.sh + num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.sh + num_src->u.l;
#else
            long long l = num_dest->u.sh + num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.sh + num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            short sh = num_dest->u.sh + num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_add_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            int i = num_dest->u.i + num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_INT: {
            num_dest->u.i = num_dest->u.i + num_src->u.i;
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.i + num_src->u.l;
#else
            long long l = num_dest->u.i + num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.i + num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            int i = num_dest->u.i + num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_add_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
#ifdef __x86_64
    long l;
#else
    long long l;
#endif
    switch( num_src->type ) {
        case _N_V_SHORT: {
            l = num_dest->u.l + num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_INT: {
            l = num_dest->u.l + num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_LONG: {
            num_dest->u.l = num_dest->u.l + num_src->u.l;
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.l + num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            l = num_dest->u.l + num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_add_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    float f;
    switch( num_src->type ) {
        case _N_V_SHORT: {
            f = num_dest->u.f + num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_INT: {
            f = num_dest->u.f + num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_LONG: {
            f = num_dest->u.f + num_src->u.l;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_FLOAT: {
            num_dest->u.f = num_dest->u.f + num_src->u.f;
            break;
        }
        case _N_V_CHAR: {
            f = num_dest->u.f + num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_add_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            short sh = num_dest->u.c + num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.c + num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.c + num_src->u.l;
#else
            long long l = num_dest->u.c + num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.c + num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            num_dest->u.c = num_dest->u.c + num_src->u.c;
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_add_string(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_STRING: {
            int len = num_src->u.s.len + num_dest->u.s.len;
            if( len>0 ) {
                char *buf = (char *)niffic_alloc(pool, len+1);
                assert(buf);
                char *p = buf;
                if( num_dest->u.s.len ) {
                    strncpy(p, num_dest->u.s.s, num_dest->u.s.len);
                    p += num_dest->u.s.len;
                }
                if( num_src->u.s.len ) {
                    strncpy(p, num_src->u.s.s, num_src->u.s.len);
                    p += num_src->u.s.len;
                }
                if( num_dest->u.s.s!=NULL ) niffic_free(num_dest->u.s.s);
                num_dest->u.s.s = buf; num_dest->u.s.len = len; 
            }
            break;
        }
        case _N_V_SHORT:
        case _N_V_INT:
        case _N_V_LONG:
        case _N_V_FLOAT:
        case _N_V_CHAR:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

/*end-------------------------------------------------------------------*/

/*sub-------------------------------------------------------------------*/
static int ncpl_calc_value_sub(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    assert(dest->type==_N_NUMERIC);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    assert(src->type==_N_NUMERIC);
    switch( num_dest->type ) {
        case _N_V_SHORT:
            return ncpl_calc_value_sub_short(pool, dest, src);
        case _N_V_INT:
            return ncpl_calc_value_sub_int(pool, dest, src);
        case _N_V_LONG:
            return ncpl_calc_value_sub_long(pool, dest, src);
        case _N_V_FLOAT:
            return ncpl_calc_value_sub_float(pool, dest, src);
        case _N_V_CHAR:
            return ncpl_calc_value_sub_char(pool, dest, src);
        case _N_V_STRING:
            return ncpl_calc_value_sub_string(pool, dest, src);
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_dest->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_sub_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            num_dest->u.sh = num_dest->u.sh - num_src->u.sh;
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.sh - num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.sh - num_src->u.l;
#else
            long long l = num_dest->u.sh - num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.sh - num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            short sh = num_dest->u.sh - num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_sub_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            int i = num_dest->u.i - num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_INT: {
            num_dest->u.i = num_dest->u.i - num_src->u.i;
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.i - num_src->u.l;
#else
            long long l = num_dest->u.i - num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.i - num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            int i = num_dest->u.i - num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_sub_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
#ifdef __x86_64
    long l;
#else
    long long l;
#endif
    switch( num_src->type ) {
        case _N_V_SHORT: {
            l = num_dest->u.l - num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_INT: {
            l = num_dest->u.l - num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_LONG: {
            num_dest->u.l = num_dest->u.l - num_src->u.l;
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.l - num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            l = num_dest->u.l - num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_sub_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    float f;
    switch( num_src->type ) {
        case _N_V_SHORT: {
            f = num_dest->u.f - num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_INT: {
            f = num_dest->u.f - num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_LONG: {
            f = num_dest->u.f - num_src->u.l;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_FLOAT: {
            num_dest->u.f = num_dest->u.f - num_src->u.f;
            break;
        }
        case _N_V_CHAR: {
            f = num_dest->u.f - num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_sub_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            short sh = num_dest->u.c - num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.c - num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.c - num_src->u.l;
#else
            long long l = num_dest->u.c - num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.c - num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            num_dest->u.c = num_dest->u.c - num_src->u.c;
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_sub_string(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_STRING: {
            if( num_dest->u.s.len==0 || num_src->u.s.len==0 ) break;
            char *w, *r, *save = NULL;
            while( (w = strstr(num_dest->u.s.s, num_src->u.s.s))!=NULL ) {
                r = w + num_src->u.s.len;
                for(; *r!=0; r++, w++) *w = *r;
                save = w;
            }
            if( save!=NULL ) for(; *save!=0; save++) *save = 0;
            int len = strlen(num_dest->u.s.s);
            if( len!=num_dest->u.s.len ) {
                char *buf = (char *)niffic_alloc(pool, len+1);
                assert(buf);
                strncpy(buf, num_dest->u.s.s, len);
                niffic_free(num_dest->u.s.s);
                num_dest->u.s.s = buf; num_dest->u.s.len = len;
            }
            break;
        }
        case _N_V_SHORT:
        case _N_V_INT:
        case _N_V_LONG:
        case _N_V_FLOAT:
        case _N_V_CHAR:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

/*end-------------------------------------------------------------------*/

/*xor-------------------------------------------------------------------*/
static int ncpl_calc_value_xor(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    assert(dest->type==_N_NUMERIC);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    assert(src->type==_N_NUMERIC);
    switch( num_dest->type ) {
        case _N_V_SHORT:
            return ncpl_calc_value_xor_short(pool, dest, src);
        case _N_V_INT:
            return ncpl_calc_value_xor_int(pool, dest, src);
        case _N_V_LONG:
            return ncpl_calc_value_xor_long(pool, dest, src);
        case _N_V_CHAR:
            return ncpl_calc_value_xor_char(pool, dest, src);
        case _N_V_FLOAT:
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_dest->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_xor_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            num_dest->u.sh = num_dest->u.sh ^ num_src->u.sh;
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.sh ^ num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.sh ^ num_src->u.l;
#else
            long long l = num_dest->u.sh ^ num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_CHAR: {
            short sh = num_dest->u.sh ^ num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_FLOAT:
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_xor_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            int i = num_dest->u.i ^ num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_INT: {
            num_dest->u.i = num_dest->u.i ^ num_src->u.i;
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.i ^ num_src->u.l;
#else
            long long l = num_dest->u.i ^ num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_CHAR: {
            int i = num_dest->u.i ^ num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_FLOAT:
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_xor_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
#ifdef __x86_64
    long l;
#else
    long long l;
#endif
    switch( num_src->type ) {
        case _N_V_SHORT: {
            l = num_dest->u.l ^ num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_INT: {
            l = num_dest->u.l ^ num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_LONG: {
            num_dest->u.l = num_dest->u.l ^ num_src->u.l;
            break;
        }
        case _N_V_CHAR: {
            l = num_dest->u.l ^ num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT:
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_xor_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            short sh = num_dest->u.c ^ num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.c ^ num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.c ^ num_src->u.l;
#else
            long long l = num_dest->u.c ^ num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_CHAR: {
            num_dest->u.c = num_dest->u.c ^ num_src->u.c;
            break;
        }
        case _N_V_FLOAT:
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

/*end-------------------------------------------------------------------*/

/*and-------------------------------------------------------------------*/
static int ncpl_calc_value_and(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    assert(dest->type==_N_NUMERIC);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    assert(src->type==_N_NUMERIC);
    switch( num_dest->type ) {
        case _N_V_SHORT:
            return ncpl_calc_value_and_short(pool, dest, src);
        case _N_V_INT:
            return ncpl_calc_value_and_int(pool, dest, src);
        case _N_V_LONG:
            return ncpl_calc_value_and_long(pool, dest, src);
        case _N_V_CHAR:
            return ncpl_calc_value_and_char(pool, dest, src);
        case _N_V_FLOAT:
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_dest->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_and_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            num_dest->u.sh = num_dest->u.sh & num_src->u.sh;
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.sh & num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.sh & num_src->u.l;
#else
            long long l = num_dest->u.sh & num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_CHAR: {
            short sh = num_dest->u.sh & num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_FLOAT:
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_and_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            int i = num_dest->u.i & num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_INT: {
            num_dest->u.i = num_dest->u.i & num_src->u.i;
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.i & num_src->u.l;
#else
            long long l = num_dest->u.i & num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_CHAR: {
            int i = num_dest->u.i & num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_FLOAT:
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_and_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
#ifdef __x86_64
    long l;
#else
    long long l;
#endif
    switch( num_src->type ) {
        case _N_V_SHORT: {
            l = num_dest->u.l & num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_INT: {
            l = num_dest->u.l & num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_LONG: {
            num_dest->u.l = num_dest->u.l & num_src->u.l;
            break;
        }
        case _N_V_CHAR: {
            l = num_dest->u.l & num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT:
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_and_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            short sh = num_dest->u.c & num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.c & num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.c & num_src->u.l;
#else
            long long l = num_dest->u.c & num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_CHAR: {
            num_dest->u.c = num_dest->u.c & num_src->u.c;
            break;
        }
        case _N_V_FLOAT:
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

/*end-------------------------------------------------------------------*/

/*or-------------------------------------------------------------------*/
static int ncpl_calc_value_or(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    assert(dest->type==_N_NUMERIC);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    assert(src->type==_N_NUMERIC);
    switch( num_dest->type ) {
        case _N_V_SHORT:
            return ncpl_calc_value_or_short(pool, dest, src);
        case _N_V_INT:
            return ncpl_calc_value_or_int(pool, dest, src);
        case _N_V_LONG:
            return ncpl_calc_value_or_long(pool, dest, src);
        case _N_V_CHAR:
            return ncpl_calc_value_or_char(pool, dest, src);
        case _N_V_FLOAT:
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_dest->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_or_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            num_dest->u.sh = num_dest->u.sh | num_src->u.sh;
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.sh | num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.sh | num_src->u.l;
#else
            long long l = num_dest->u.sh | num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_CHAR: {
            short sh = num_dest->u.sh | num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_FLOAT:
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_or_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            int i = num_dest->u.i | num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_INT: {
            num_dest->u.i = num_dest->u.i | num_src->u.i;
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.i | num_src->u.l;
#else
            long long l = num_dest->u.i | num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_CHAR: {
            int i = num_dest->u.i | num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_FLOAT:
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_or_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
#ifdef __x86_64
    long l;
#else
    long long l;
#endif
    switch( num_src->type ) {
        case _N_V_SHORT: {
            l = num_dest->u.l | num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_INT: {
            l = num_dest->u.l | num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_LONG: {
            num_dest->u.l = num_dest->u.l | num_src->u.l;
            break;
        }
        case _N_V_CHAR: {
            l = num_dest->u.l | num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT:
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_or_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            short sh = num_dest->u.c | num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.c | num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.c | num_src->u.l;
#else
            long long l = num_dest->u.c | num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_CHAR: {
            num_dest->u.c = num_dest->u.c | num_src->u.c;
            break;
        }
        case _N_V_FLOAT:
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

/*end-------------------------------------------------------------------*/

/*rand-------------------------------------------------------------------*/
static int ncpl_calc_value_rand(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    assert(dest->type==_N_NUMERIC);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    assert(src->type==_N_NUMERIC);
    switch( num_dest->type ) {
        case _N_V_SHORT:
            return ncpl_calc_value_rand_short(pool, dest, src);
        case _N_V_INT:
            return ncpl_calc_value_rand_int(pool, dest, src);
        case _N_V_LONG:
            return ncpl_calc_value_rand_long(pool, dest, src);
        case _N_V_FLOAT:
            return ncpl_calc_value_rand_float(pool, dest, src);
        case _N_V_CHAR:
            return ncpl_calc_value_rand_char(pool, dest, src);
        case _N_V_STRING:
            return ncpl_calc_value_rand_string(pool, dest, src);
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_dest->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_rand_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            num_dest->u.sh = num_dest->u.sh && num_src->u.sh;
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.sh && num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.sh && num_src->u.l;
#else
            long long l = num_dest->u.sh && num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.sh && num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            short sh = num_dest->u.sh && num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_rand_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            int i = num_dest->u.i && num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_INT: {
            num_dest->u.i = num_dest->u.i && num_src->u.i;
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.i && num_src->u.l;
#else
            long long l = num_dest->u.i && num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.i && num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            int i = num_dest->u.i && num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_rand_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
#ifdef __x86_64
    long l;
#else
    long long l;
#endif
    switch( num_src->type ) {
        case _N_V_SHORT: {
            l = num_dest->u.l && num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_INT: {
            l = num_dest->u.l && num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_LONG: {
            num_dest->u.l = num_dest->u.l && num_src->u.l;
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.l && num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            l = num_dest->u.l && num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_rand_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    float f;
    switch( num_src->type ) {
        case _N_V_SHORT: {
            f = num_dest->u.f && num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_INT: {
            f = num_dest->u.f && num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_LONG: {
            f = num_dest->u.f && num_src->u.l;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_FLOAT: {
            num_dest->u.f = num_dest->u.f && num_src->u.f;
            break;
        }
        case _N_V_CHAR: {
            f = num_dest->u.f && num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_rand_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            short sh = num_dest->u.c && num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.c && num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.c && num_src->u.l;
#else
            long long l = num_dest->u.c && num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.c && num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            num_dest->u.c = num_dest->u.c && num_src->u.c;
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_rand_string(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_STRING: {
            int i;
            if( num_dest->u.s.len && num_src->u.s.len ) {
                i = 1; ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            } else {
                i = 0; ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            }
            break;
        }
        case _N_V_SHORT:
        case _N_V_INT:
        case _N_V_LONG:
        case _N_V_FLOAT:
        case _N_V_CHAR:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

/*end-------------------------------------------------------------------*/

/*ror-------------------------------------------------------------------*/
static int ncpl_calc_value_ror(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    assert(dest->type==_N_NUMERIC);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    assert(src->type==_N_NUMERIC);
    switch( num_dest->type ) {
        case _N_V_SHORT:
            return ncpl_calc_value_ror_short(pool, dest, src);
        case _N_V_INT:
            return ncpl_calc_value_ror_int(pool, dest, src);
        case _N_V_LONG:
            return ncpl_calc_value_ror_long(pool, dest, src);
        case _N_V_FLOAT:
            return ncpl_calc_value_ror_float(pool, dest, src);
        case _N_V_CHAR:
            return ncpl_calc_value_ror_char(pool, dest, src);
        case _N_V_STRING:
            return ncpl_calc_value_ror_string(pool, dest, src);
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_dest->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_ror_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            num_dest->u.sh = num_dest->u.sh || num_src->u.sh;
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.sh || num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.sh || num_src->u.l;
#else
            long long l = num_dest->u.sh || num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.sh || num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            short sh = num_dest->u.sh || num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_ror_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            int i = num_dest->u.i || num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_INT: {
            num_dest->u.i = num_dest->u.i || num_src->u.i;
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.i || num_src->u.l;
#else
            long long l = num_dest->u.i || num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.i || num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            int i = num_dest->u.i || num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_ror_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
#ifdef __x86_64
    long l;
#else
    long long l;
#endif
    switch( num_src->type ) {
        case _N_V_SHORT: {
            l = num_dest->u.l || num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_INT: {
            l = num_dest->u.l || num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_LONG: {
            num_dest->u.l = num_dest->u.l || num_src->u.l;
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.l || num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            l = num_dest->u.l || num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_ror_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    float f;
    switch( num_src->type ) {
        case _N_V_SHORT: {
            f = num_dest->u.f || num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_INT: {
            f = num_dest->u.f || num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_LONG: {
            f = num_dest->u.f || num_src->u.l;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_FLOAT: {
            num_dest->u.f = num_dest->u.f || num_src->u.f;
            break;
        }
        case _N_V_CHAR: {
            f = num_dest->u.f || num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_ror_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            short sh = num_dest->u.c || num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.c || num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.c || num_src->u.l;
#else
            long long l = num_dest->u.c || num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.c || num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            num_dest->u.c = num_dest->u.c || num_src->u.c;
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_ror_string(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_STRING: {
            int i;
            if( num_dest->u.s.len || num_src->u.s.len ) {
                i = 1; ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            } else {
                i = 0; ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            }
            break;
        }
        case _N_V_SHORT:
        case _N_V_INT:
        case _N_V_LONG:
        case _N_V_FLOAT:
        case _N_V_CHAR:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

/*end-------------------------------------------------------------------*/

/*nequal-------------------------------------------------------------------*/
static int ncpl_calc_value_NEQUAL(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    assert(dest->type==_N_NUMERIC);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    assert(src->type==_N_NUMERIC);
    switch( num_dest->type ) {
        case _N_V_SHORT:
            return ncpl_calc_value_nequal_short(pool, dest, src);
        case _N_V_INT:
            return ncpl_calc_value_nequal_int(pool, dest, src);
        case _N_V_LONG:
            return ncpl_calc_value_nequal_long(pool, dest, src);
        case _N_V_FLOAT:
            return ncpl_calc_value_nequal_float(pool, dest, src);
        case _N_V_CHAR:
            return ncpl_calc_value_nequal_char(pool, dest, src);
        case _N_V_STRING:
            return ncpl_calc_value_nequal_string(pool, dest, src);
        case _N_V_FILE:
            return ncpl_calc_value_nequal_file(pool, dest, src);
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_dest->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_nequal_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            num_dest->u.sh = num_dest->u.sh != num_src->u.sh;
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.sh != num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.sh != num_src->u.l;
#else
            long long l = num_dest->u.sh != num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.sh != num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            short sh = num_dest->u.sh != num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_nequal_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            int i = num_dest->u.i != num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_INT: {
            num_dest->u.i = num_dest->u.i != num_src->u.i;
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.i != num_src->u.l;
#else
            long long l = num_dest->u.i != num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.i != num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            int i = num_dest->u.i != num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_nequal_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
#ifdef __x86_64
    long l;
#else
    long long l;
#endif
    switch( num_src->type ) {
        case _N_V_SHORT: {
            l = num_dest->u.l != num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_INT: {
            l = num_dest->u.l != num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_LONG: {
            num_dest->u.l = num_dest->u.l != num_src->u.l;
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.l != num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            l = num_dest->u.l != num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_nequal_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    float f;
    switch( num_src->type ) {
        case _N_V_SHORT: {
            f = num_dest->u.f != num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_INT: {
            f = num_dest->u.f != num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_LONG: {
            f = num_dest->u.f != num_src->u.l;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_FLOAT: {
            num_dest->u.f = num_dest->u.f != num_src->u.f;
            break;
        }
        case _N_V_CHAR: {
            f = num_dest->u.f != num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_nequal_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            short sh = num_dest->u.c != num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.c != num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.c != num_src->u.l;
#else
            long long l = num_dest->u.c != num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.c != num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            num_dest->u.c = num_dest->u.c != num_src->u.c;
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_nequal_string(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_STRING: {
            int i = 0;
            if( num_dest->u.s.len==0 && num_src->u.s.len==0 ) i = 0;
            else if( num_dest->u.s.len==0 || num_src->u.s.len==0 ) i = 1;
            else {
                if( strcmp(num_dest->u.s.s, num_src->u.s.s) ) i = 1;
                else i = 0;
            }
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_SHORT:
        case _N_V_INT:
        case _N_V_LONG:
        case _N_V_FLOAT:
        case _N_V_CHAR:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_nequal_file(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_FILE: {
            int i = 0;
            if( num_dest->u.file.fd!=num_src->u.file.fd ) i = 1;
            else i = 0;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_SHORT:
        case _N_V_INT:
        case _N_V_LONG:
        case _N_V_FLOAT:
        case _N_V_CHAR:
        case _N_V_STRING:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

/*end-------------------------------------------------------------------*/

/*equal-------------------------------------------------------------------*/
static int ncpl_calc_value_EQUAL(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    assert(dest->type==_N_NUMERIC);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    assert(src->type==_N_NUMERIC);
    switch( num_dest->type ) {
        case _N_V_SHORT:
            return ncpl_calc_value_equal_short(pool, dest, src);
        case _N_V_INT:
            return ncpl_calc_value_equal_int(pool, dest, src);
        case _N_V_LONG:
            return ncpl_calc_value_equal_long(pool, dest, src);
        case _N_V_FLOAT:
            return ncpl_calc_value_equal_float(pool, dest, src);
        case _N_V_CHAR:
            return ncpl_calc_value_equal_char(pool, dest, src);
        case _N_V_STRING:
            return ncpl_calc_value_equal_string(pool, dest, src);
        case _N_V_FILE:
            return ncpl_calc_value_equal_file(pool, dest, src);
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_dest->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_equal_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            num_dest->u.sh = num_dest->u.sh == num_src->u.sh;
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.sh == num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.sh == num_src->u.l;
#else
            long long l = num_dest->u.sh == num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.sh == num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            short sh = num_dest->u.sh == num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_equal_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            int i = num_dest->u.i == num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_INT: {
            num_dest->u.i = num_dest->u.i == num_src->u.i;
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.i == num_src->u.l;
#else
            long long l = num_dest->u.i == num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.i == num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            int i = num_dest->u.i == num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_equal_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
#ifdef __x86_64
    long l;
#else
    long long l;
#endif
    switch( num_src->type ) {
        case _N_V_SHORT: {
            l = num_dest->u.l == num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_INT: {
            l = num_dest->u.l == num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_LONG: {
            num_dest->u.l = num_dest->u.l == num_src->u.l;
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.l == num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            l = num_dest->u.l == num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_equal_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    float f;
    switch( num_src->type ) {
        case _N_V_SHORT: {
            f = num_dest->u.f == num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_INT: {
            f = num_dest->u.f == num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_LONG: {
            f = num_dest->u.f == num_src->u.l;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_FLOAT: {
            num_dest->u.f = num_dest->u.f == num_src->u.f;
            break;
        }
        case _N_V_CHAR: {
            f = num_dest->u.f == num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_equal_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            short sh = num_dest->u.c == num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.c == num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.c == num_src->u.l;
#else
            long long l = num_dest->u.c == num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.c == num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            num_dest->u.c = num_dest->u.c == num_src->u.c;
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_equal_string(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_STRING: {
            int i = 0;
            if( num_dest->u.s.len==0 && num_src->u.s.len==0 ) i = 1;
            else if( num_dest->u.s.len==0 || num_src->u.s.len==0 ) i = 0;
            else {
                if( !strcmp(num_dest->u.s.s, num_src->u.s.s) ) i = 1;
                else i = 0;
            }
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_SHORT:
        case _N_V_INT:
        case _N_V_LONG:
        case _N_V_FLOAT:
        case _N_V_CHAR:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_equal_file(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_FILE: {
            int i = 0;
            if( num_dest->u.file.fd==num_src->u.file.fd ) i = 1;
            else i = 0;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_SHORT:
        case _N_V_INT:
        case _N_V_LONG:
        case _N_V_FLOAT:
        case _N_V_CHAR:
        case _N_V_STRING:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

/*end-------------------------------------------------------------------*/

/*less-------------------------------------------------------------------*/
static int ncpl_calc_value_LESS(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    assert(dest->type==_N_NUMERIC);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    assert(src->type==_N_NUMERIC);
    switch( num_dest->type ) {
        case _N_V_SHORT:
            return ncpl_calc_value_less_short(pool, dest, src);
        case _N_V_INT:
            return ncpl_calc_value_less_int(pool, dest, src);
        case _N_V_LONG:
            return ncpl_calc_value_less_long(pool, dest, src);
        case _N_V_FLOAT:
            return ncpl_calc_value_less_float(pool, dest, src);
        case _N_V_CHAR:
            return ncpl_calc_value_less_char(pool, dest, src);
        case _N_V_STRING:
            return ncpl_calc_value_less_string(pool, dest, src);
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_dest->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_less_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            num_dest->u.sh = num_dest->u.sh < num_src->u.sh;
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.sh < num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.sh < num_src->u.l;
#else
            long long l = num_dest->u.sh < num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.sh < num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            short sh = num_dest->u.sh < num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_less_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            int i = num_dest->u.i < num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_INT: {
            num_dest->u.i = num_dest->u.i < num_src->u.i;
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.i < num_src->u.l;
#else
            long long l = num_dest->u.i < num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.i < num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            int i = num_dest->u.i < num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_less_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
#ifdef __x86_64
    long l;
#else
    long long l;
#endif
    switch( num_src->type ) {
        case _N_V_SHORT: {
            l = num_dest->u.l < num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_INT: {
            l = num_dest->u.l < num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_LONG: {
            num_dest->u.l = num_dest->u.l < num_src->u.l;
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.l < num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            l = num_dest->u.l < num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_less_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    float f;
    switch( num_src->type ) {
        case _N_V_SHORT: {
            f = num_dest->u.f < num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_INT: {
            f = num_dest->u.f < num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_LONG: {
            f = num_dest->u.f < num_src->u.l;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_FLOAT: {
            num_dest->u.f = num_dest->u.f < num_src->u.f;
            break;
        }
        case _N_V_CHAR: {
            f = num_dest->u.f < num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_less_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            short sh = num_dest->u.c < num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.c < num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.c < num_src->u.l;
#else
            long long l = num_dest->u.c < num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.c < num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            num_dest->u.c = num_dest->u.c < num_src->u.c;
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_less_string(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_STRING: {
            int i;
            if( num_dest->u.s.len==0 && num_src->u.s.len==0 ) i = 0;
            else if( num_dest->u.s.len && num_src->u.s.len==0 ) i = 0;
            else if( num_dest->u.s.len==0 && num_src->u.s.len ) i = 1;
            else {
                if( strcmp(num_dest->u.s.s, num_src->u.s.s)<0 ) i = 1;
                else i = 0;
            }
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_SHORT:
        case _N_V_INT:
        case _N_V_LONG:
        case _N_V_FLOAT:
        case _N_V_CHAR:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

/*end-------------------------------------------------------------------*/

/*grea-------------------------------------------------------------------*/
static int ncpl_calc_value_GREA(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    assert(dest->type==_N_NUMERIC);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    assert(src->type==_N_NUMERIC);
    switch( num_dest->type ) {
        case _N_V_SHORT:
            return ncpl_calc_value_grea_short(pool, dest, src);
        case _N_V_INT:
            return ncpl_calc_value_grea_int(pool, dest, src);
        case _N_V_LONG:
            return ncpl_calc_value_grea_long(pool, dest, src);
        case _N_V_FLOAT:
            return ncpl_calc_value_grea_float(pool, dest, src);
        case _N_V_CHAR:
            return ncpl_calc_value_grea_char(pool, dest, src);
        case _N_V_STRING:
            return ncpl_calc_value_grea_string(pool, dest, src);
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_dest->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_grea_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            num_dest->u.sh = num_dest->u.sh > num_src->u.sh;
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.sh > num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.sh > num_src->u.l;
#else
            long long l = num_dest->u.sh > num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.sh > num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            short sh = num_dest->u.sh > num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_grea_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            int i = num_dest->u.i > num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_INT: {
            num_dest->u.i = num_dest->u.i > num_src->u.i;
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.i > num_src->u.l;
#else
            long long l = num_dest->u.i > num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.i > num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            int i = num_dest->u.i > num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_grea_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
#ifdef __x86_64
    long l;
#else
    long long l;
#endif
    switch( num_src->type ) {
        case _N_V_SHORT: {
            l = num_dest->u.l > num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_INT: {
            l = num_dest->u.l > num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_LONG: {
            num_dest->u.l = num_dest->u.l > num_src->u.l;
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.l > num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            l = num_dest->u.l > num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_grea_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    float f;
    switch( num_src->type ) {
        case _N_V_SHORT: {
            f = num_dest->u.f > num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_INT: {
            f = num_dest->u.f > num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_LONG: {
            f = num_dest->u.f > num_src->u.l;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_FLOAT: {
            num_dest->u.f = num_dest->u.f > num_src->u.f;
            break;
        }
        case _N_V_CHAR: {
            f = num_dest->u.f > num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_grea_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            short sh = num_dest->u.c > num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.c > num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.c > num_src->u.l;
#else
            long long l = num_dest->u.c > num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.c > num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            num_dest->u.c = num_dest->u.c > num_src->u.c;
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_grea_string(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_STRING: {
            int i;
            if( num_dest->u.s.len==0 && num_src->u.s.len==0 ) i = 0;
            else if( num_dest->u.s.len && num_src->u.s.len==0 ) i = 1;
            else if( num_dest->u.s.len==0 && num_src->u.s.len ) i = 0;
            else {
                if( strcmp(num_dest->u.s.s, num_src->u.s.s)>0 ) i = 1;
                else i = 0;
            }
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_SHORT:
        case _N_V_INT:
        case _N_V_LONG:
        case _N_V_FLOAT:
        case _N_V_CHAR:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

/*end-------------------------------------------------------------------*/

/*gequal-------------------------------------------------------------------*/
static int ncpl_calc_value_GEQUAL(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    assert(dest->type==_N_NUMERIC);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    assert(src->type==_N_NUMERIC);
    switch( num_dest->type ) {
        case _N_V_SHORT:
            return ncpl_calc_value_gequal_short(pool, dest, src);
        case _N_V_INT:
            return ncpl_calc_value_gequal_int(pool, dest, src);
        case _N_V_LONG:
            return ncpl_calc_value_gequal_long(pool, dest, src);
        case _N_V_FLOAT:
            return ncpl_calc_value_gequal_float(pool, dest, src);
        case _N_V_CHAR:
            return ncpl_calc_value_gequal_char(pool, dest, src);
        case _N_V_STRING:
            return ncpl_calc_value_gequal_string(pool, dest, src);
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_dest->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_gequal_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            num_dest->u.sh = num_dest->u.sh >= num_src->u.sh;
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.sh >= num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.sh >= num_src->u.l;
#else
            long long l = num_dest->u.sh >= num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.sh >= num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            short sh = num_dest->u.sh >= num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_gequal_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            int i = num_dest->u.i >= num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_INT: {
            num_dest->u.i = num_dest->u.i >= num_src->u.i;
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.i >= num_src->u.l;
#else
            long long l = num_dest->u.i >= num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.i >= num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            int i = num_dest->u.i >= num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_gequal_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
#ifdef __x86_64
    long l;
#else
    long long l;
#endif
    switch( num_src->type ) {
        case _N_V_SHORT: {
            l = num_dest->u.l >= num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_INT: {
            l = num_dest->u.l >= num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_LONG: {
            num_dest->u.l = num_dest->u.l >= num_src->u.l;
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.l >= num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            l = num_dest->u.l >= num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_gequal_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    float f;
    switch( num_src->type ) {
        case _N_V_SHORT: {
            f = num_dest->u.f >= num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_INT: {
            f = num_dest->u.f >= num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_LONG: {
            f = num_dest->u.f >= num_src->u.l;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_FLOAT: {
            num_dest->u.f = num_dest->u.f >= num_src->u.f;
            break;
        }
        case _N_V_CHAR: {
            f = num_dest->u.f >= num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_gequal_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            short sh = num_dest->u.c >= num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.c >= num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.c >= num_src->u.l;
#else
            long long l = num_dest->u.c >= num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.c >= num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            num_dest->u.c = num_dest->u.c >= num_src->u.c;
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_gequal_string(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_STRING: {
            int i;
            if( num_dest->u.s.len==0 && num_src->u.s.len==0 ) i = 1;
            else if( num_dest->u.s.len && num_src->u.s.len==0 ) i = 1;
            else if( num_dest->u.s.len==0 && num_src->u.s.len ) i = 0;
            else {
                if( strcmp(num_dest->u.s.s, num_src->u.s.s)>=0 ) i = 1;
                else i = 0;
            }
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_SHORT:
        case _N_V_INT:
        case _N_V_LONG:
        case _N_V_FLOAT:
        case _N_V_CHAR:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

/*end-------------------------------------------------------------------*/

/*lequal-------------------------------------------------------------------*/
static int ncpl_calc_value_LEQUAL(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    assert(dest->type==_N_NUMERIC);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    assert(src->type==_N_NUMERIC);
    switch( num_dest->type ) {
        case _N_V_SHORT:
            return ncpl_calc_value_lequal_short(pool, dest, src);
        case _N_V_INT:
            return ncpl_calc_value_lequal_int(pool, dest, src);
        case _N_V_LONG:
            return ncpl_calc_value_lequal_long(pool, dest, src);
        case _N_V_FLOAT:
            return ncpl_calc_value_lequal_float(pool, dest, src);
        case _N_V_CHAR:
            return ncpl_calc_value_lequal_char(pool, dest, src);
        case _N_V_STRING:
            return ncpl_calc_value_lequal_string(pool, dest, src);
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_dest->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_lequal_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            num_dest->u.sh = num_dest->u.sh <= num_src->u.sh;
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.sh <= num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.sh <= num_src->u.l;
#else
            long long l = num_dest->u.sh <= num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.sh <= num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            short sh = num_dest->u.sh <= num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_lequal_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            int i = num_dest->u.i <= num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_INT: {
            num_dest->u.i = num_dest->u.i <= num_src->u.i;
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.i <= num_src->u.l;
#else
            long long l = num_dest->u.i <= num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.i <= num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            int i = num_dest->u.i <= num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_lequal_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
#ifdef __x86_64
    long l;
#else
    long long l;
#endif
    switch( num_src->type ) {
        case _N_V_SHORT: {
            l = num_dest->u.l <= num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_INT: {
            l = num_dest->u.l <= num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_LONG: {
            num_dest->u.l = num_dest->u.l <= num_src->u.l;
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.l <= num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            l = num_dest->u.l <= num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_lequal_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    float f;
    switch( num_src->type ) {
        case _N_V_SHORT: {
            f = num_dest->u.f <= num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_INT: {
            f = num_dest->u.f <= num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_LONG: {
            f = num_dest->u.f <= num_src->u.l;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_FLOAT: {
            num_dest->u.f = num_dest->u.f <= num_src->u.f;
            break;
        }
        case _N_V_CHAR: {
            f = num_dest->u.f <= num_src->u.c;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_lequal_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            short sh = num_dest->u.c <= num_src->u.sh;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_SHORT, &sh);
            break;
        }
        case _N_V_INT: {
            int i = num_dest->u.c <= num_src->u.i;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_LONG: {
#ifdef __x86_64
            long l = num_dest->u.c <= num_src->u.l;
#else
            long long l = num_dest->u.c <= num_src->u.l;
#endif
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_LONG, &l);
            break;
        }
        case _N_V_FLOAT: {
            float f = num_dest->u.c <= num_src->u.f;
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_FLOAT, &f);
            break;
        }
        case _N_V_CHAR: {
            num_dest->u.c = num_dest->u.c <= num_src->u.c;
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_lequal_string(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_STRING: {
            int i;
            if( num_dest->u.s.len==0 && num_src->u.s.len==0 ) i = 1;
            else if( num_dest->u.s.len && num_src->u.s.len==0 ) i = 0;
            else if( num_dest->u.s.len==0 && num_src->u.s.len ) i = 1;
            else {
                if( strcmp(num_dest->u.s.s, num_src->u.s.s)<=0 ) i = 1;
                else i = 0;
            }
            ncpl_assign_value(pool, dest, _N_NUMERIC, _N_V_INT, &i);
            break;
        }
        case _N_V_SHORT:
        case _N_V_INT:
        case _N_V_LONG:
        case _N_V_FLOAT:
        case _N_V_CHAR:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

/*end-------------------------------------------------------------------*/

/*eq-------------------------------------------------------------------*/
static int ncpl_calc_value_EQ(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    assert(dest->type==_N_NUMERIC);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    assert(src->type==_N_NUMERIC);
    switch( num_dest->type ) {
        case _N_V_SHORT:
            return ncpl_calc_value_eq_short(pool, dest, src);
        case _N_V_INT:
            return ncpl_calc_value_eq_int(pool, dest, src);
        case _N_V_LONG:
            return ncpl_calc_value_eq_long(pool, dest, src);
        case _N_V_FLOAT:
            return ncpl_calc_value_eq_float(pool, dest, src);
        case _N_V_CHAR:
            return ncpl_calc_value_eq_char(pool, dest, src);
        case _N_V_STRING:
            return ncpl_calc_value_eq_string(pool, dest, src);
        case _N_V_FILE:
            return ncpl_calc_value_eq_file(pool, dest, src);
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_dest->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_eq_short(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            num_dest->u.sh = num_src->u.sh;
            break;
        }
        case _N_V_INT: {
            num_dest->u.sh = num_src->u.i;
            break;
        }
        case _N_V_LONG: {
            num_dest->u.sh = num_src->u.l;
            break;
        }
        case _N_V_FLOAT: {
            num_dest->u.sh = num_src->u.f;
            break;
        }
        case _N_V_CHAR: {
            num_dest->u.sh = num_src->u.c;
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_eq_int(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            num_dest->u.i = num_src->u.sh;
            break;
        }
        case _N_V_INT: {
            num_dest->u.i = num_src->u.i;
            break;
        }
        case _N_V_LONG: {
            num_dest->u.i = num_src->u.l;
            break;
        }
        case _N_V_FLOAT: {
            num_dest->u.i = num_src->u.f;
            break;
        }
        case _N_V_CHAR: {
            num_dest->u.i = num_src->u.c;
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_eq_long(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            num_dest->u.l = num_src->u.sh;
            break;
        }
        case _N_V_INT: {
            num_dest->u.l = num_src->u.i;
            break;
        }
        case _N_V_LONG: {
            num_dest->u.l = num_src->u.l;
            break;
        }
        case _N_V_FLOAT: {
            num_dest->u.l = num_src->u.f;
            break;
        }
        case _N_V_CHAR: {
            num_dest->u.l = num_src->u.c;
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_eq_float(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            num_dest->u.f = num_src->u.sh;
            break;
        }
        case _N_V_INT: {
            num_dest->u.f = num_src->u.i;
            break;
        }
        case _N_V_LONG: {
            num_dest->u.f = num_src->u.l;
            break;
        }
        case _N_V_FLOAT: {
            num_dest->u.f = num_src->u.f;
            break;
        }
        case _N_V_CHAR: {
            num_dest->u.f = num_src->u.c;
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_eq_char(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    NCPL_NUMERIC *num_dest = &(dest->u.num);
    switch( num_src->type ) {
        case _N_V_SHORT: {
            num_dest->u.c = num_src->u.sh;
            break;
        }
        case _N_V_INT: {
            num_dest->u.c = num_src->u.i;
            break;
        }
        case _N_V_LONG: {
            num_dest->u.c = num_src->u.l;
            break;
        }
        case _N_V_FLOAT: {
            num_dest->u.c = num_src->u.f;
            break;
        }
        case _N_V_CHAR: {
            num_dest->u.c = num_src->u.c;
            break;
        }
        case _N_V_STRING:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_eq_string(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    switch( num_src->type ) {
        case _N_V_STRING:
            ncpl_equal_value(pool, dest, src);
            break;
        case _N_V_SHORT:
        case _N_V_INT:
        case _N_V_LONG:
        case _N_V_FLOAT:
        case _N_V_CHAR:
        case _N_V_FILE:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

static int ncpl_calc_value_eq_file(niffic_pool_t *pool, NCPL_VALUE *dest, NCPL_VALUE *src)
{
    NCPL_NUMERIC *num_src = &(src->u.num);
    switch( num_src->type ) {
        case _N_V_FILE:
            ncpl_equal_value(pool, dest, src);
            break;
        case _N_V_SHORT:
        case _N_V_INT:
        case _N_V_LONG:
        case _N_V_FLOAT:
        case _N_V_CHAR:
        case _N_V_STRING:
            return E_N_PRM_TYPE;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num_src->type); exit(1);
    }
    return 0;
}

/*end-------------------------------------------------------------------*/

/*file_opr-------------------------------------------------------------------*/
int ncpl_value_file_open(niffic_pool_t *pool, NCPL_VALUE *ret, NCPL_VALUE *param)
{
    assert(param->type==_N_NUMERIC);
    NCPL_NUMERIC *num = &(param->u.num);
    assert(num->type==_N_V_STRING);
    int fd = open(num->u.s.s, O_RDWR);
    if( fd<0 ) return -1;
    ncpl_assign_value(pool, ret, _N_NUMERIC, _N_V_FILE, &fd);
    return 0;
}

void ncpl_value_file_close(niffic_pool_t *pool, NCPL_VALUE *v)
{
    assert(v->type==_N_NUMERIC);
    NCPL_NUMERIC *num = &(v->u.num);
    assert(num->type==_N_V_FILE);
    if( num->u.file.fd<0 ) return;
    close(num->u.file.fd);
    ncpl_assign_value(pool, v, _N_NONE, 0, NULL);
}

int ncpl_get_file_desc(NCPL_VALUE *v)
{
    assert(v->type==_N_NUMERIC);
    NCPL_NUMERIC *num = &(v->u.num);
    assert(num->type==_N_V_FILE);
    return num->u.file.fd;
}

/*end-------------------------------------------------------------------*/

static void ncpl_print_value_numeric(NCPL_NUMERIC *num);

void ncpl_print_value(NCPL_VALUE *v)
{
    printf("Print value:");
    switch( v->type ) {
        case _N_NONE:
            printf("NONE\n"); break;
        case _N_CONTROL:
            printf("CONTROL  ");
            if( v->u.ctl==_N_C_BREAK ) printf("Break\n");
            else printf("Continue\n");
            break;
        case _N_NUMERIC:
            printf("NUMERIC  ");
            ncpl_print_value_numeric(&(v->u.num)); break;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, v->type); exit(1);
    }
}

static void ncpl_print_value_numeric(NCPL_NUMERIC *num)
{
    switch( num->type ) {
        case _N_V_SHORT:
            printf("Short: %d\n", num->u.sh); break;
        case _N_V_INT:
            printf("Int: %d\n", num->u.i); break;
        case _N_V_LONG:
#ifdef __x86_64
            printf("Long: %ld\n", num->u.l); break;
#else
            printf("Long: %lld\n", num->u.l); break;
#endif
        case _N_V_FLOAT:
            printf("Float: %f\n", num->u.f); break;
        case _N_V_CHAR:
            printf("Char: 0x%x[%c]\n", num->u.c, num->u.c); break;
        case _N_V_STRING:
            printf("String: [%s]\n", num->u.s.s); break;
        case _N_V_FILE:
            printf("File: fd[%d]\n", num->u.file.fd); break;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num->type); exit(1);
    }
}

/*get_value---------------------------------------------------------*/
static char ncpl_get_octet_from_file(NCPL_VALUE *v)
{
    assert(v->type==_N_NUMERIC);
    NCPL_NUMERIC *num = &(v->u.num);
    if( num->type!=_N_V_FILE ) return E_N_INVALID_TYPE;
    NCPL_FILE_VALUE *fv = &(num->u.file);
    if( fv->status && fv->rd_pos==fv->rd_sum ) {
        return E_N_END_FILE;
    }
    if( fv->rd_sum==fv->rd_pos ) {
        int n = read(fv->fd, fv->rd_buf, _N_V_BUFLEN);
        if( n<0 ) return E_N_READ_FILE;
        if( n==0 ) {
            fv->status = 1; return E_N_END_FILE;
        } else if( n<_N_V_BUFLEN ) {
            fv->status = 1;
        }
        fv->rd_sum = n;
    }
    return fv->rd_buf[fv->rd_pos++];
}

static int ncpl_flush_wrbuf(NCPL_VALUE *v)
{
    assert(v->type==_N_NUMERIC);
    NCPL_NUMERIC *num = &(v->u.num);
    if( num->type!=_N_V_FILE ) return E_N_INVALID_TYPE;
    memset(num->u.file.wr_buf, 0, _N_V_BUFLEN);
    num->u.file.wr_pos = 0;
    return 0;
}

static void ncpl_copy_to_wrbuf(NCPL_VALUE *v, char c)
{
    assert(v->type==_N_NUMERIC);
    NCPL_NUMERIC *num = &(v->u.num);
    assert(num->type==_N_V_FILE);
    assert(num->u.file.wr_pos<=_N_V_BUFLEN);
    num->u.file.wr_buf[num->u.file.wr_pos++] = c;
}

static char *ncpl_get_wrbuf_content(NCPL_VALUE *v)
{
    assert(v->type==_N_NUMERIC);
    NCPL_NUMERIC *num = &(v->u.num);
    assert(num->type==_N_V_FILE);
    return num->u.file.wr_buf;
}

static char *ncpl_get_string_from_file(NCPL_VALUE *v, int *error)
{
    if( (*error = ncpl_flush_wrbuf(v))<0 ) return NULL;
    int mark = 0;
    char c;
lp: c = ncpl_get_octet_from_file(v);
    if( c<0 ) {
        *error = c; return NULL;
    } else if( c==',' || c=='\n' )
        goto lp;
    else if( c=='\"' ) mark = 1;
    else ncpl_copy_to_wrbuf(v, c);
    while( 1 ) {
        c = ncpl_get_octet_from_file(v);
        if( c<0 ) {
            if( mark ) {
                *error = c; break;
            }
            if( c==E_N_END_FILE ) {
                return ncpl_get_wrbuf_content(v);
            } else {
                *error = c; break;
            }
        } else if( c==',' || c=='\n' ) {
            if( mark ) ncpl_copy_to_wrbuf(v, c);
            else return ncpl_get_wrbuf_content(v);
        } else if( c=='\"' ) {
            if( !mark ) {
                *error = E_N_FILE_FMT; break;
            }
            if( (c = ncpl_get_octet_from_file(v))=='\"' )
                ncpl_copy_to_wrbuf(v, c);
            else return ncpl_get_wrbuf_content(v);
        } else {
            ncpl_copy_to_wrbuf(v, c);
        }
    }
    return NULL;
}

static char ncpl_get_char_from_file(NCPL_VALUE *v, int *error)
{
    char *p = ncpl_get_string_from_file(v, error);
    if( p==NULL ) return 0;
    return *p;
}

static float ncpl_get_float_from_file(NCPL_VALUE *v, int *error)
{
    char *p = ncpl_get_string_from_file(v, error);
    if( p==NULL ) return 0;
    float f = ncpl_atof(p);
    return f;
}

#ifdef __x86_64
static long ncpl_get_integer_from_file(NCPL_VALUE *v, int *error)
#else
static long long ncpl_get_integer_from_file(NCPL_VALUE *v, int *error)
#endif
{
    char *p = ncpl_get_string_from_file(v, error);
    if( p==NULL ) return 0;
    #ifdef __x86_64
    long l = ncpl_atol(p);
    #else
    long long l = ncpl_atoll(p);
    #endif
    return l;
}

char ncpl_get_char_value(NCPL_VALUE *v, int *error)
{
    assert(v->type==_N_NUMERIC);
    NCPL_NUMERIC *num = &(v->u.num);
    switch( num->type ) {
        case _N_V_SHORT:
            return (char)(num->u.sh);
        case _N_V_INT:
            return (char)(num->u.i);
        case _N_V_LONG:
            return (char)(num->u.l);
        case _N_V_CHAR:
            return num->u.c;
        case _N_V_FILE:
            return ncpl_get_char_from_file(v, error);
        case _N_V_FLOAT: {
            return (char)(num->u.f);
        }
        case _N_V_STRING:
            break;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num->type); exit(1);
    }
    *error = E_N_INVALID_TYPE;
    return 0;
}

#ifdef __x86_64
long ncpl_get_integer_value(NCPL_VALUE *v, int *error)
#else
long long ncpl_get_integer_value(NCPL_VALUE *v, int *error)
#endif
{
    assert(v->type==_N_NUMERIC);
    NCPL_NUMERIC *num = &(v->u.num);
    switch( num->type ) {
        case _N_V_SHORT:
            return num->u.sh;
        case _N_V_INT:
            return num->u.i;
        case _N_V_LONG:
            return num->u.l;
        case _N_V_CHAR:
            return num->u.c;
        case _N_V_FILE:
            return ncpl_get_integer_from_file(v, error);
        case _N_V_FLOAT: {
        #ifdef __x86_64
            return (long)(num->u.f);
        #else
            return (long long)(num->u.f);
        #endif
        }
        case _N_V_STRING:
            break;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num->type); exit(1);
    }
    *error = E_N_INVALID_TYPE;
    return 0;
}

float ncpl_get_float_value(NCPL_VALUE *v, int *error)
{
    assert(v->type==_N_NUMERIC);
    NCPL_NUMERIC *num = &(v->u.num);
    switch( num->type ) {
        case _N_V_SHORT:
            return num->u.sh;
        case _N_V_INT:
            return num->u.i;
        case _N_V_LONG:
            return num->u.l;
        case _N_V_CHAR:
            return num->u.c;
        case _N_V_FILE:
            return ncpl_get_float_from_file(v, error);
        case _N_V_FLOAT:
            return num->u.f;
        case _N_V_STRING:
            break;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num->type); exit(1);
    }
    *error = E_N_INVALID_TYPE;
    return 0;
}

char *ncpl_get_string_value(NCPL_VALUE *v, int *error)
{
    assert(v->type==_N_NUMERIC);
    NCPL_NUMERIC *num = &(v->u.num);
    switch( num->type ) {
        case _N_V_FILE:
            return ncpl_get_string_from_file(v, error);
        case _N_V_STRING:
            return num->u.s.s;
        case _N_V_SHORT:
        case _N_V_INT:
        case _N_V_LONG:
        case _N_V_CHAR:
        case _N_V_FLOAT:
            break;
        default:
            fprintf(stderr, "%s(): shouldn't be here. %d.\n", \
            __FUNCTION__, num->type); exit(1);
    }
    *error = E_N_INVALID_TYPE;
    return 0;
}

/*end---------------------------------------------------------------*/

char *ncpl_value_strerror(int err)
{
    if( err>=0 ) return noerr;
    return err_tbl[(-err)-1];
}

