/*
 * Copyright (C) Niklaus F.Schen.
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<assert.h>
#include"ncpl_env.h"
#include"ncpl_parser.h"

/*
 * Static declarations
 */

static int ncpl_sym_hash(char *s)
{
    int hash = 0;
    for(; *s; s++) {
        hash += ((*s)*65599);
    }
    return hash;
}

/*
 * symbol
 */
NCPL_SYM *ncpl_get_sym(NCPL_ENV *env, char *s)
{
    int hash = ncpl_sym_hash(s)%SYMLEN;
    NCPL_SYM *sym = (env->sym_tbl)[hash];
    for(; sym!=NULL; sym = sym->next) {
        if( !strcmp(sym->str, s) )
            return sym;
    }
    return NULL;
}

NCPL_SYM *ncpl_new_sym(NCPL_ENV *env, char *s)
{
    NCPL_SYM *sym = (NCPL_SYM *)niffic_alloc(env->pool, sizeof(NCPL_SYM));
    assert(sym);
    sym->str = s;
    int hash = ncpl_sym_hash(s)%SYMLEN;
    sym->next = (env->sym_tbl)[hash];
    (env->sym_tbl)[hash] = sym;
    return sym;
}

void ncpl_free_sym(NCPL_ENV *env, char *s)
{
    int hash = ncpl_sym_hash(s)%SYMLEN;
    NCPL_SYM *sym = (env->sym_tbl)[hash];
    (env->sym_tbl)[hash] = sym->next;
    niffic_free(sym);
}

/*
 * Envty
 */
NCPL_ENVTY *ncpl_create_envty(NCPL_ENV *env, int type, NCPL_SYM *sym)
{
    NCPL_ENVTY *typ = (NCPL_ENVTY *)niffic_alloc(env->pool, sizeof(NCPL_ENVTY));
    assert(typ);
    if( sym!=NULL ) typ->sym = sym; typ->type = type;
    return typ;
}

void ncpl_free_envty(NCPL_ENV *env, NCPL_ENVTY *typ)
{
    niffic_free(typ);
}

/*
 * Envtylist
 */
NCPL_ENVTYLIST *ncpl_create_envtylist(NCPL_ENV *env, NCPL_ENVTY *typ)
{
    NCPL_ENVTYLIST *tylist = (NCPL_ENVTYLIST *)niffic_alloc(env->pool, \
                                            sizeof(NCPL_ENVTYLIST));
    assert(tylist);
    tylist->typ = typ;
    return tylist;
}

void ncpl_add_envtylist(NCPL_ENVTYLIST *cur, NCPL_ENVTYLIST *new)
{
    cur->next = new;
}

void ncpl_free_all_envtylist(NCPL_ENV *env, NCPL_ENVTYLIST *tylist)
{
    NCPL_ENVTYLIST *fr;
    while( tylist!=NULL ) {
        fr = tylist;
        tylist = tylist->next;
        ncpl_free_envty(env, fr->typ);
        niffic_free(fr);
    }
}

int ncpl_get_nr_param(NCPL_ENVTYLIST *tylist)
{
    int cnt = 0;
    for(; tylist!=NULL; tylist = tylist->next, cnt++)
        ;
    return cnt;
}

/*
 * Stack
 */
void ncpl_env_push(NCPL_ENV *env, NCPL_ENVVAR *var)
{
    NCPL_ENVSTACK *stack = (NCPL_ENVSTACK *)niffic_alloc(env->pool, \
                                          sizeof(NCPL_ENVSTACK));
    assert(stack);
    stack->var = var;
    stack->next = env->top;
    env->top = stack;
}

NCPL_ENVSTACK *ncpl_env_pop(NCPL_ENV *env)
{
    NCPL_ENVSTACK *stack = env->top;
    env->top = stack->next;
    return stack;
}

void ncpl_free_stack(NCPL_ENVSTACK* stack)
{
    niffic_free(stack);
}

/*
 * Envvar
 */
NCPL_ENVVAR *ncpl_new_envvar(NCPL_ENV *env, int type, \
NCPL_ENVTY *typ, NCPL_ENVTYLIST *tylist, const char *s)
{
    NCPL_ENVVAR *var = (NCPL_ENVVAR *)niffic_alloc(env->pool, \
                                      sizeof(NCPL_ENVVAR));
    assert(var);
    var->type = type;
    switch( type ) {
        case ENVVAR:
        case SCOPEMARK: {
            var->u.var.varty = typ;
            break;
        }
        case ENVFUN: {
            var->u.func.retty = typ;
            var->u.func.formal = tylist;
            break;
        }
        default:
            fprintf(stderr, "%s(): No such type '%d'.\n", __FUNCTION__, type);
            exit(1);
    }
    int hash = HASHPTR(typ->sym)%ENVLEN;
    var->hash_next = (env->env_tbl)[hash];
    (env->env_tbl)[hash] = var;
    return var;
}

NCPL_ENVVAR *ncpl_get_var(NCPL_ENV *env, NCPL_SYM *sym)
{
    NCPL_ENVVAR *var = (env->env_tbl)[HASHPTR(sym)%ENVLEN];
    for(; var!=NULL; var = var->hash_next) {
        switch( var->type ) {
            case ENVVAR:
            case SCOPEMARK:
                if( sym==var->u.var.varty->sym ) return var;
                break;
            case ENVFUN:
                if( sym==var->u.func.retty->sym ) return var;
                break;
            default:
                fprintf(stderr, "%s(): No such type '%d'.\n", __FUNCTION__, var->type);
                exit(1);
        }
    }
    return NULL;
}

void ncpl_free_var(NCPL_ENV *env, NCPL_ENVVAR *var)
{
    int hash;
    NCPL_ENVVAR *head;
    switch( var->type ) {
        case ENVVAR:
        case SCOPEMARK:
            hash = HASHPTR(var->u.var.varty->sym)%ENVLEN;
            head = (env->env_tbl)[hash];
            (env->env_tbl)[hash] = head->hash_next;
            assert(head==var);
            ncpl_free_envty(env, var->u.var.varty);
            break;
        case ENVFUN:
            hash = HASHPTR(var->u.func.retty->sym)%ENVLEN;
            head = (env->env_tbl)[hash];
            (env->env_tbl)[hash] = head->hash_next;
            assert(head==var);
            ncpl_free_envty(env, var->u.func.retty);
            ncpl_free_all_envtylist(env, var->u.func.formal);
            break;
        default:
            fprintf(stderr, "%s(): No such type '%d'.\n", __FUNCTION__, var->type);
            exit(1);
    }
    if( var->val!=NULL ) ncpl_free_value(var->val);
    niffic_free(var);
}

int ncpl_check_var_repeat(NCPL_ENV *env, NCPL_SYM *sym)
{
    NCPL_ENVSTACK *stack = env->top;
    int type;
    for(; stack!=NULL && stack->var->type!=SCOPEMARK; stack = stack->next) {
        type = stack->var->type;
        switch( type ) {
            case ENVVAR:
                if( sym==stack->var->u.var.varty->sym )
                    return 1;
                break;
            case ENVFUN:
                if( sym==stack->var->u.func.retty->sym )
                    return 1;
                break;
            default:
                fprintf(stderr, "%s(): No such type '%d'.\n", __FUNCTION__, type);
                exit(1);
        }
    }
    return 0;
}

NCPL_ENVVAR *ncpl_push_new_variable(NCPL_ENV *env, \
char *s, int ty_type, int repeat_check)
{
    NCPL_SYM *sym = ncpl_get_sym(env, s);
    if( sym==NULL ) sym = ncpl_new_sym(env, s);
    NCPL_ENVTY *typ = ncpl_create_envty(env, ty_type, sym);
    if( repeat_check ) {
        if( ncpl_check_var_repeat(env, sym) ) {
            return NULL;
        }
    }
    NCPL_ENVVAR *var = ncpl_new_envvar(env, ENVVAR, typ, NULL, NULL);
    var->val = ncpl_new_value(env->pool);
    ncpl_env_push(env, var);
    return var;
}

void ncpl_push_new_function(NCPL_ENV *env, \
char *s, NCPL_ENVTY *ty_ty, NCPL_ENVTYLIST *tylist)
{
    NCPL_SYM *sym = ncpl_get_sym(env, s);
    if( sym==NULL ) sym = ncpl_new_sym(env, s);
    NCPL_ENVVAR *var = ncpl_new_envvar(env, ENVFUN, ty_ty, tylist, s);
    ncpl_env_push(env, var);
}

int ncpl_get_var_type(NCPL_ENV *env, char *s)
{
    NCPL_SYM *sym = ncpl_get_sym(env, s);
    if( sym==NULL ) return -1;
    NCPL_ENVVAR *var = ncpl_get_var(env, sym);
    if( var==NULL ) return -2;
    int type;
    switch( var->type ) {
        case ENVVAR:
            type = var->u.var.varty->type;
            break;
        case ENVFUN:
            type = var->u.func.retty->type;
            break;
        default:
            fprintf(stderr, "%s(): No such type '%d'.\n", __FUNCTION__, var->type);
            exit(1);
    }
    return type;
}

/*
 * mark
 */
void ncpl_push_mark(NCPL_ENV *env, char *s, int mark_ty)
{
    NCPL_SYM *sym = ncpl_get_sym(env, s);
    if( sym==NULL ) {
        char *p = (char *)niffic_alloc(env->pool, strlen(s)+1);
        memcpy(p, s, strlen(s));
        sym = ncpl_new_sym(env, p);
    }
    ncpl_env_push(env, ncpl_new_envvar(env, SCOPEMARK, \
    ncpl_create_envty(env, mark_ty, sym), NULL, NULL));
}

void ncpl_pop_until_mark(NCPL_ENV *env)
{
    NCPL_ENVSTACK *stack;
    NCPL_ENVVAR *var;
    int type;
    while( env->top!=NULL ) {
        stack = ncpl_env_pop(env);
        var = stack->var;
        type = var->type;
        ncpl_free_stack(stack);
        ncpl_free_var(env, var);
        if( type==SCOPEMARK )
            return ;
    }
}

/*
 * print
 */
void print_env(NCPL_ENV *env)
{
    /*sym_tbl*/
    int i;
    NCPL_SYM *sym;
    printf("Symbol table:\n");
    for(i = 0; i<SYMLEN; i++) {
        sym = (env->sym_tbl)[i];
        for(; sym!=NULL; sym = sym->next) {
            printf("  %s\n", sym->str);
        }
    }
    /*stack*/
    printf("stack:\n");
    NCPL_ENVSTACK *stack;
    for(stack = env->top; stack!=NULL; stack = stack->next) {
        print_env_var(stack->var);
    }
    printf("=======================================\n");
}

void print_env_var(NCPL_ENVVAR *var)
{
     switch( var->type ) {
        case ENVVAR:
            printf(" type: variable | var_type: %d | symbol: %s\n", \
            var->u.var.varty->type, var->u.var.varty->sym->str);
            break;
        case ENVFUN:
        {
            printf(" type: function | return_type: %d | symbol: %s", \
            var->u.func.retty->type, var->u.func.retty->sym->str);
            NCPL_ENVTYLIST *list;
            for(list = var->u.func.formal; list!=NULL; list = list->next) {
                printf(" | Param type: %d", list->typ->type);
            }
            printf("\n");
            break;
        }
        case SCOPEMARK:
            printf(" <SCOPEMARK>\n"); break;
        default:
            printf("%s(): No such type '%d'.\n", __FUNCTION__, var->type);
            exit(1);
     }
}

