/*
 * Copyright (C) Niklaus F.Schen.
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
#include<errno.h>
#include"ncpl_lex.h"
#include"ncpl_parser.h"

int ncpl_script(char *sfile, char *buf, int len)
{
    int fd = open(sfile, O_RDONLY);
    if( fd<0 ) {
        memset(buf, 0, len);
        snprintf(buf, len, "%s(): open error. %s", __FUNCTION__, strerror(errno));
        return -1;
    }
    NCPL_PARSER p;
    memset(&p, 0, sizeof(p));
    strcpy(p.pls.file, sfile);
    p.pls.ch = -1;
    p.pls.line = 1;
    p.pls.fd = fd;
    p.pls.len_buffer = 0;
    p.pls.len_token = LINELEN;
    p.pls.pool = niffic_new_pool(N_M_INFINITE, 1024);
    p.pls.log = p.log;
    p.pls.log_len = p.log_len = N_LOGSIZE;
    p.pool = niffic_new_pool(N_M_INFINITE, 1024);
    p.env.pool = niffic_new_pool(N_M_INFINITE, 1024);
    strcpy(p.log, "Succeed.");
    int ret;
    while( (ret = ncpl_parse(&p))==0 )
        ;
    if( ret<0 ) {
        int n = (len>p.log_len)?p.log_len:len;
        memcpy(buf, p.log, n);
        return -1;
    }
    if( ncpl_visit(&p)<0 ) {
        int n = (len>p.log_len)?p.log_len:len;
        memcpy(buf, p.log, n);
        return -1;
    }
    p.pass_tychk = 1;
    if( ncpl_visit(&p)<0 ) {
        int n = (len>p.log_len)?p.log_len:len;
        memcpy(buf, p.log, n);
        return -1;
    }
    ncpl_close_all_fd(p.fdhash);
    niffic_free_pool(p.env.pool);
    niffic_free_pool(p.pool);
    niffic_free_pool(p.pls.pool);
    return 0;
}

