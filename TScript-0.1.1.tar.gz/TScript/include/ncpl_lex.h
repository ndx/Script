/*
 * Copyright (C) Niklaus F.Schen.
 */

#ifndef __NCPL_LEX_H
#define __NCPL_LEX_H

#include"niffic_alloc.h"

/*Common*/
#define SYLEN 16
#define FILENAME 256
#define NAMELEN 64
#define LINELEN 1024
#define NRSPEC 29
#define NRKEYW 23
#define END_OF_FILE 0x0
#define ERRRET (char)-1
/*Special charaters*/
#define NONE -1
#define EXCL 0 /*!*/
#define PERC 1 /*%*/
#define MUL 2 /***/
#define DIV 3 /*/*/
#define ADD 4 /*+*/
#define SUB 5 /*-*/
#define EQ   6 /*=*/
#define GREA 7 /*>*/
#define LESS 8 /*<*/
#define LBRACE 9 /*{*/
#define RBRACE 10 /*}*/
#define LBRACK 11 /*[*/
#define RBRACK 12 /*]*/
#define LPAREN 13 /*(*/
#define RPAREN 14 /*)*/
#define QUEST 15  /*?*/
#define COLON 16 /*:*/
#define SEMIC 17 /*;*/
#define POINT 18 /*.*/
#define COMMA 19 /*,*/
#define NEGATE 20 /*~*/
#define CHARAC 21 /*'*/
#define STRING 22 /*"*/
#define DOLLAR 23 /*$*/
#define AND 24 /*&*/
#define OR  25 /*|*/
#define BACKSLASH 26 /*\*/
#define POUND 27 /*#*/
#define XOR 28 /*^*/
#define RAND 29 /*&&*/
#define ROR  30 /*||*/
#define GEQUAL 31 /*>=*/
#define LEQUAL 32 /*<=*/
#define EQUAL 33 /*==*/
#define NEQUAL 34 /*!=*/
#define INC 35 /*++*/
#define DEC 36 /*--*/
/*other types*/
#define INUM 37
#define FNUM 38
#define ID 39
#define COMMENT 40
/*Key words*/
#define IF 41
#define ELSE 42
#define WHILE 43
#define FOR 44
#define INT 45
#define FLOAT 46
#define LONG 47
#define CHAR 48
#define SHORT 49
#define STATIC 50
#define VOID 51
#define CONST 52
#define RETURN 53
#define QUERY 54
#define FCLOSE 55
#define FFILE 56
#define STR 57
#define NUL 58
#define FOPEN 59
#define CONTINUE 60
#define BREAK 61
#define FERR 62
#define PRINT 63
#define KEYSTART IF
#define ENDFILE 64
#define NRALL 65  /*number of all above*/

struct param_lex_s {
    char ch;
    int line;
    int fd;
    int len_buffer;
    int pos_buffer;
    int len_token;
    int pos_token;
    int log_len;/*equal to the size of parser's log-buf*/
    niffic_pool_t *pool;
    char *log;  /*equal to parser's log*/
    char ptr_buf[LINELEN];
    char ptr_token[LINELEN];
    char file[FILENAME];
};

typedef struct lex_s {
    int type;
    int line;
    char content[NAMELEN];
    struct lex_s *left;
    struct lex_s *right;
}NCPL_LEX;

/*typedef*/
typedef NCPL_LEX *(*ncpl_keyf)(struct param_lex_s *pls, char *ch, int type);


/*declarations*/
#define ASSIGN(s,i,v) (s)->(i) = (v)
extern NCPL_LEX *ncpl_token(struct param_lex_s *pls);
extern char ncpl_getone(struct param_lex_s *pls);
extern void ncpl_put_in_buf(struct param_lex_s *pls);
extern int ncpl_translate(struct param_lex_s *pls, char ch);
extern NCPL_LEX *ncpl_create_lex_node(struct param_lex_s *pls, int type);
extern void ncpl_free_lex_node(NCPL_LEX *lex);
extern int ncpl_lex_atoi(char *str);  /*map all macro-strings to their integer*/

#endif

