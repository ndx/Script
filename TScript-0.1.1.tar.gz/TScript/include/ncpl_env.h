/*
 * Copyright (C) Niklaus F.Schen.
 */

#ifndef __NCPL_ENV_H
#define __NCPL_ENV_H

#include"niffic_alloc.h"
#include"ncpl_value.h"

#define HASHPTR(ptr) (((unsigned long)(ptr))>>3)
#define SYMLEN 199
#define ENVLEN 1023
#define ENVVAR 1
#define ENVFUN 2
#define SCOPEMARK 3
/*
 * for NCPL_ENVTY->type, should be
 * different with macros in lex and parser
 */
#define FUNCMARK 1024
#define DOMAINMARK 2048

typedef struct symbol {
    char *str;
    struct symbol *next;
}NCPL_SYM;

typedef struct tyenv {
    NCPL_SYM *sym;
    int type;
}NCPL_ENVTY;

typedef struct tyenv_list {
    NCPL_ENVTY *typ;
    struct tyenv_list *next;
}NCPL_ENVTYLIST;

typedef struct varenv {
    int type;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_ENVTY *varty;
        }var;
        struct {
            NCPL_ENVTY *retty;
            NCPL_ENVTYLIST *formal;
        }func;
    }u;
    struct varenv *next;
    struct varenv *hash_next;
}NCPL_ENVVAR;

typedef struct varenvlist {
    NCPL_ENVVAR *var;
    struct varenvlist *next;
}NCPL_ENVVARLIST;

typedef struct env_stack {
    NCPL_ENVVAR *var;
    struct env_stack *next;
}NCPL_ENVSTACK;

typedef struct env {
    NCPL_SYM *sym_tbl[SYMLEN];
    NCPL_ENVVAR *env_tbl[ENVLEN];
    NCPL_ENVSTACK *top;
    niffic_pool_t *pool;
}NCPL_ENV;

/*symbol*/
extern NCPL_SYM *ncpl_get_sym(NCPL_ENV *env, char *s);
extern NCPL_SYM *ncpl_new_sym(NCPL_ENV *env, char *s);
extern void ncpl_free_sym(NCPL_ENV *env, char *s);
/*envty*/
extern NCPL_ENVTY *ncpl_create_envty(NCPL_ENV *env, int type, NCPL_SYM *sym);
extern void ncpl_free_envty(NCPL_ENV *env, NCPL_ENVTY *typ);
/*envtylist*/
extern NCPL_ENVTYLIST *ncpl_create_envtylist(NCPL_ENV *env, NCPL_ENVTY *typ);
extern void ncpl_add_envtylist(NCPL_ENVTYLIST *cur, NCPL_ENVTYLIST *new);
extern void ncpl_free_all_envtylist(NCPL_ENV *env, NCPL_ENVTYLIST *tylist);
extern int ncpl_get_nr_param(NCPL_ENVTYLIST *tylist);
/*stack*/
extern void ncpl_env_push(NCPL_ENV *env, NCPL_ENVVAR *var);
extern NCPL_ENVSTACK *ncpl_env_pop(NCPL_ENV *env);
extern void ncpl_free_stack(NCPL_ENVSTACK* stack);
/*envvar*/
extern NCPL_ENVVAR *ncpl_new_envvar(NCPL_ENV *env, int type, \
NCPL_ENVTY *typ, NCPL_ENVTYLIST *tylist, const char *s);
extern NCPL_ENVVAR *ncpl_get_var(NCPL_ENV *env, NCPL_SYM *sym);
extern void ncpl_free_var(NCPL_ENV *env, NCPL_ENVVAR *var);
extern int ncpl_check_var_repeat(NCPL_ENV *env, NCPL_SYM *sym);
extern NCPL_ENVVAR *ncpl_push_new_variable(NCPL_ENV *env, \
char *s, int ty_type, int repeat_check);
extern void ncpl_push_new_function(NCPL_ENV *env, \
char *s, NCPL_ENVTY *ty_ty, NCPL_ENVTYLIST *tylist);
extern int ncpl_get_var_type(NCPL_ENV *env, char *s);
/*mark*/
extern void ncpl_push_mark(NCPL_ENV *env, char *s, int mark_ty);
extern void ncpl_pop_until_mark(NCPL_ENV *env);
/*print*/
extern void print_env(NCPL_ENV *env);
extern void print_env_var(NCPL_ENVVAR *var);
#endif

