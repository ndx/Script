/*
 * Copyright (C) Niklaus F.Schen.
 */

#ifndef __NCPL_TOOL
#define __NCPL_TOOL
#include"ncpl_env.h"

extern int ncpl_type_legal(int left, int right);
extern int ncpl_calc_type_result(int type1, int type2);
extern int ncpl_isnumeral(int type);
extern int ncpl_isinteger(int type);
extern int ncpl_islint1(int type);
extern int ncpl_islint2(int type);
extern int ncpl_islint3(int type);
extern int ncpl_issint1(int type);
extern int ncpl_issint2(int type);
extern int ncpl_issint3(int type);
extern int ncpl_isstring(int type);
extern int ncpl_ischar(int type);
extern int ncpl_isfloat(int type);
extern int ncpl_isfile(int type);
extern int ncpl_isshort(int type);
extern int ncpl_islong(int type);
extern int ncpl_isint(int type);
extern long ncpl_atol(char *s);
extern long long ncpl_atoll(char *s);
extern float ncpl_atof(char *s);

#endif

