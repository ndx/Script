/*
 * Copyright (C) Niklaus F.Schen.
 */

#ifndef __NCPL_PARSER_TBL_H
#define __NCPL_PARSER_TBL_H

#include "ncpl_lex.h"
#include "ncpl_env.h"
/*for ncpl_check_strfmt() to calc buffer size*/
#define N_NUMLEN 32
/*type*/
#define PERROR 0
#define PSHIFT 1
#define PREDUCE 2
#define PACCEPT 3
/*struct type*/
#define PCOMMON 0

typedef struct {
    int type;
    int seq; /*status or rule sequence*/
}NCPL_STATSW;

#define start 67
typedef struct ncpl_start_s NCPL_start;
#define stmlist 68
typedef struct ncpl_stmlist_s NCPL_stmlist;
#define stm 69
typedef struct ncpl_stm_s NCPL_stm;
#define ctlexp 70
typedef struct ncpl_ctlexp_s NCPL_ctlexp;
#define tydecl 71
typedef struct ncpl_tydecl_s NCPL_tydecl;
#define ty 72
typedef struct ncpl_ty_s NCPL_ty;
#define assign 73
typedef struct ncpl_assign_s NCPL_assign;
#define select_exp 74
typedef struct ncpl_select_exp_s NCPL_select_exp;
#define elsee 75
typedef struct ncpl_elsee_s NCPL_elsee;
#define loop_exp 76
typedef struct ncpl_loop_exp_s NCPL_loop_exp;
#define func_decl 77
typedef struct ncpl_func_decl_s NCPL_func_decl;
#define explist 78
typedef struct ncpl_explist_s NCPL_explist;
#define exp 79
typedef struct ncpl_exp_s NCPL_exp;
#define factor 80
typedef struct ncpl_factor_s NCPL_factor;
#define parenexp 81
typedef struct ncpl_parenexp_s NCPL_parenexp;
#define unary_opr 82
typedef struct ncpl_unary_opr_s NCPL_unary_opr;
#define castexp 83
typedef struct ncpl_castexp_s NCPL_castexp;
#define multiexp 84
typedef struct ncpl_multiexp_s NCPL_multiexp;
#define multiexp_prime 85
typedef struct ncpl_multiexp_prime_s NCPL_multiexp_prime;
#define addexp 86
typedef struct ncpl_addexp_s NCPL_addexp;
#define addexp_prime 87
typedef struct ncpl_addexp_prime_s NCPL_addexp_prime;
#define logicexp 88
typedef struct ncpl_logicexp_s NCPL_logicexp;
#define logic_prime 89
typedef struct ncpl_logic_prime_s NCPL_logic_prime;
#define relatexp 90
typedef struct ncpl_relatexp_s NCPL_relatexp;
#define relatexp_prime 91
typedef struct ncpl_relatexp_prime_s NCPL_relatexp_prime;
#define assignexp 92
typedef struct ncpl_assignexp_s NCPL_assignexp;
#define assignexp_prime 93
typedef struct ncpl_assignexp_prime_s NCPL_assignexp_prime;

typedef struct {
    int left;
    int nr_right;
    int right[8];
}NCPL_RULE;

typedef struct stack_s {
    int type;
    int in_status_no;
    int cur_rule;
    int rule_pos;
    void *ptr;
    struct stack_s *next;
}STACK;

/*for factor_type
 * and it supports lex's type and this one*/
#define EXPTYPE 0xffffffff
typedef struct {
    int type;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
}NCPL_RETVAL;

typedef struct ncpl_fd {
    int fd;
    struct ncpl_fd *next;
    struct ncpl_fd *prev;
}NCPL_FD;

#define FDHASH 512
#define N_LOGSIZE 1024

typedef struct {
    int pass_tychk; /*the mark that pass or not procedure of type-check*/
    int cur_status;
    int is_define;
    int ctlmark; /*for break and continue*/
    int log_len;/*equal to N_LOGSIZE*/
    char log[N_LOGSIZE];
    NCPL_LEX *lookahead;
    STACK *stack_top;
    STACK *store;
    niffic_pool_t *pool;
    NCPL_start *ptr;
    struct param_lex_s pls;
    NCPL_ENV env;
    NCPL_FD *fdhash[FDHASH];
}NCPL_PARSER;

typedef int (*RFUNC)(NCPL_PARSER *);

struct ncpl_start_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_stm *ncpl_0_0;
        }start_0;
    }u;
};

struct ncpl_stmlist_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_stm *ncpl_2_1;
        }stmlist_2;
    }u;
};

struct ncpl_stm_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_ctlexp *ncpl_3_0;
            NCPL_stmlist *ncpl_3_1;
        }stm_3;
        struct {
            NCPL_tydecl *ncpl_4_0;
            NCPL_stmlist *ncpl_4_1;
        }stm_4;
        struct {
            NCPL_select_exp *ncpl_5_0;
            NCPL_stmlist *ncpl_5_1;
        }stm_5;
        struct {
            NCPL_loop_exp *ncpl_6_0;
            NCPL_stmlist *ncpl_6_1;
        }stm_6;
        struct {
            NCPL_func_decl *ncpl_7_0;
            NCPL_stmlist *ncpl_7_1;
        }stm_7;
    }u;
};

struct ncpl_ctlexp_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_LEX *ncpl_9_0;
        }ctlexp_9;
        struct {
            NCPL_LEX *ncpl_10_0;
        }ctlexp_10;
        struct {
            NCPL_LEX *ncpl_11_0;
        }ctlexp_11;
    }u;
};

struct ncpl_tydecl_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_ty *ncpl_12_0;
            NCPL_factor *ncpl_12_1;
            NCPL_assign *ncpl_12_2;
        }tydecl_12;
    }u;
};

struct ncpl_ty_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_LEX *ncpl_13_0;
        }ty_13;
        struct {
            NCPL_LEX *ncpl_14_0;
        }ty_14;
        struct {
            NCPL_LEX *ncpl_15_0;
        }ty_15;
        struct {
            NCPL_LEX *ncpl_16_0;
        }ty_16;
        struct {
            NCPL_LEX *ncpl_17_0;
        }ty_17;
        struct {
            NCPL_LEX *ncpl_18_0;
        }ty_18;
        struct {
            NCPL_LEX *ncpl_19_0;
        }ty_19;
    }u;
};

struct ncpl_assign_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_LEX *ncpl_21_0;
            NCPL_exp *ncpl_21_1;
        }assign_21;
    }u;
};

struct ncpl_select_exp_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_exp *ncpl_23_2;
            NCPL_stm *ncpl_23_5;
            NCPL_elsee *ncpl_23_7;
        }select_exp_23;
    }u;
};

struct ncpl_elsee_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_stm *ncpl_24_2;
        }elsee_24;
    }u;
};

struct ncpl_loop_exp_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_exp *ncpl_26_2;
            NCPL_stm *ncpl_26_5;
        }loop_exp_26;
    }u;
};

struct ncpl_func_decl_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_LEX *ncpl_27_0;
            NCPL_exp *ncpl_27_2;
        }func_decl_27;
        struct {
            NCPL_LEX *ncpl_28_0;
            NCPL_exp *ncpl_28_2;
        }func_decl_28;
        struct {
            NCPL_LEX *ncpl_29_0;
            NCPL_exp *ncpl_29_2;
        }func_decl_29;
        struct {
            NCPL_LEX *ncpl_30_0;
            NCPL_exp *ncpl_30_2;
        }func_decl_30;
        struct {
            NCPL_LEX *ncpl_31_0;
            NCPL_exp *ncpl_31_2;
        }func_decl_31;
        struct {
            NCPL_LEX *ncpl_32_0;
            NCPL_exp *ncpl_32_2;
        }func_decl_32;
    }u;
};

struct ncpl_explist_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_exp *ncpl_34_1;
        }explist_34;
    }u;
};

struct ncpl_exp_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_func_decl *ncpl_35_0;
            NCPL_explist *ncpl_35_1;
        }exp_35;
        struct {
            NCPL_assignexp *ncpl_36_0;
            NCPL_explist *ncpl_36_1;
        }exp_36;
    }u;
};

struct ncpl_factor_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_LEX *ncpl_37_0;
        }factor_37;
        struct {
            NCPL_LEX *ncpl_38_0;
        }factor_38;
        struct {
            NCPL_LEX *ncpl_39_0;
        }factor_39;
        struct {
            NCPL_LEX *ncpl_40_0;
        }factor_40;
        struct {
            NCPL_LEX *ncpl_41_0;
        }factor_41;
        struct {
            NCPL_LEX *ncpl_42_0;
        }factor_42;
        struct {
            NCPL_LEX *ncpl_43_0;
        }factor_43;
    }u;
};

struct ncpl_parenexp_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_factor *ncpl_44_0;
        }parenexp_44;
        struct {
            NCPL_exp *ncpl_45_1;
        }parenexp_45;
    }u;
};

struct ncpl_unary_opr_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_LEX *ncpl_46_0;
        }unary_opr_46;
        struct {
            NCPL_LEX *ncpl_47_0;
        }unary_opr_47;
        struct {
            NCPL_LEX *ncpl_48_0;
        }unary_opr_48;
    }u;
};

struct ncpl_castexp_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_parenexp *ncpl_49_0;
        }castexp_49;
        struct {
            NCPL_unary_opr *ncpl_50_0;
            NCPL_parenexp *ncpl_50_1;
        }castexp_50;
    }u;
};

struct ncpl_multiexp_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_castexp *ncpl_51_0;
            NCPL_multiexp_prime *ncpl_51_1;
        }multiexp_51;
    }u;
};

struct ncpl_multiexp_prime_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_LEX *ncpl_52_0;
            NCPL_multiexp *ncpl_52_1;
        }multiexp_prime_52;
        struct {
            NCPL_LEX *ncpl_53_0;
            NCPL_multiexp *ncpl_53_1;
        }multiexp_prime_53;
        struct {
            NCPL_LEX *ncpl_54_0;
            NCPL_multiexp *ncpl_54_1;
        }multiexp_prime_54;
    }u;
};

struct ncpl_addexp_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_multiexp *ncpl_56_0;
            NCPL_addexp_prime *ncpl_56_1;
        }addexp_56;
    }u;
};

struct ncpl_addexp_prime_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_LEX *ncpl_57_0;
            NCPL_addexp *ncpl_57_1;
        }addexp_prime_57;
        struct {
            NCPL_LEX *ncpl_58_0;
            NCPL_addexp *ncpl_58_1;
        }addexp_prime_58;
    }u;
};

struct ncpl_logicexp_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_addexp *ncpl_60_0;
            NCPL_logic_prime *ncpl_60_1;
        }logicexp_60;
    }u;
};

struct ncpl_logic_prime_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_LEX *ncpl_61_0;
            NCPL_logicexp *ncpl_61_1;
        }logic_prime_61;
        struct {
            NCPL_LEX *ncpl_62_0;
            NCPL_logicexp *ncpl_62_1;
        }logic_prime_62;
        struct {
            NCPL_LEX *ncpl_63_0;
            NCPL_logicexp *ncpl_63_1;
        }logic_prime_63;
    }u;
};

struct ncpl_relatexp_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_logicexp *ncpl_65_0;
            NCPL_relatexp_prime *ncpl_65_1;
        }relatexp_65;
    }u;
};

struct ncpl_relatexp_prime_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_LEX *ncpl_66_0;
            NCPL_relatexp *ncpl_66_1;
        }relatexp_prime_66;
        struct {
            NCPL_LEX *ncpl_67_0;
            NCPL_relatexp *ncpl_67_1;
        }relatexp_prime_67;
        struct {
            NCPL_LEX *ncpl_68_0;
            NCPL_relatexp *ncpl_68_1;
        }relatexp_prime_68;
        struct {
            NCPL_LEX *ncpl_69_0;
            NCPL_relatexp *ncpl_69_1;
        }relatexp_prime_69;
        struct {
            NCPL_LEX *ncpl_70_0;
            NCPL_relatexp *ncpl_70_1;
        }relatexp_prime_70;
        struct {
            NCPL_LEX *ncpl_71_0;
            NCPL_relatexp *ncpl_71_1;
        }relatexp_prime_71;
        struct {
            NCPL_LEX *ncpl_72_0;
            NCPL_relatexp *ncpl_72_1;
        }relatexp_prime_72;
        struct {
            NCPL_LEX *ncpl_73_0;
            NCPL_relatexp *ncpl_73_1;
        }relatexp_prime_73;
    }u;
};

struct ncpl_assignexp_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_relatexp *ncpl_75_0;
            NCPL_assignexp_prime *ncpl_75_1;
        }assignexp_75;
    }u;
};

struct ncpl_assignexp_prime_s {
    int type;
    int line;
    int retval;
    int factor_type;
    char *factor_str;
    NCPL_VALUE *val;
    union {
        struct {
            NCPL_LEX *ncpl_76_0;
            NCPL_assignexp *ncpl_76_1;
        }assignexp_prime_76;
    }u;
};


extern int ncpl_parse(NCPL_PARSER *p);
extern int ncpl_visit(NCPL_PARSER *);
extern NCPL_FD *ncpl_new_fd(niffic_pool_t *pool, int fd);
extern void ncpl_free_fd(NCPL_FD *f, int need_close);
extern void ncpl_add_fd(NCPL_FD *f, NCPL_FD **tbl);
extern void ncpl_del_fd(NCPL_FD *f, NCPL_FD **tbl);
extern void ncpl_close_all_fd(NCPL_FD **tbl);
extern NCPL_FD *ncpl_get_fd(int fd, NCPL_FD **tbl);
extern NCPL_RETVAL *ncpl_lex_visit(NCPL_PARSER *, NCPL_LEX *);
extern NCPL_RETVAL *ncpl_start_visit(NCPL_PARSER *, NCPL_start *);
extern NCPL_RETVAL *ncpl_stmlist_visit(NCPL_PARSER *, NCPL_stmlist *);
extern NCPL_RETVAL *ncpl_stm_visit(NCPL_PARSER *, NCPL_stm *);
extern NCPL_RETVAL *ncpl_ctlexp_visit(NCPL_PARSER *, NCPL_ctlexp *);
extern NCPL_RETVAL *ncpl_tydecl_visit(NCPL_PARSER *, NCPL_tydecl *);
extern NCPL_RETVAL *ncpl_ty_visit(NCPL_PARSER *, NCPL_ty *);
extern NCPL_RETVAL *ncpl_assign_visit(NCPL_PARSER *, NCPL_assign *);
extern NCPL_RETVAL *ncpl_select_exp_visit(NCPL_PARSER *, NCPL_select_exp *);
extern NCPL_RETVAL *ncpl_elsee_visit(NCPL_PARSER *, NCPL_elsee *);
extern NCPL_RETVAL *ncpl_loop_exp_visit(NCPL_PARSER *, NCPL_loop_exp *);
extern NCPL_RETVAL *ncpl_func_decl_visit(NCPL_PARSER *, NCPL_func_decl *);
extern NCPL_RETVAL *ncpl_explist_visit(NCPL_PARSER *, NCPL_explist *);
extern NCPL_RETVAL *ncpl_exp_visit(NCPL_PARSER *, NCPL_exp *);
extern NCPL_RETVAL *ncpl_factor_visit(NCPL_PARSER *, NCPL_factor *);
extern NCPL_RETVAL *ncpl_parenexp_visit(NCPL_PARSER *, NCPL_parenexp *);
extern NCPL_RETVAL *ncpl_unary_opr_visit(NCPL_PARSER *, NCPL_unary_opr *);
extern NCPL_RETVAL *ncpl_castexp_visit(NCPL_PARSER *, NCPL_castexp *);
extern NCPL_RETVAL *ncpl_multiexp_visit(NCPL_PARSER *, NCPL_multiexp *);
extern NCPL_RETVAL *ncpl_multiexp_prime_visit(NCPL_PARSER *, NCPL_multiexp_prime *);
extern NCPL_RETVAL *ncpl_addexp_visit(NCPL_PARSER *, NCPL_addexp *);
extern NCPL_RETVAL *ncpl_addexp_prime_visit(NCPL_PARSER *, NCPL_addexp_prime *);
extern NCPL_RETVAL *ncpl_logicexp_visit(NCPL_PARSER *, NCPL_logicexp *);
extern NCPL_RETVAL *ncpl_logic_prime_visit(NCPL_PARSER *, NCPL_logic_prime *);
extern NCPL_RETVAL *ncpl_relatexp_visit(NCPL_PARSER *, NCPL_relatexp *);
extern NCPL_RETVAL *ncpl_relatexp_prime_visit(NCPL_PARSER *, NCPL_relatexp_prime *);
extern NCPL_RETVAL *ncpl_assignexp_visit(NCPL_PARSER *, NCPL_assignexp *);
extern NCPL_RETVAL *ncpl_assignexp_prime_visit(NCPL_PARSER *, NCPL_assignexp_prime *);

#endif

