
/*
 * Copyright (C) Niklaus F.Schen.
 */

/*
Functions:
	niffic_new_pool() niffic_alloc() niffic_free()
	niffic_free_pool()
attention:
	If users want to use niffic_alloc() to allocate a 
	memory block, you need to call niffic_new_pool()	
	to create a pool at first.
	After calling niffic_free_pool(), don't forget
	to set pointer to equal NULL.
        Have a nice hacking.
*/

#ifndef __MLIB_ALLOC
#define __MLIB_ALLOC
#include<string.h>
#include<stdlib.h>

#define ADDLEN sizeof(niffic_buffer_t)+sizeof(unsigned long)
#define N_M_INFINITE ~0
#define xB ((unsigned long)(x))
#define xK (((unsigned long)(x))<<10)
#define xM ((((unsigned long)(x))<<10)<<10)
#define xG (((((unsigned long)(x))<<10)<<10)<<10)
#define xT ((((((unsigned long)(x))<<10)<<10)<<10)<<10)

typedef struct niffic_buffer_s niffic_buffer_t;

typedef struct niffic_block_s {
    niffic_buffer_t *buf;
    struct niffic_block_s *next;
    struct niffic_block_s *prev;
}niffic_block_t;

typedef struct niffic_list_s {
    niffic_block_t *used;
    niffic_block_t *free;
    unsigned long nr_free;
    unsigned long nr_used;
}niffic_list_t;

typedef struct niffic_pool_s {
    unsigned long limit;
    unsigned long used;
    unsigned long nrblk_limit;
    niffic_list_t list[sizeof(long *)<<3];
}niffic_pool_t;

struct niffic_buffer_s {
    niffic_pool_t *pool;
    niffic_list_t *list;
    niffic_block_t *blk;
    void *buf;
};

extern niffic_pool_t *niffic_new_pool(unsigned long limit, unsigned long nrblk_limit);
extern void niffic_free_pool(niffic_pool_t *pool);
extern void *niffic_alloc(niffic_pool_t *pool, unsigned long size);
extern void niffic_free(void *ptr);
extern void niffic_print_pool(niffic_pool_t *pool);
#endif

