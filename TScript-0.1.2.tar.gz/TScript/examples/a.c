#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"ncpl_start.h"


int main(int argc, char *argv[])
{
    char buf[1024];
    memset(buf, 0, sizeof(buf));
    if( argc!=2 ) {
        fprintf(stderr, "%s filepath\n", argv[0]);
        exit(1);
    }
    if( ncpl_script(argv[1], buf, 1024)<0 ) {
        fprintf(stderr, "%s\n", buf);
        return -1;
    }
    return 0;
}

