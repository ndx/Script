int i = 1;
while( i<10 ) {
   if( i>5 ) {
      int i = 100;
      print("i:%d\n", i);
      break;
      print("shouldn't be here.\n");
   };
   i = i +1;
   print("the outside:%d\n", i);
};
print("end i:%d\n", i);
