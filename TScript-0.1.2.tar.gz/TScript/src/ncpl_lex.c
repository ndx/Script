/*
 * Copyright (C) Niklaus F.Schen.
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<assert.h>
#include<errno.h>
#include<unistd.h>
#include<ctype.h>
#include"ncpl_lex.h"

/*
 * Static declarations
 */
#define isletter(c) (isalpha((c))||(c)=='_')
#define isname(c) (isletter((c))||isdigit((c)))
static NCPL_LEX *ncpl_get_lex_node(struct param_lex_s *pls, int type);
static NCPL_LEX *ncpl_spec_common_func(struct param_lex_s *pls, char *ch, int type);
static NCPL_LEX *ncpl_spec_div_func(struct param_lex_s *pls, char *ch, int type);
static NCPL_LEX *ncpl_spec_excl_func(struct param_lex_s *pls, char *ch, int type);
static NCPL_LEX *ncpl_spec_less_func(struct param_lex_s *pls, char *ch, int type);
static NCPL_LEX *ncpl_spec_greater_func(struct param_lex_s *pls, char *ch, int type);
static NCPL_LEX *ncpl_spec_equal_func(struct param_lex_s *pls, char *ch, int type);
static NCPL_LEX *ncpl_spec_sub_func(struct param_lex_s *pls, char *ch, int type);
static NCPL_LEX *ncpl_spec_add_func(struct param_lex_s *pls, char *ch, int type);
static NCPL_LEX *ncpl_spec_or_func(struct param_lex_s *pls, char *ch, int type);
static NCPL_LEX *ncpl_spec_and_func(struct param_lex_s *pls, char *ch, int type);
static NCPL_LEX *ncpl_spec_backslash_func(struct param_lex_s *pls, char *ch, int type);
static NCPL_LEX *ncpl_spec_pound_func(struct param_lex_s *pls, char *ch, int type);
static NCPL_LEX *ncpl_spec_point_func(struct param_lex_s *pls, char *ch, int type);
static NCPL_LEX *ncpl_spec_charac_func(struct param_lex_s *pls, char *ch, int type);
static NCPL_LEX *ncpl_spec_string_func(struct param_lex_s *pls, char *ch, int type);
static NCPL_LEX *ncpl_id_func(struct param_lex_s *pls, char *ch);
static NCPL_LEX *ncpl_num_func(struct param_lex_s *pls, char *ch);


/*global tables*/
char spec_tbl[NRSPEC] = "!%*/+-=><{}[]()?:;.,~'\"$&|\\#^";
char keywords_tbl[NRKEYW][SYLEN] = {
"if", "else", "while", "for", "int",
"float", "long", "char", "short",
"static", "void", "const", "return",
"query", "fclose", "file", "string",
"NULL", "fopen", "continue", "break",
"ferr", "print", "lseek", "eof"
};

ncpl_keyf keywordfunc_tbl[NRSPEC] = {
ncpl_spec_excl_func, ncpl_spec_common_func,
ncpl_spec_common_func, ncpl_spec_div_func,
ncpl_spec_add_func, ncpl_spec_sub_func,
ncpl_spec_equal_func, ncpl_spec_greater_func,
ncpl_spec_less_func, ncpl_spec_common_func,
ncpl_spec_common_func, ncpl_spec_common_func,
ncpl_spec_common_func, ncpl_spec_common_func,
ncpl_spec_common_func, ncpl_spec_common_func,
ncpl_spec_common_func, ncpl_spec_common_func,
ncpl_spec_point_func, ncpl_spec_common_func,
ncpl_spec_common_func, ncpl_spec_charac_func,
ncpl_spec_string_func, ncpl_spec_common_func,
ncpl_spec_and_func, ncpl_spec_or_func,
ncpl_spec_backslash_func, ncpl_spec_pound_func,
ncpl_spec_common_func
};

char keywordmap[NRALL][NAMELEN] = {
"EXCL", "PERC", "MUL", "DIV", "ADD", "SUB",
"EQ", "GREA", "LESS", "LBRACE", "RBRACE",
"LBRACK", "RBRACK", "LPAREN", "RPAREN",
"QUEST", "COLON", "SEMIC", "POINT", "COMMA",
"NEGATE", "CHARAC", "STRING", "DOLLAR",
"AND", "OR", "BACKSLASH", "POUND", "XOR",
"RAND", "ROR", "GEQUAL", "LEQUAL", "EQUAL",
"NEQUAL", "INC", "DEC", "INUM", "FNUM", "ID",
"COMMENT", "IF", "ELSE", "WHILE", "FOR",
"INT", "FLOAT", "LONG", "CHAR", "SHORT",
"STATIC", "VOID", "CONST", "RETURN", "QUERY",
"FCLOSE", "FFILE", "STR", "NUL", "FOPEN",
"CONTINUE", "BREAK", "FERR", "PRINT",
"LSEEK", "EOFF", "ENDFILE"
};

/*
 * Let's Begin.
 * This lexer do not support character '$'.
 * This character wiil be treated as EOF.
 * So if this character appeared in file, lexer would stop
 * analysing when it encountered '$'.
 * --abolished***!!!Warning:Every token is ended by ' ', '\t' or '\n'.
 */
NCPL_LEX *ncpl_token(struct param_lex_s *pls)
{
    char *scan, *end, ch;
lp: if( pls->ch==-1 ) {
        ch = ncpl_getone(pls);
    } else {
        ch = pls->ch;
    }
    while( ch=='\t' || ch==' ' ) {
        ch = ncpl_getone(pls);
    }
    while( ch=='\n' ) {
        pls->line++;
        ch = ncpl_getone(pls);
    }
    if( ch=='\t' || ch==' ' )
        goto lp;
    scan = spec_tbl; end = spec_tbl + NRSPEC;
    NCPL_LEX *lex;
    for(; scan<end; scan++) {
        if( *scan==ch ) {
            lex = keywordfunc_tbl[scan-spec_tbl](pls, &ch, scan-spec_tbl);
            if( lex==NULL ) {
                return NULL;
            } else if( lex->type==COMMENT ) {
                ncpl_free_lex_node(lex);
                goto lp;
            }
            return lex;
        }
    }
    if( isletter(ch) )
        return ncpl_id_func(pls, &ch);
    else if( isdigit(ch) )
        return ncpl_num_func(pls, &ch);
    else if( ch==END_OF_FILE ) {
        ncpl_put_in_buf(pls); ch = ncpl_getone(pls);
        return ncpl_get_lex_node(pls, ENDFILE);
    }
    memset(pls->log, 0, pls->log_len);
    snprintf(pls->log, pls->log_len, "%s:%d: Invalid character '0x%x[%c]'.", pls->file, pls->line, ch, ch);
    return NULL;
}


/*ID and NUM functions*/
static NCPL_LEX *ncpl_id_func(struct param_lex_s *pls, char *ch)
{
    do {
        ncpl_put_in_buf(pls);
        *ch = ncpl_getone(pls);
    } while( isname(*ch) );
    int i;
    for(i = 0; i<NRSPEC; i++) {
        if( !strcmp(pls->ptr_token, keywords_tbl[i]) ) {
            return ncpl_get_lex_node(pls, i+KEYSTART);
        }
    }
    return ncpl_get_lex_node(pls, ID);
}

static NCPL_LEX *ncpl_num_func(struct param_lex_s *pls, char *ch)
{
    int point = 0, type = INUM;
    int x_num = 0, cnt = 0, is_hex = 0;
    while( 1 ) {
        ncpl_put_in_buf(pls); cnt++;
        *ch = ncpl_getone(pls);
        if( *ch=='.' ) {
            point++;
            type = FNUM;
            continue;
        } else if( isdigit(*ch) ) {
            continue;
        } else {
            if( *ch=='x' && !x_num && cnt==1 ) {
                is_hex = 1;
                continue;
            }
            if( ((*ch>='a' && *ch<='f') || (*ch>='A' && *ch<='F')) && is_hex )
                continue;
            break;
        }
    }
    if( x_num>1 ) {
        memset(pls->log, 0, pls->log_len);
        snprintf(pls->log, pls->log_len, "%s:%d: Too many 'x' in hex.", \
        pls->file, pls->line);
        return NULL;
    }
    if( point>1 ) {
        memset(pls->log, 0, pls->log_len);
        snprintf(pls->log, pls->log_len, "%s:%d: Too many point in float.", \
        pls->file, pls->line);
        return NULL;
    }
    return ncpl_get_lex_node(pls, type);
}

/*keywords function table*/
static NCPL_LEX *ncpl_spec_common_func(struct param_lex_s *pls, char *ch, int type)
{
    ncpl_put_in_buf(pls); *ch = ncpl_getone(pls);
    return ncpl_get_lex_node(pls, type);
}

static NCPL_LEX *ncpl_spec_div_func(struct param_lex_s *pls, char *ch, int type)
{
    ncpl_put_in_buf(pls); *ch = ncpl_getone(pls);
    if( *ch=='*' ) {
        ncpl_put_in_buf(pls);
        while( 1 ) {
            *ch = ncpl_getone(pls);
            if( *ch==END_OF_FILE ) {
                return ncpl_get_lex_node(pls, COMMENT);
            } else if( *ch=='*' ) {
                *ch = ncpl_getone(pls);
                if( *ch=='/' ) {
                    *ch = ncpl_getone(pls);
                    return ncpl_get_lex_node(pls, COMMENT);
                }
            }
        }
    } else if( *ch=='/' ) {
        ncpl_put_in_buf(pls);
        while( 1 ) {
            *ch = ncpl_getone(pls);
            if( *ch==END_OF_FILE ) {
                return ncpl_get_lex_node(pls, COMMENT);
            } else if( *ch=='\n' ) {
                return ncpl_get_lex_node(pls, COMMENT);
            }
        }
    }
    return ncpl_get_lex_node(pls, type);
}

static NCPL_LEX *ncpl_spec_add_func(struct param_lex_s *pls, char *ch, int type)
{
    ncpl_put_in_buf(pls); *ch = ncpl_getone(pls);
    if( *ch!='+' )
        return ncpl_get_lex_node(pls, type);
    ncpl_put_in_buf(pls);
    *ch = ncpl_getone(pls);
    return ncpl_get_lex_node(pls, INC);
}

static NCPL_LEX *ncpl_spec_sub_func(struct param_lex_s *pls, char *ch, int type)
{
    ncpl_put_in_buf(pls); *ch = ncpl_getone(pls);
    if( *ch!='-' )
        return ncpl_get_lex_node(pls, type);
    ncpl_put_in_buf(pls);
    *ch = ncpl_getone(pls);
    return ncpl_get_lex_node(pls, DEC);
}

static NCPL_LEX *ncpl_spec_equal_func(struct param_lex_s *pls, char *ch, int type)
{
    ncpl_put_in_buf(pls); *ch = ncpl_getone(pls);
    if( *ch!='=' )
        return ncpl_get_lex_node(pls, type);
    ncpl_put_in_buf(pls);
    *ch = ncpl_getone(pls);
    return ncpl_get_lex_node(pls, EQUAL);
}

static NCPL_LEX *ncpl_spec_greater_func(struct param_lex_s *pls, char *ch, int type)
{
    ncpl_put_in_buf(pls); *ch = ncpl_getone(pls);
    if( *ch!='=' )
        return ncpl_get_lex_node(pls, type);
    ncpl_put_in_buf(pls);
    *ch = ncpl_getone(pls);
    return ncpl_get_lex_node(pls, GEQUAL);
}

static NCPL_LEX *ncpl_spec_less_func(struct param_lex_s *pls, char *ch, int type)
{
    ncpl_put_in_buf(pls); *ch = ncpl_getone(pls);
    if( *ch!='=' )
        return ncpl_get_lex_node(pls, type);
    ncpl_put_in_buf(pls);
    *ch = ncpl_getone(pls);
    return ncpl_get_lex_node(pls, LEQUAL);
}

static NCPL_LEX *ncpl_spec_excl_func(struct param_lex_s *pls, char *ch, int type)
{
    ncpl_put_in_buf(pls); *ch = ncpl_getone(pls);
    if( *ch!='=' )
        return ncpl_get_lex_node(pls, type);
    ncpl_put_in_buf(pls);
    *ch = ncpl_getone(pls);
    return ncpl_get_lex_node(pls, NEQUAL);
}

static NCPL_LEX *ncpl_spec_and_func(struct param_lex_s *pls, char *ch, int type)
{
    ncpl_put_in_buf(pls); *ch = ncpl_getone(pls);
    if( *ch!='&' )
        return ncpl_get_lex_node(pls, type);
    ncpl_put_in_buf(pls);
    *ch = ncpl_getone(pls);
    return ncpl_get_lex_node(pls, RAND);
}

static NCPL_LEX *ncpl_spec_or_func(struct param_lex_s *pls, char *ch, int type)
{
    ncpl_put_in_buf(pls); *ch = ncpl_getone(pls);
    if( *ch!='|' )
        return ncpl_get_lex_node(pls, type);
    ncpl_put_in_buf(pls);
    *ch = ncpl_getone(pls);
    return ncpl_get_lex_node(pls, ROR);
}

static NCPL_LEX *ncpl_spec_point_func(struct param_lex_s *pls, char *ch, int type)
{
    ncpl_put_in_buf(pls); *ch = ncpl_getone(pls);
    if( !isdigit(*ch) )
        return ncpl_get_lex_node(pls, type);
    do {
        ncpl_put_in_buf(pls);
        *ch = ncpl_getone(pls);
    } while( isdigit(*ch) );
    return ncpl_get_lex_node(pls, FNUM);
}

static NCPL_LEX *ncpl_spec_backslash_func(struct param_lex_s *pls, char *ch, int type)
{
    ncpl_put_in_buf(pls); *ch = ncpl_getone(pls);
    if( *ch!='\n' ) {
        memset(pls->log, 0, pls->log_len);
        snprintf(pls->log, pls->log_len, "%s:%d: Invalid character '\\' .", pls->file, pls->line);
        return NULL;
    }
    *ch = ncpl_getone(pls);
    return ncpl_get_lex_node(pls, COMMENT);
}

static NCPL_LEX *ncpl_spec_charac_func(struct param_lex_s *pls, char *ch, int type)
{
    int ret;
    *ch = ncpl_getone(pls);
    if( *ch==END_OF_FILE ) {
        memset(pls->log, 0, pls->log_len);
        snprintf(pls->log, pls->log_len, "%s:%d: Type character incompleted.", pls->file, pls->line);
        return NULL;
    } else if( *ch=='\'' ) {
        memset(pls->log, 0, pls->log_len);
        snprintf(pls->log, pls->log_len, "%s:%d: Character is NULL.", pls->file, pls->line);
        return NULL;
    } else if( *ch=='\\' ) {
        if( (ret = ncpl_translate(pls, *ch))<0 )
            return NULL;
    } else {
        ncpl_put_in_buf(pls);
    }
    *ch = ncpl_getone(pls);
    if( *ch!='\'' ) {
        memset(pls->log, 0, pls->log_len);
        snprintf(pls->log, pls->log_len, "%s:%d: Lost character ' .", pls->file, pls->line);
        return NULL;
    }
    *ch = ncpl_getone(pls);
    return ncpl_get_lex_node(pls, type);
}

static NCPL_LEX *ncpl_spec_string_func(struct param_lex_s *pls, char *ch, int type)
{
    int ret;
    while( 1 ) {
        *ch = ncpl_getone(pls);
        if( *ch==END_OF_FILE ) {
            memset(pls->log, 0, pls->log_len);
            snprintf(pls->log, pls->log_len, "%s:%d: Lost character \" .", pls->file, pls->line);
            break;
        }
        if( *ch=='"' ) {
            *ch = ncpl_getone(pls);
            return ncpl_get_lex_node(pls, type);
        } else if( *ch=='\\' ) {
            if( (ret = ncpl_translate(pls, *ch))<0 )
                return NULL;
        } else {
            ncpl_put_in_buf(pls);
        }
    }
    return NULL;
}

static NCPL_LEX *ncpl_spec_pound_func(struct param_lex_s *pls, char *ch, int type)
{
    ncpl_put_in_buf(pls); *ch = ncpl_getone(pls);
    return ncpl_get_lex_node(pls, type);
}

/*components*/
int ncpl_translate(struct param_lex_s *pls, char ch)
{
    char c = ncpl_getone(pls);
    switch( c ) {
        case '\n':
            break;
        case '0':
            pls->ch = 0;
            ncpl_put_in_buf(pls);
            break;
        case '"':
            ncpl_put_in_buf(pls);
            break;
        case '\'':
            ncpl_put_in_buf(pls);
            break;
        case '\\':
            pls->ch = '\\';
            ncpl_put_in_buf(pls);
            break;
        case 'n':
            pls->ch = '\n';
            ncpl_put_in_buf(pls);
            break;
        case 't':
            pls->ch = '\t';
            ncpl_put_in_buf(pls);
            break;
        case 'b':
            pls->ch = '\b';
            ncpl_put_in_buf(pls);
            break;
        case 'a':
            pls->ch = '\a';
            ncpl_put_in_buf(pls);
            break;
        case 'f':
            pls->ch = '\f';
            ncpl_put_in_buf(pls);
            break;
        case 'r':
            pls->ch = '\r';
            ncpl_put_in_buf(pls);
            break;
        case 'v':
            pls->ch = '\v';
            ncpl_put_in_buf(pls);
            break;
        default:
            pls->ch = ch;
            ncpl_put_in_buf(pls);
            pls->ch = c;
            ncpl_put_in_buf(pls);
            break;
    }
    return 0;
}

void ncpl_put_in_buf(struct param_lex_s *pls)
{
    if( pls->pos_token==pls->len_token ) {
        memset(pls->log, 0, pls->log_len);
        snprintf(pls->log, pls->log_len, "%s:%d: String too much long.", pls->file, pls->line);
        exit(1);
    }
    pls->ptr_token[pls->pos_token++] = pls->ch;
}

char ncpl_getone(struct param_lex_s *pls)
{
    if( pls->len_buffer==pls->pos_buffer ) {
        memset(pls->ptr_buf, 0, pls->len_buffer);
        pls->pos_buffer = 0;
        pls->len_buffer = read(pls->fd, pls->ptr_buf, LINELEN);
        if( pls->len_buffer==0 ) {
            pls->ch = pls->ptr_buf[pls->pos_buffer++] = END_OF_FILE;
            return END_OF_FILE;
        } else if( pls->len_buffer<0 ) {
            perror("read"); exit(1);
        }
    }
    pls->ch = pls->ptr_buf[pls->pos_buffer++];
    return pls->ch;
}

static NCPL_LEX *ncpl_get_lex_node(struct param_lex_s *pls, int type)
{
    NCPL_LEX *lex = ncpl_create_lex_node(pls, type);
    memset(pls->ptr_token, 0, pls->len_token);
    pls->pos_token = 0;
    return lex;
}

int ncpl_lex_atoi(char *str)  /*map all macro-strings to their integer*/
{
    int i;
    for(i = 0; i<NRALL; i++) {
        if( !strcmp(keywordmap[i], str) )
            return i;
    }
    return -1;
}

/*structure*/
NCPL_LEX *ncpl_create_lex_node(struct param_lex_s *pls, int type)
{
    NCPL_LEX *lex = (NCPL_LEX *)niffic_alloc(pls->pool, sizeof(NCPL_LEX));
    assert(lex);
    lex->type = type;
    lex->line = pls->line;
    strncpy(lex->content, pls->ptr_token, (pls->pos_token>NAMELEN)?NAMELEN:pls->pos_token);
    return lex;
}

void ncpl_free_lex_node(NCPL_LEX *lex)
{
    niffic_free(lex);
}

