/*
 * Copyright (C) Niklaus F.Schen.
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<errno.h>
#include<unistd.h>
#include<fcntl.h>
#include<assert.h>
#include<errno.h>
#include"ncpl_parser_constructor.h"

static void init(int argc, char *argv[], struct param_lex_s *pls);
static CHARA *get_chara_node(NCPL_LEX *lex, CONSTRUCTOR *cst);
static NCPL_LEX *get_lex(struct param_lex_s *pls, CONSTRUCTOR *cst);
static int build_rules(struct param_lex_s *pls, CONSTRUCTOR *cst);
static void build_right_rule(struct param_lex_s *pls, CONSTRUCTOR *cst, RULE *rule);
static void build_ignore_tbl(struct param_lex_s *pls, CONSTRUCTOR *cst);
static SET *get_set_node(CHARA *c, SET *set);
static void calc_nullable(CONSTRUCTOR *cst);
static void calc_first(CONSTRUCTOR *cst);
static int check_first(CONSTRUCTOR *cst);
static void calc_follow(CONSTRUCTOR *cst);
static void closure(STATUS *s, CONSTRUCTOR *cst);
static STATUS *get_status_node(STATUS *s, CONSTRUCTOR *cst);
static void Goto(STATUS *s, CONSTRUCTOR *cst);
static int check_rule_repeat(RULE *r, STATUS *s, CHARA *la);
static int calc_items(STATUS *s);
static void print(CONSTRUCTOR *cst);
static void print_status(STATUS *s);
static int isTerminal(CHARA *c, CONSTRUCTOR *cst);
static int isIgnore(NCPL_LEX *lex, CONSTRUCTOR *cst);
static int statuscmp(STATUS *s1, STATUS *s2);
static int itemcmp(ITEM *i1, ITEM *i2);
static int lookaheadcmp(ITEM *i, CHARA *c);
static void move_lookahead_item(ITEM *dest, ITEM *src);
static void move_lookahead(STATUS *dest, STATUS *src);
static void fix_goto_status(STATUS *status, int nr_status, int oldid, int newid);
static void rebuild_status_tbl(STATUS *status, int nr_status, CONSTRUCTOR *cst);
static void build_lalr(CONSTRUCTOR *cst);
static void check_conflicts(CONSTRUCTOR *cst);
static int check_lookahead_repeat(ITEM *i1, ITEM *i2);
static void build_func_constructor(FILE *fp, CONSTRUCTOR *cst);
static void build_func_constructor_param(FILE *fp, RULE *rule, CONSTRUCTOR *cst);
static void build_func_constructor_content(FILE *fp, RULE *rule, CONSTRUCTOR *cst);

static void create_header_file(CONSTRUCTOR *cst);
static void build_struct(FILE *fp, CONSTRUCTOR *cst);
static void build_struct_content(FILE *fp, RULE *r, CONSTRUCTOR *cst);
static int rightcmp(RULE *r1, RULE *r2);
static void create_source_file(CONSTRUCTOR *cst);
static void build_include(FILE *fp);
static void build_rule_tbl(FILE *fp, CONSTRUCTOR *cst);
static void build_status_tbl(FILE *fp, CONSTRUCTOR *cst);
static void build_status_item(FILE *fp, STATUS *s, CONSTRUCTOR *cst, int num);
static void build_status_type(FILE *fp, STATUS *s, ITEM *it, CONSTRUCTOR *cst, int type);
static int map_atoi(char *str, CONSTRUCTOR *cst);
static void build_declaration(FILE *fp, CONSTRUCTOR *cst);
static void build_func_tbl(FILE *fp, CONSTRUCTOR *cst);
static void build_stack(FILE *fp);
static void build_rule_functions(FILE *fp, CONSTRUCTOR *cst);
static void build_rule_func_content(FILE *fp, RULE *rule, CONSTRUCTOR *cst);
static void build_rule_func_null(FILE *fp, RULE *rule, CONSTRUCTOR *cst);
static void build_parser(FILE *fp, CONSTRUCTOR *cst);
static void create_visit_file(CONSTRUCTOR *cst);
static void build_visit_declarations(FILE *fp, CONSTRUCTOR *cst);
static void build_visit(FILE *fp, CONSTRUCTOR *cst);
static void build_visit_nonterminal(FILE *fp, CONSTRUCTOR *cst, RULE *rule);
static void build_visit_rule_right(FILE *fp, CONSTRUCTOR *cst, RULE *rule);
static void build_escape_declarations(FILE *fp, CONSTRUCTOR *cst);
static void create_escape_file(CONSTRUCTOR *cst);
static void build_escape(FILE *fp, CONSTRUCTOR *cst);
static void build_escape_nonterminal(FILE *fp, CONSTRUCTOR *cst, RULE *rule);
static void build_escape_rule_right(FILE *fp, CONSTRUCTOR *cst, RULE *rule);

char src_file[FILENAME];
char header_file[FILENAME];
char visit_file[FILENAME];
char src_name[FILENAME];
char header_name[FILENAME];
char visit_name[FILENAME];
char esc_file[FILENAME];
char esc_name[FILENAME];
int ignore = 0;

int main(int argc, char *argv[])
{
    struct param_lex_s pls;
    memset(&pls, 0, sizeof(pls));
    pls.pool = niffic_new_pool(N_M_INFINITE, 1024);
    init(argc, argv, &pls);
    CONSTRUCTOR cst;
    memset(&cst, 0, sizeof(cst));
    if( build_rules(&pls, &cst)<0 ) {
        fprintf(stderr, "building rules failed.\n");
        exit(1);
    }
    if( ignore ) {
        build_ignore_tbl(&pls, &cst);
    }
    if( !cst.nr_rule ) exit(0);
    calc_nullable(&cst);
    calc_first(&cst);
    if( check_first(&cst)<0 ) {
        exit(1);
    }
    calc_follow(&cst);
    Goto(NULL, &cst);
    build_lalr(&cst);
    print(&cst);
    check_conflicts(&cst);
    create_header_file(&cst);
    create_source_file(&cst);
    create_visit_file(&cst);
    create_escape_file(&cst);
    exit(0);
}

static void init(int argc, char *argv[], struct param_lex_s *pls)
{
    memset(src_file, 0, FILENAME);
    memset(header_file, 0, FILENAME);
    memset(src_name, 0, FILENAME);
    memset(header_name, 0, FILENAME);
    memset(visit_file, 0, FILENAME);
    memset(visit_name, 0, FILENAME);
    memset(esc_name, 0, FILENAME);
    memset(esc_file, 0, FILENAME);
    if( argc==2 ) {
        strcpy(src_file, "ncpl_parser.c");
        strcpy(header_file, "ncpl_parser.h");
        strcpy(visit_file, "ncpl_visit.c");
        strcpy(src_name, "ncpl_parser.c");
        strcpy(header_name, "ncpl_parser.h");
        strcpy(visit_name, "ncpl_visit.c");
        strcpy(esc_file, "ncpl_esc.c");
        strcpy(esc_name, "ncpl_esc.c");
    } else if( argc==10 ) {
        sprintf(src_file, "%s/%s", argv[2], argv[3]);
        sprintf(header_file, "%s/%s", argv[4], argv[5]);
        sprintf(visit_file, "%s/%s", argv[6], argv[7]);
        sprintf(esc_file, "%s/%s", argv[8], argv[9]);
        strcpy(src_name, argv[3]);
        strcpy(header_name, argv[5]);
        strcpy(visit_name, argv[7]);
        strcpy(esc_name, argv[9]);
    } else {
        fprintf(stderr, "Parameter error. %s grammar-file [srcpath srcfile headerpathe headerfile visitpath visitfile escpath escfile]\n", argv[0]);
        exit(1);
    }
    strncpy(pls->file, argv[1], FILENAME);
    int fd;
    if( (fd = open(pls->file, O_RDONLY))<0 ) {
        fprintf(stderr, "Failed. %s\n", strerror(errno));
        exit(1);
    }
    pls->fd = fd;
    pls->len_buffer = 0;
    pls->len_token = LINELEN;
    pls->ch = -1;
}


/*@?  every line of grammar should be ended by '#'
 * 利用递归函数，在递归前将符号加入到CONSTRUCTOR结构中的双向链表中
 * 或者检测是否已存在，将该结构指针返保存。
 * 之后进行递归，直到获取字符类型为SEMIC，然后将总个数记录在RULE
 * 结构中的nr_right中，并分配内存给right。
 * 然后逐个函数返回，并将之前保存的指针逐个赋给right数组中的元素（指针）。
 * 注意，是倒序赋值。*/

/*
 * 0 - EOF 1 - again -1 - failed.
 */
static int build_rules(struct param_lex_s *pls, CONSTRUCTOR *cst)
{
    NCPL_LEX *lex = (cst->lex==NULL)?get_lex(pls, cst):cst->lex;
    if( lex->type==ENDFILE || lex->type==PERC ) {
        ignore = (lex->type==PERC)?1:0;
        if( !cst->nr_rule ) return 0;
        cst->rule_cnt = cst->nr_rule;
        if( !cst->rule_cnt ) {
            fprintf(stderr, "%s(): No rules in file '%s'.\n", __FUNCTION__, pls->file);
            return -1;
        }
        cst->rule = (RULE *)calloc(cst->rule_cnt, sizeof(RULE));
        assert(cst->rule);
        return 0;
    }
    CHARA *c = get_chara_node(lex, cst);
    if( c==NULL ) {
        TOKEN *t = create_token_node();
        t->lex = lex;
        t->is_terminal = 0;
        c = create_chara_node();
        c->token = t;
        add_chara_node(c, &(cst->c_head), &(cst->c_tail));
    } else {
        c->token->is_terminal = 0;
    }
    CHARA *left = c;
    lex = get_lex(pls, cst);
    if( lex->type!=COLON ) {
        fprintf(stderr, "%s(): %s:Line:%d Format error, lost ':'.\n", \
        __FUNCTION__, pls->file, lex->line);
        return -1;
    }
    RULE r;
    memset(&r, 0, sizeof(r));
    r.left = left;
    build_right_rule(pls, cst, &r);
    cst->nr_rule++;
    lex = get_lex(pls, cst);
    int ret = build_rules(pls, cst);
    if( ret<0 ) {
        return ret;
    }
    memcpy(&((cst->rule)[cst->rule_cnt-1]), &r, sizeof(RULE));
    cst->rule_cnt--;
    return 0;
}

static void build_right_rule(struct param_lex_s *pls, CONSTRUCTOR *cst, RULE *rule)
{
    NCPL_LEX *lex = get_lex(pls, cst);
    if( lex->type==SEMIC ) {
        rule->right_cnt = rule->nr_right;
        if( rule->nr_right ) {
            rule->right = (CHARA **)calloc(1, rule->nr_right*sizeof(CHARA **));
            assert(rule->right);
        } else {
            rule->left->is_nullable = 1;
        }
        return;
    }
    CHARA *c = get_chara_node(lex, cst);
    if( c==NULL ) {
        TOKEN *t = create_token_node();
        t->lex = lex;
        t->is_terminal = 1;
        c = create_chara_node();
        c->token = t;
        add_chara_node(c, &(cst->c_head), &(cst->c_tail));
    }
    rule->nr_right++;
    build_right_rule(pls, cst, rule);
    rule->right[rule->right_cnt-1] = c;
    rule->right_cnt--;
}

static void build_ignore_tbl(struct param_lex_s *pls, CONSTRUCTOR *cst)
{
    NCPL_LEX *lex = get_lex(pls, cst);
    if( lex->type==ENDFILE ) {
        if( !cst->nr_ign_lex ) return;
        cst->ign_lex = (NCPL_LEX *)calloc(cst->nr_ign_lex, sizeof(NCPL_LEX));
        assert(cst->ign_lex);
        return;
    }
    int cur_pos = cst->nr_ign_lex;
    cst->nr_ign_lex++;
    build_ignore_tbl(pls, cst);
    memcpy(&cst->ign_lex[cur_pos], lex, sizeof(NCPL_LEX));
}

static void calc_nullable(CONSTRUCTOR *cst)
{
    RULE *r, *rend;
    CHARA **c, **cend;
    int chg, null;
    while( 1 ) {
        chg = 0;
        rend = cst->rule + cst->nr_rule;
        for(r = cst->rule; r<rend; r++) {
            null = 1;
            if( r->left->token->is_terminal )
                continue;
            if( r->left->is_nullable )
                continue;
            cend = r->right + r->nr_right;
            for(c = r->right; c<cend; c++ ) {
                if( !((*c)->is_nullable) ) {
                    null = 0;
                }
            }
            if( null ) {
                r->left->is_nullable = 1;
                chg = 1;
            }
        }
        if( !chg )
            break;
    }
}

static void calc_first(CONSTRUCTOR *cst)
{
    RULE *r, *rend;
    CHARA **c, **cend, *scan;
    SET *s, *s2;
    int chg;
    for(scan = cst->c_head; scan!=NULL; scan = scan->next) {
        if( scan->token->is_terminal ) {
            s = create_set_node();
            s->c = scan;
            add_set_node(s, &(scan->first_head), &(scan->first_tail));
        }
    }
    while( 1 ) {
        chg = 0;
        rend = cst->rule + cst->nr_rule;
        for(r = cst->rule; r<rend; r++) {
            cend = r->right + r->nr_right;
            for(c = r->right; c<cend; c++) {
                for(s2 = (*c)->first_head; s2!=NULL; s2 = s2->next) {
                    s = get_set_node(s2->c, r->left->first_head);
                    if( s==NULL ) {
                        s = create_set_node();
                        s->c = s2->c;
                        add_set_node(s, &(r->left->first_head), &(r->left->first_tail));
                        chg = 1;
                    }
                }
                if( !((*c)->is_nullable) )
                    break;
            }
        }
        if( !chg )
            break;
    }
}

static int check_first(CONSTRUCTOR *cst)
{
    int failed = 0;
    CHARA *c;
    for(c = cst->c_head; c!=NULL; c = c->next) {
        if( c->token->is_terminal )
            continue;
        if( c->first_head==NULL ) {
            fprintf(stderr, "%s(): Nonterminal '%s' rule error. First Set is NULL.\n", \
            __FUNCTION__, c->token->lex->content);
            failed++;
        }
    }
    if( failed )
        return -1;
    return 0;
}

#define  FOLLOW_MARCO(); f = get_set_node(scan->c, c->follow_head);\
                        if( f==NULL ) {\
                            f = create_set_node();\
                            f->c = scan->c;\
                            add_set_node(f, &(c->follow_head), &(c->follow_tail));\
                            chg = 1;\
                        }
static void calc_follow(CONSTRUCTOR *cst)
{
    int null, chg, i, j;
    RULE *r, *rend;
    CHARA *c, *la;
    SET *scan, *f;
    while( 1 ) {
        chg = 0;
        rend = cst->rule + cst->nr_rule;
        for(r = cst->rule; r<rend; r++) {
            null = 1;
            for(i = r->nr_right - 1; i>=0; i--) {
                c = r->right[i];
                if( null && null==(r->nr_right - i) ) {
                    for(scan = r->left->follow_head; scan!=NULL; scan = scan->next) {
                        FOLLOW_MARCO();
                    }
                    for(j = 1; j<=null-1; j++) {
                        la = r->right[i+j];
                        for(scan = la->first_head; scan!=NULL; scan = scan->next) {
                            FOLLOW_MARCO();
                        }
                    }
                } else {
                    for(j = 1; j<=null+1; j++) {
                        la = r->right[i+j];
                        for(scan = la->first_head; scan!=NULL; scan = scan->next) {
                            FOLLOW_MARCO();
                        }
                    }
                }
                null = (c->is_nullable)?null+1:0;
            }
        }
        if( !chg )
            break;
    }
}

static void closure(STATUS *s, CONSTRUCTOR *cst)
{
    int chg, null;
    ITEM *it, *crt;
    SET *set, *laset;
    CHARA *c, *_c;
    RULE *r, *rend;
    while( 1 ) {
        chg = 0;
        for(it = s->i_head; it!=NULL; it = it->next) {
            if( it->rule==NULL ) continue;
            if( it->rule->nr_right==it->pos )
                continue;
            c = it->rule->right[it->pos];
            if( c->token->is_terminal )
                continue;
            for(r = cst->rule, rend = cst->rule + cst->nr_rule; r<rend; r++) {
                null = 0;
                if( r->left==c ) {
                    if( it->pos+1<it->rule->nr_right ) {
                        _c = it->rule->right[it->pos + 1];
                        for(set = _c->first_head; set!=NULL; set = set->next) {
                            if( check_rule_repeat(r, s, set->c) ) {
                                continue;
                            }
                            crt = create_item_node();
                            crt->pos = 0;
                            crt->rule = r;
                            laset = create_set_node();
                            laset->c = set->c;
                            add_set_node(laset, &(crt->la_head), &(crt->la_tail));
                            crt->input = it->input;
                            add_item_node(crt, &(s->i_head), &(s->i_tail));
                            chg = 1;
                        }
                    } else {
                        null = 1;
                    }
                    if( (null ||_c->is_nullable) && it->la_head!=NULL ) {
                        if( !check_rule_repeat(r, s, it->la_head->c) ) {
                            crt = create_item_node();
                            crt->pos = 0;
                            crt->rule = r;
                            if( it->la_head!=NULL ) {
                                laset = create_set_node();
                                laset->c = it->la_head->c;
                                add_set_node(laset, &(crt->la_head), &(crt->la_tail));
                            }
                            crt->input = it->input;
                            add_item_node(crt, &(s->i_head), &(s->i_tail));
                            chg = 1;
                        }
                    }
                }
            }
        }
        if( !chg )
            break;
    }
}

static void Goto(STATUS *s, CONSTRUCTOR *cst)
{
    if( s==NULL ) {
        s = create_status_node();
        s->id = (cst->status_id)++;
        ITEM *i = create_item_node();
        i->rule = &(cst->rule[0]);
        add_item_node(i, &(s->i_head), &(s->i_tail));
        add_status_node(s, &(cst->s_head), &(cst->s_tail));
        closure(s, cst);
    }
    CHARA *scan;
    ITEM *it, *crt;
    STATUS status, *cs;
    SET *laset;
    int match;
    for(scan = cst->c_head; scan!=NULL; scan = scan->next) {
        match = 0;
        memset(&status, 0, sizeof(status));
        for(it = s->i_head; it!=NULL; it = it->next) {
            if( it->rule->nr_right==it->pos )
                continue;
            if( it->rule->right[it->pos]==scan ) {
                match = 1;
                crt = create_item_node();
                crt->pos = it->pos + 1;
                crt->rule = it->rule;
                if( it->la_head!=NULL ) {
                    laset = create_set_node();
                    laset->c = it->la_head->c;
                    add_set_node(laset, &(crt->la_head), &(crt->la_tail));
                }
                crt->input = scan;
                it->read = scan;
                add_item_node(crt, &(status.i_head), &(status.i_tail));
            }
        }
        if( !match )
            continue;
        closure(&status, cst);
        cs = get_status_node(&status, cst);
        if( cs!=NULL ) {
            for(it = s->i_head; it!=NULL; it = it->next) {
                if( it->rule->nr_right==it->pos )
                    continue;
                if( it->rule->right[it->pos]==scan )
                    it->gotoi = cs->id;
            }
            clean_item_chain(&(status.i_head), &(status.i_tail));
            continue;
        }
        status.id = (cst->status_id)++;
        cs = create_status_node();
        memcpy(cs, &status, sizeof(status));
        add_status_node(cs, &(cst->s_head), &(cst->s_tail));
        for(it = s->i_head; it!=NULL; it = it->next) {
            if( it->rule->nr_right==it->pos )
                continue;
            if( it->rule->right[it->pos]==scan ) {
                it->gotoi = cs->id;
            }
        }
        Goto(cs, cst);
    }
}

/*components*/
static int isTerminal(CHARA *c, CONSTRUCTOR *cst)
{
    RULE *r, *rend = cst->rule + cst->nr_rule;
    for(r = cst->rule; r<rend; r++) {
        if( c==r->left )
            return 0;
    }
    return 1;
}

static int isIgnore(NCPL_LEX *lex, CONSTRUCTOR *cst)
{
    NCPL_LEX *l, *lend = cst->ign_lex + cst->nr_ign_lex;
    for(l = cst->ign_lex; l<lend; l++) {
        if( !strcmp(l->content, lex->content) )
            return 1;
    }
    return 0;
}

static STATUS *get_status_node(STATUS *s, CONSTRUCTOR *cst)
{
    STATUS *scan;
    ITEM *i1, *i2;
    int failed, sum_s = calc_items(s), sum_scan, cnt, max;
    for(scan = cst->s_head; scan!=NULL; scan = scan->next) {
        cnt = 0;
        sum_scan = calc_items(scan);
        max = (sum_s>sum_scan)?sum_s:sum_scan;
        failed = 0;
        for(i1 = s->i_head; i1!=NULL; i1 = i1->next) {
            for(i2 = scan->i_head; i2!=NULL; i2 = i2->next) {
                if( i1->rule==i2->rule && \
                    i1->pos==i2->pos && \
                    i1->la_head->c==i2->la_head->c && \
                    i1->input==i2->input )
                    break;
            }
            if( i2==NULL )
                failed++;
            else
                cnt++;
        }
        if( !failed && cnt==max )
            return scan;
    }
    return NULL;
}

static int calc_items(STATUS *s)
{
    ITEM *i;
    int cnt = 0;
    for(i = s->i_head; i!=NULL; i = i->next, cnt++)
        ;
    return cnt;
}

static int check_rule_repeat(RULE *r, STATUS *s, CHARA *la)
{
    ITEM *it;
    for(it = s->i_head; it!=NULL; it = it->next) {
        if( it->rule==r && it->pos==0 && it->la_head->c==la )
            return 1;
    }
    return 0;
}

static NCPL_LEX *get_lex(struct param_lex_s *pls, CONSTRUCTOR *cst)
{
    cst->lex = ncpl_token(pls);
    return cst->lex;
}

static CHARA *get_chara_node(NCPL_LEX *lex, CONSTRUCTOR *cst)
{
    CHARA *scan;
    for(scan = cst->c_head; scan!=NULL; scan = scan->next) {
        if( !strcmp(scan->token->lex->content, lex->content) && \
            scan->token->lex->type==lex->type )
        {
            return scan;
        }
    }
    return NULL;
}

static SET *get_set_node(CHARA *c, SET *set)
{
    for(; set!=NULL; set = set->next ) {
        if( set->c==c )
            return set;
    }
    return NULL;
}

static void print(CONSTRUCTOR *cst)
{
    RULE *r, *rend = cst->rule + cst->nr_rule;
    CHARA **c, **cend, *scan;
    SET *s;
    NCPL_LEX *l, *lend = cst->ign_lex + cst->nr_ign_lex;
    printf("IGNORE:");
    for(l = cst->ign_lex; l<lend; l++) {
        printf(" %s", l->content);
    }
    printf("\n\n");
    printf("NR_RULE:%d\n", cst->nr_rule);
    for(r = cst->rule; r<rend; r++) {
        printf("NR_RIGHT:%d ", r->nr_right);
        printf("left: [%s] %s ", r->left->token->lex->content, \
        (r->left->token->is_terminal)?"Terminal":"Not Terminal");
        for(c = r->right, cend = r->right + r->nr_right; c<cend; c++) {
            printf("    right:[%s]%s", (*c)->token->lex->content, \
            ((*c)->token->is_terminal)?"Terminal":"Not Terminal");
        }
        printf("\n");
    }
    printf("\nNULLABLE:\n");
    for(scan = cst->c_head; scan!=NULL; scan = scan->next) {
        printf("\t\t[%s] %s:", scan->token->lex->content, scan->is_nullable?"NULLABLE":"NON-NULLABLE");
        printf("\n");
    }
    printf("\nFIRST:\n");
    for(scan = cst->c_head; scan!=NULL; scan = scan->next) {
        printf("\t\t[%s] first:", scan->token->lex->content);
        for(s = scan->first_head; s!=NULL; s = s->next) {
            printf("   [%s]", s->c->token->lex->content);
        }
        printf("\n");
    }
    printf("\nFOLLOW:\n");
    for(scan = cst->c_head; scan!=NULL; scan = scan->next) {
        printf("\t\t[%s] follow:", scan->token->lex->content);
        for(s = scan->follow_head; s!=NULL; s = s->next) {
            printf("   [%s]", s->c->token->lex->content);
        }
        printf("\n");
    }
    printf("\nSTATUS:\n");
    STATUS *st, *stend;
    for(st = cst->status, stend = cst->status + cst->nr_status; st<stend; st++) {
        print_status(st);
        printf("\n");
    }
}

static void print_status(STATUS *s)
{
    STATUS *st = s; CHARA *rc; ITEM *itt;
    SET *la;
    int k;
    printf("STATUS:%d\n", st->id);
    printf("\n");
    printf("\tItems:\n");
    for(itt = st->i_head; itt!=NULL; itt = itt->next) {
        if( itt->rule==NULL ) continue;
        printf("\t\t%s ->", itt->rule->left->token->lex->content);
        if( !itt->rule->nr_right )
            printf(" .");
        for(k = 0; k<itt->rule->nr_right; k++) {
            rc = itt->rule->right[k];
            if( k==itt->pos )
                printf(" .");
            printf(" %s", rc->token->lex->content);
        }
        if( itt->pos!=0&&itt->pos==itt->rule->nr_right )
            printf(" .");
        if( itt->la_head!=NULL ) {
            printf("  \tLookAhead:");
            for(la = itt->la_head; la!=NULL; la = la->next) {
                printf(" %s", la->c->token->lex->content);
            }
        }
        printf("  \tNext status id: %d", itt->gotoi);
        if( itt->input!=NULL ) {
            printf("  \tInput: %s", itt->input->token->lex->content);
        }
        if( itt->read!=NULL ) {
            printf("  \tRead: %s", itt->read->token->lex->content);
        }
        printf("\n");
    }
}

static int statuscmp(STATUS *s1, STATUS *s2)
{
    ITEM *i1, *i2;
    int failed = 0, sum_s1 = calc_items(s1), \
        sum_s2 = calc_items(s2), cnt = 0;
    int max = (sum_s1>sum_s2)?sum_s1:sum_s2;
    for(i1 = s1->i_head; i1!=NULL; i1 = i1->next) {
        for(i2 = s2->i_head; i2!=NULL; i2 = i2->next) {
            if( itemcmp(i1, i2) )
                break;
        }
        if( i2==NULL )
            failed++;
        else
            cnt++;
    }
    if( !failed && cnt==max )
        return 1;
    return 0;
}

static int itemcmp(ITEM *i1, ITEM *i2)
{
    if( i1==NULL || i2==NULL )
        return 0;
    if( i1->rule==i2->rule && \
        i1->pos==i2->pos && \
        i1->input==i2->input )
        return 1;
    return 0;
}

static int lookaheadcmp(ITEM *i, CHARA *c)
{
    SET *s = i->la_head;
    for(; s!=NULL; s = s->next) {
        if( s->c==c )
            return 1;
    }
    return 0;
}

static void move_lookahead_item(ITEM *dest, ITEM *src)
{
    SET *s = src->la_head, *la;
    while( s!=NULL ) {
        la = s;
        s = s->next;
        del_set_node(la, &(src->la_head), &(src->la_tail));
        if( !lookaheadcmp(dest, la->c) )
            add_set_node(la, &(dest->la_head), &(dest->la_tail));
    }
}

static void move_lookahead(STATUS *dest, STATUS *src)
{
    ITEM *i1, *i2;
    for(i1 = dest->i_head; i1!=NULL; i1 = i1->next) {
        for(i2 = src->i_head; i2!=NULL; i2 = i2->next) {
            if( itemcmp(i1, i2) ) {
                move_lookahead_item(i1, i2);
            }
        }
    }
}

static void fix_goto_status(STATUS *status, int nr_status, int oldid, int newid)
{
    STATUS *s, *send;
    ITEM *it;
    for(s = status, send = status + nr_status; s<send; s++) {
        if( s->id<0 )
            continue;
        for(it = s->i_head; it!=NULL; it = it->next) {
            if( it->gotoi==oldid )
                it->gotoi = newid;
        }
    }
}

static void rebuild_status_tbl(STATUS *status, int nr_status, CONSTRUCTOR *cst)
{
    STATUS *s, *send;
    for(s = status, send = status + nr_status; s<send; s++) {
        if( s->id>=0 )
            (cst->nr_status)++;
    }
    cst->status = (STATUS *)calloc(cst->nr_status, sizeof(STATUS));
    assert(cst->status);
    int i = 0;
    for(s = status, send = status + nr_status; s<send; s++) {
        if( s->id<0 )
            continue;
        if( s->id!=i ) {
            fix_goto_status(status, nr_status, s->id, i);
            s->id = i;
        }
        memcpy(&(cst->status[i]), s, sizeof(STATUS));
        i++;
    }
}


static void build_lalr(CONSTRUCTOR *cst)
{
    STATUS *s, *send, *tmp;
    int nr_status = 0;
    for(s = cst->s_head; s!=NULL; s = s->next, nr_status++)
        ;
    tmp = (STATUS *)calloc(nr_status, sizeof(STATUS));
    assert(tmp);
    for(s = cst->s_head; s!=NULL; s = s->next) {
        memcpy(&(tmp[s->id]), s, sizeof(STATUS));
    }
    /*item compress*/
    ITEM *i1, *i2, *fr;
    SET *la;
    for(s = tmp, send = tmp + nr_status; s<send; s++) {
        for(i1 = s->i_head; i1!=NULL; i1 = i1->next ) {
            for(i2 = i1->next; i2!=NULL; ) {
                if( itemcmp(i1, i2) ) {
                    fr = i2;
                    i2 = i2->next;
                    la = fr->la_head;
                    del_set_node(la, &(fr->la_head), &(fr->la_tail));
                    add_set_node(la, &(i1->la_head), &(i1->la_tail));
                    del_item_node(fr, &(s->i_head), &(s->i_tail));
                    continue;
                }
                i2 = i2->next;
            }
        }
    }
    /*status compress*/
    STATUS *sc;
    for(s = tmp, send = tmp + nr_status; s<send; s++) {
        if( s->id<0 )
            continue;
        for(sc = s + 1; sc<send; sc++) {
            if( sc->id<0 )
                continue;
            if( statuscmp(s, sc) ) {
                move_lookahead(s, sc);
                fix_goto_status(tmp, nr_status, sc->id, s->id);
                sc->id = -1;
            }
        }
    }
    /*rebuild table*/
    rebuild_status_tbl(tmp, nr_status, cst);
    free(tmp);
}

static int check_lookahead_repeat(ITEM *i1, ITEM *i2)
{
    SET *s1, *s2;
    for(s1 = i1->la_head; s1!=NULL; s1 = s1->next) {
        for(s2 = i2->la_head; s2!=NULL; s2 = s2->next) {
            if( s1->c==s2->c )
                return 1;
        }
    }
    return 0;
}

static void check_conflicts(CONSTRUCTOR *cst)
{
    STATUS *s, *send = cst->status + cst->nr_status;
    ITEM *it, *chk;
    CHARA *c;
    SET *la;
    int failed = 0;
    for(s = cst->status; s<send; s++) {
        for(it = s->i_head; it!=NULL; it = it->next) {
            if( it->rule==NULL ) continue;
            if( it->pos==it->rule->nr_right ) { /*reduce-reduce*/
                for(chk = it->next; chk!=NULL; chk = chk->next) {
                    if( chk->pos==chk->rule->nr_right && check_lookahead_repeat(it, chk) ) {
                        fprintf(stderr, "ERROR %s(): RULE %ld and %ld  Reduce-Reduce conflict.\n",\
                        __FUNCTION__, it->rule - cst->rule, chk->rule - cst->rule); failed++;
                    }
                }
            } else { /*Shift-Shift*/
                c = it->rule->right[it->pos];
                for(chk = it->next; chk!=NULL; chk = chk->next) {
                    if( chk->pos!=chk->rule->nr_right ) {
                        if( chk->rule->right[chk->pos]==c ) {
                            fprintf(stderr, "ERROR %s(): Status:%d Shift-Shift conflict.\n", \
                            __FUNCTION__, s->id); failed++;
                        }
                    }
                }
            }
            for(chk = s->i_head; chk!=NULL; chk = chk->next) { /*Shift-Reduce*/
                if( chk==it ) continue;
                if( (it->pos==it->rule->nr_right)&&(chk->pos!=chk->rule->nr_right) ) {
                    c = chk->rule->right[chk->pos];
                    for(la = it->la_head; la!=NULL; la = la->next) {
                        if( la->c==c ) {
                            fprintf(stderr, "ERROR %s(): Status:%d Shift-Reduce conflict.\n", \
                            __FUNCTION__, s->id); failed++;
                        }
                    }
                } else if( (it->pos!=it->rule->nr_right)&&(chk->pos==chk->rule->nr_right) ) {
                    c = it->rule->right[it->pos];
                    for(la = chk->la_head; la!=NULL; la = la->next) {
                        if( la->c==c ) {
                            fprintf(stderr, "ERROR %s(): Status:%d Shift-Reduce conflict.\n", \
                            __FUNCTION__, s->id); failed++;
                        }
                    }
                }
            }
        }
    }
    if( failed )
        exit(1);
}






static void create_header_file(CONSTRUCTOR *cst)
{
    if( access(header_file, F_OK)>=0 ) {
        fprintf(stderr, "%s(): '%s' existed.\n", __FUNCTION__, header_file);
        return ;
    }
    FILE *fp = fopen(header_file, "w");
    if( fp==NULL ) {
        fprintf(stderr, "%s(): fopen error. %s\n", \
                     __FUNCTION__, strerror(errno));
        exit(1);
    }
    int max_la = 0, cnt;
    STATUS *s = cst->s_head;
    ITEM *it;
    SET *laset;
    for(; s!=NULL; s = s->next) {
        for(it = s->i_head; it!=NULL; it = it->next) {
            cnt = 0;
            for(laset = it->la_head; laset!=NULL; laset = laset->next, cnt++)
                ;
            max_la = (max_la<cnt)?cnt:max_la;
        }
    }
    fprintf(fp, \
"#ifndef __NCPL_PARSER_TBL_H\n\
#define __NCPL_PARSER_TBL_H\n\n\
#include \"ncpl_lex.h\"\n\
#include \"ncpl_env.h\"\n\
/*for ncpl_check_strfmt() to calc buffer size*/\n\
#define N_NUMLEN 32\n\
/*type*/\n\
#define PERROR 0\n\
#define PSHIFT 1\n\
#define PREDUCE 2\n\
#define PACCEPT 3\n\
/*struct type*/\n\
#define PCOMMON 0\n\n\
typedef struct {\n\
    int type;\n\
    int seq; /*status or rule sequence*/\n\
}NCPL_STATSW;\n\n");
    RULE *r, *rend = cst->rule + cst->nr_rule, *back;
    CHARA *left;
    int define_num = NRALL;
    int max_right = 0;
    for(r = cst->rule; r<rend; r++ ) {
        max_right = (r->nr_right>max_right)?r->nr_right:max_right;
        left = r->left;
        for(back = r-1; back>=cst->rule; back--) {
            if( back->left==left )
                break;
        }
        if( back>=cst->rule )
            continue;
        fprintf(fp, "#define %s %d\n", left->token->lex->content, define_num++);
        fprintf(fp, "typedef struct ncpl_%s_s NCPL_%s;\n", \
        left->token->lex->content, left->token->lex->content);
    }
    fprintf(fp, "\n\
typedef struct {\n\
    int left;\n\
    int nr_right;\n\
    int right[%d];\n\
}NCPL_RULE;\n", max_right);
    fprintf(fp, "\n\
typedef struct stack_s {\n\
    int type;\n\
    int in_status_no;\n\
    int cur_rule;\n\
    int rule_pos;\n\
    void *ptr;\n\
    struct stack_s *next;\n\
}STACK;\n");
    fprintf(fp, "\n\
/*for factor_type\n\
 * and it supports lex's type and this one*/\n\
#define EXPTYPE 0xffffffff");
    fprintf(fp, "\n\
typedef struct {\n\
    int type;\n\
    int factor_type;\n\
    char *factor_str;\n\
    NCPL_VALUE *val;\n\
}NCPL_RETVAL;\n");
    fprintf(fp, "\n\
typedef struct ncpl_fd {\n\
    int fd;\n\
    struct ncpl_fd *next;\n\
    struct ncpl_fd *prev;\n\
}NCPL_FD;\n\
\n#define FDHASH 512\n\
#define N_LOGSIZE 1024\n");
    fprintf(fp, "\n\
typedef struct {\n\
    int pass_tychk; /*the mark that pass or not procedure of type-check*/\n\
    int cur_status;\n\
    int is_define;\n\
    int ctlmark; /*for break and continue*/\n\
    int log_len;/*equal to N_LOGSIZE*/\n\
    char log[N_LOGSIZE];\n\
    NCPL_LEX *lookahead;\n\
    STACK *stack_top;\n\
    STACK *store;\n\
    niffic_pool_t *pool;\n\
    NCPL_%s *ptr;\n\
    struct param_lex_s pls;\n\
    NCPL_ENV env;\n\
    NCPL_FD *fdhash[FDHASH];\n\
}NCPL_PARSER;\n", cst->rule->left->token->lex->content);
    fprintf(fp, "\ntypedef int (*RFUNC)(NCPL_PARSER *);\n");
    fprintf(fp, "\n");
    build_struct(fp, cst);
    fprintf(fp, "\nextern int ncpl_parse(NCPL_PARSER *p);\n");
    fprintf(fp, "extern int ncpl_visit(NCPL_PARSER *);\n");
    fprintf(fp, "extern NCPL_FD *ncpl_new_fd(niffic_pool_t *pool, int fd);\n");
    fprintf(fp, "extern void ncpl_free_fd(NCPL_FD *f, int need_close);\n");
    fprintf(fp, "extern void ncpl_add_fd(NCPL_FD *f, NCPL_FD **tbl);\n");
    fprintf(fp, "extern void ncpl_del_fd(NCPL_FD *f, NCPL_FD **tbl);\n");
    fprintf(fp, "extern void ncpl_close_all_fd(NCPL_FD **tbl);\n");
    fprintf(fp, "extern NCPL_FD *ncpl_get_fd(int fd, NCPL_FD **tbl);\n");
    build_visit_declarations(fp, cst);
    fprintf(fp, "\n#endif\n\n");
    fclose(fp);
}

static void build_struct(FILE *fp, CONSTRUCTOR *cst)
{
    CHARA *left;
    RULE *r, *rend = cst->rule + cst->nr_rule, *back;
    RULE *rs, *rsend = cst->rule + cst->nr_rule;
    for(r = cst->rule; r<rend; r++ ) {
        left = r->left;
        for(back = r-1; back>=cst->rule; back--) {
            if( back->left==left && back->nr_right )
                break;
        }
        if( back>=cst->rule )
            continue;
        if( !r->nr_right )
            continue;
        fprintf(fp, "struct ncpl_%s_s {\n", left->token->lex->content);
        fprintf(fp, "    int type;\n");
        fprintf(fp, "    int line;\n");
        fprintf(fp, "    int retval;\n");
        fprintf(fp, "    union {\n");
        for(rs = cst->rule; rs<rsend; rs++) {
            if( rs->left==r->left && rs->nr_right && !rightcmp(rs, r) ) {
                fprintf(fp, "        struct {\n");
                build_struct_content(fp, rs, cst);
                fprintf(fp, "        }%s_%ld;\n", \
                rs->left->token->lex->content, rs-cst->rule);
            }
        }
        fprintf(fp ,"    }u;\n");
        fprintf(fp, "};\n\n");
    }
}

static int rightcmp(RULE *r1, RULE *r2)
{
    CHARA **c1, **c1end, **c2, **c2end;
    for(c1 = r1->right, c1end = r1->right + r1->nr_right, \
        c2 = r2->right, c2end = r2->right + r2->nr_right; \
        c1<c1end && c1<c2end; c1++, c2++)
    {
        if( (*c1)!=(*c2) )
            break;
    }
    if( c1!=NULL || c2!=NULL ) {
        return 0;
    }
    return 1;
}

static void build_struct_content(FILE *fp, RULE *r, CONSTRUCTOR *cst)
{
    CHARA **c, **cend = r->right + r->nr_right;
    RULE *rs, *rsend;
    for(c = r->right; c<cend; c++) {
        rsend = cst->rule + cst->nr_rule;
        for(rs = cst->rule; rs<rsend; rs++) {
            if( *c==rs->left )
                break;
        }
        if( rs>=rsend ) {
            if( !isIgnore((*c)->token->lex, cst) )
                fprintf(fp, "            NCPL_LEX *ncpl_%ld_%ld;\n", r - cst->rule, c - r->right);
        } else {
            fprintf(fp, "            NCPL_%s *ncpl_%ld_%ld;\n", (*c)->token->lex->content, r - cst->rule, c - r->right);
        }
    }
}

static void create_source_file(CONSTRUCTOR *cst)
{
    if( access(src_file, F_OK)>=0 ) {
        fprintf(stderr, "%s(): '%s' existed.\n", __FUNCTION__, src_file);
        return ;
    }
    FILE *fp = fopen(src_file, "w");
    if( fp==NULL ) {
        fprintf(stderr, "%s(): fopen error. %s\n", \
                     __FUNCTION__, strerror(errno));
        exit(1);
    }
    build_include(fp);
    PRINT_TITLE(fp, "rule_table");
    build_rule_tbl(fp, cst);
    PRINT_TITLE(fp, "status_switch_table");
    build_status_tbl(fp, cst);
    PRINT_TITLE(fp, "declarations");
    build_declaration(fp, cst);
    PRINT_TITLE(fp, "functions_table");
    build_func_tbl(fp, cst);
    PRINT_TITLE(fp, "stack");
    build_stack(fp);
    PRINT_TITLE(fp, "function_constructors");
    build_func_constructor(fp, cst);
    PRINT_TITLE(fp, "rule_functions");
    build_rule_functions(fp, cst);
    PRINT_TITLE(fp, "parse");
    build_parser(fp, cst);
    fclose(fp);
}

static void build_include(FILE *fp)
{
    fprintf(fp, "\
#include<stdio.h>\n\
#include<stdlib.h>\n\
#include<string.h>\n\
#include<assert.h>\n\
#include\"%s\"\n\n", header_name);
}

static void build_rule_tbl(FILE *fp, CONSTRUCTOR *cst)
{
    fprintf(fp, "NCPL_RULE rule_tbl[%d] = {\n", cst->nr_rule);
    RULE *r, *rend = cst->rule + cst->nr_rule;
    CHARA **c, **cend;
    for(r = cst->rule; r<rend; r++ ) {
        fprintf(fp, "{%s, %d, ", r->left->token->lex->content, r->nr_right);
        fprintf(fp, "{");
        cend = r->right + r->nr_right;
        for(c = r->right; c<cend; c++) {
            fprintf(fp, "%s", (*c)->token->lex->content);
            if( c+1<cend )
                fprintf(fp, ", ");
        }
        fprintf(fp, "}}");
        if( r+1<rend )
            fprintf(fp, ",");
        fprintf(fp, "\n");
    }
    fprintf(fp, "};\n\n");
}

static void build_status_tbl(FILE *fp, CONSTRUCTOR *cst)
{
    int define_num = NRALL;
    RULE *r, *rend = cst->rule + cst->nr_rule, *back;
    for(r = cst->rule; r<rend; r++ ) {
        for(back = r-1; back>=cst->rule; back--) {
            if( back->left==r->left )
                break;
        }
        if( back>=cst->rule )
            continue;
        define_num++;
    }
    fprintf(fp, "NCPL_STATSW stsw_tbl[%d][%d] = {\n", cst->nr_status, define_num);
    STATUS *s, *send = cst->status + cst->nr_status;
    for(s = cst->status; s<send; s++) {
        fprintf(fp, "{\n");
        build_status_item(fp, s, cst, define_num);
        fprintf(fp, "}\n");
        if( s+1<send )
            fprintf(fp, ",");
    }
    fprintf(fp, "};\n\n");
}

static void build_status_item(FILE *fp, STATUS *s, CONSTRUCTOR *cst, int num)
{
    int field_cnt = 0;
    int i, type, ch;
    ITEM *it;
    SET *la;
    for(field_cnt = 0, i = 0; i<num; i++) {
        type = PERROR;
        for(it = s->i_head; it!=NULL; it = it->next) {
            if( it->pos==it->rule->nr_right ) { /*Reduce, 
                                                  and the situation that pos behind ENDFILE
                                                  will be set PERROR.*/
                la = it->la_head;
                for(; la!=NULL; la = la->next) {
                    ch = map_atoi(la->c->token->lex->content, cst);
                    if( ch==i ) {
                        type = PREDUCE;
                        break;
                    }
                }
                if( la!=NULL )
                    break;
            } else { /*Pshift or Paccept*/
                ch = map_atoi((it->rule->right[it->pos])->token->lex->content, cst);
                if( i==ch ) {
                    type = (i==ENDFILE)?PACCEPT:PSHIFT;
                    break;
                }
            }
        }
        build_status_type(fp, s, it, cst, type);
        if( i+1<num )
            fprintf(fp, ",");
        if( ++field_cnt>=8 ) {
            fprintf(fp, "\n");
            field_cnt = 0;
        }
    }

}

static void build_status_type(FILE *fp, STATUS *s, ITEM *it, CONSTRUCTOR *cst, int type)
{
    int i;
    fprintf(fp, " {");
    switch( type ) {
        case PERROR:
            fprintf(fp, "PERROR, 0");
            break;
        case PSHIFT:
            fprintf(fp, "PSHIFT, %d ", it->gotoi);
            break;
        case PREDUCE:
            for(i = 0; i<cst->nr_rule; i++) {
                if( &(cst->rule[i])==it->rule )
                    break;
            }
            fprintf(fp, "PREDUCE, %d", i);
            break;
        case PACCEPT:
            fprintf(fp, "PACCEPT, 0");
            break;
        default:
            fprintf(stderr, "%s(): type error, value:%d.\n", __FUNCTION__, type);
            exit(1);
    }
    fprintf(fp, "}");
}

static int map_atoi(char *str, CONSTRUCTOR *cst)
{
    int i = ncpl_lex_atoi(str);
    if( i>=0 )
        return i;
    int define_num = NRALL;
    RULE *r, *rend, *back;
    rend = cst->rule + cst->nr_rule;
    for(r = cst->rule; r<rend; r++ ) {
        for(back = r-1; back>=cst->rule; back--) {
            if( back->left==r->left )
                break;
        }
        if( back>=cst->rule )
            continue;
        if( !strcmp(str, r->left->token->lex->content) )
            return define_num;
        define_num++;
    }
    return -1;
}

static void build_declaration(FILE *fp, CONSTRUCTOR *cst)
{
    RULE *r, *rend = cst->rule + cst->nr_rule;
    for(r = cst->rule; r<rend; r++) {
        fprintf(fp, "static int ncpl_%s_%ld(NCPL_PARSER *p);\n", \
        r->left->token->lex->content, r - cst->rule);
    }
    fprintf(fp, "\n");
}

static void build_func_tbl(FILE *fp, CONSTRUCTOR *cst)
{
    fprintf(fp, "\nRFUNC rfunc_tbl[%d] = {\n", cst->nr_rule);
    RULE *r, *rend = cst->rule + cst->nr_rule;
    int nr_col = 0;
    for(r = cst->rule; r<rend; r++) {
        fprintf(fp, "ncpl_%s_%ld", \
        r->left->token->lex->content, r - cst->rule);
        if( r+1<rend )
            fprintf(fp, ", ");
        if( ++nr_col==4 ) {
            fprintf(fp, "\n");
            nr_col = 0;
        }
    }
    fprintf(fp, "};\n\n");
}

static void build_stack(FILE *fp)
{
    fprintf(fp, \
"static STACK *create_stack_node(NCPL_PARSER *p, int type, void *ptr, int status_no)\n\
{\n\
    STACK *s = (STACK *)niffic_alloc(p->pool, sizeof(STACK));\n\
    assert(s);\n\
    s->type = type; s->ptr = ptr; s->in_status_no = status_no;\n\
    return s;\n\
}\n\n");
    fprintf(fp, \
"static void free_stack_node(NCPL_PARSER *p, STACK *s)\n\
{\n\
    niffic_free(s);\n\
}\n\n");
    fprintf(fp, \
"static void push(STACK *s, NCPL_PARSER *p)\n\
{\n\
    if( p->stack_top==NULL ) {\n\
        p->stack_top = s; return ;\n\
    }\n\
    s->next = p->stack_top;\n\
    p->stack_top = s;\n\
}\n\n");
    fprintf(fp, \
"static STACK *pop(NCPL_PARSER *p)\n\
{\n\
    if( p->stack_top==NULL )\n\
        return NULL;\n\
    STACK *s = p->stack_top;\n\
    p->stack_top = s->next;\n\
    p->cur_status = s->in_status_no;\n\
    s->next = NULL;\n\
    return s;\n\
}\n\n");
}

static void build_func_constructor(FILE *fp, CONSTRUCTOR *cst)
{
    RULE *r, *rend = cst->rule + cst->nr_rule;
    for(r = cst->rule; r<rend; r++) {
        if( !r->nr_right ) continue;
        fprintf(fp, "\nstatic NCPL_%s *ncpl_constructor_%s_%ld(NCPL_PARSER *p \\\n", \
        r->left->token->lex->content, r->left->token->lex->content, r - cst->rule);
        build_func_constructor_param(fp, r, cst);
        fprintf(fp, ")\n{\n");
        build_func_constructor_content(fp, r, cst);
        fprintf(fp, "}\n\n");
    }
}

static void build_func_constructor_param(FILE *fp, RULE *rule, CONSTRUCTOR *cst)
{
    CHARA **c, **cend = rule->right + rule->nr_right;
    for(c = rule->right; c<cend; c++) {
        if( isTerminal(*c, cst) ) {
            if( isIgnore((*c)->token->lex, cst) ) continue;
            fprintf(fp, ", NCPL_LEX *%s_%ld_ptr", \
            (*c)->token->lex->content, c - rule->right);
        } else {
            fprintf(fp, ", NCPL_%s *%s_%ld_ptr", \
            (*c)->token->lex->content, (*c)->token->lex->content, c - rule->right);
        }
    }
}

static void build_func_constructor_content(FILE *fp, RULE *rule, CONSTRUCTOR *cst)
{
    fprintf(fp, "    NCPL_%s *t = (NCPL_%s *)niffic_alloc(p->pool, sizeof(NCPL_%s));\n", \
    rule->left->token->lex->content, rule->left->token->lex->content, rule->left->token->lex->content);
    fprintf(fp, "    assert(t); t->type = %ld;\n", rule - cst->rule);
    CHARA **c, **cend = rule->right + rule->nr_right;
    for(c = rule->right; c<cend; c++) {
        if( isTerminal(*c, cst) && isIgnore((*c)->token->lex, cst) ) continue;
        fprintf(fp, "    t->u.%s_%ld.ncpl_%ld_%ld = %s_%ld_ptr;\n", \
        rule->left->token->lex->content, rule - cst->rule, rule - cst->rule, \
        c - rule->right, (*c)->token->lex->content, c - rule->right);
    }
    fprintf(fp, "    return t;\n");
}

static void build_rule_functions(FILE *fp, CONSTRUCTOR *cst)
{
    RULE *r, *rend = cst->rule + cst->nr_rule;
    for(r = cst->rule; r<rend; r++) {
        fprintf(fp, "static int ncpl_%s_%ld(NCPL_PARSER *p)\n{\n", \
        r->left->token->lex->content, r - cst->rule);
        if( !r->nr_right )
            build_rule_func_null(fp, r, cst);
        else {
            build_rule_func_content(fp, r, cst);
        }
        fprintf(fp, "}\n\n");
    }
}

static void build_rule_func_null(FILE *fp, RULE *rule, CONSTRUCTOR *cst)
{
    fprintf(fp, "    if( p->store!=NULL ) {push(p->store, p); p->store = NULL;}\n");
    fprintf(fp, "    int status = p->cur_status;\n");
    fprintf(fp, "    p->store = pop(p); if( p->store==NULL ) return -1;\n");
    fprintf(fp, "    p->cur_status = status;\n");
    fprintf(fp, "    STACK *new = create_stack_node(p, %s, NULL, p->cur_status);\n", \
                     rule->left->token->lex->content);
    fprintf(fp, "    push(new, p); return 0;\n");
}

static void build_rule_func_content(FILE *fp, RULE *rule, CONSTRUCTOR *cst)
{
    fprintf(fp, "    if( p->store!=NULL ) {push(p->store, p); p->store = NULL;}\n");
    fprintf(fp, "    p->store = pop(p); if( p->store==NULL ) return -1;\n");
    fprintf(fp, "    STACK *s;\n");
    CHARA **c = rule->right + rule->nr_right - 1, **cend;
    for(cend = rule->right; c>=cend; c--) {
        fprintf(fp, "    s = pop(p);");
        fprintf(fp, " if( s==NULL ) return -1;\n");
        if( isTerminal((*c), cst) ) {
            if( isIgnore((*c)->token->lex, cst) )
                fprintf(fp, "    ncpl_free_lex_node(s->ptr);");
            else
                fprintf(fp, "    NCPL_LEX *ncpl_%ld = s->ptr;", c - rule->right);
        } else {
            fprintf(fp, "    NCPL_%s *ncpl_%ld = s->ptr;", \
            (*c)->token->lex->content, c - rule->right);
        }
        fprintf(fp, " free_stack_node(p, s);\n");
    }
    fprintf(fp, "    NCPL_%s *t = ncpl_constructor_%s_%ld(p", \
    rule->left->token->lex->content, rule->left->token->lex->content, rule - cst->rule);
    c = rule->right;
    cend = rule->right + rule->nr_right;
    for(; c<cend; c++) {
        if( isTerminal((*c), cst) && isIgnore((*c)->token->lex, cst) ) continue;
        fprintf(fp, ", ncpl_%ld", c - rule->right);
    }
    fprintf(fp, ");\n");
    fprintf(fp, "    STACK *new = create_stack_node(p, %s, t, p->cur_status);\n", \
                     rule->left->token->lex->content);
    fprintf(fp, "    push(new, p); return 0;\n");
}

static void build_parser(FILE *fp, CONSTRUCTOR *cst)
{
    fprintf(fp, "int ncpl_parse(NCPL_PARSER *p)\n");
    fprintf(fp, "{\n");
    fprintf(fp, "    STACK *stack;\n");
    fprintf(fp, "    if( p->stack_top==NULL ) {\n");
    fprintf(fp, "        p->lookahead = ncpl_token(&(p->pls));\n");
    fprintf(fp, "        if( p->lookahead==NULL ) return -1;\n");
    fprintf(fp, "        stack = create_stack_node(p, p->lookahead->type, p->lookahead, p->cur_status);\n");
    fprintf(fp, "        push(stack, p);\n");
    fprintf(fp, "        p->lookahead = ncpl_token(&(p->pls));\n");
    fprintf(fp, "        if( p->lookahead==NULL ) return -1;\n");
    fprintf(fp, "    }\n");
    fprintf(fp, "    NCPL_STATSW *stw = &stsw_tbl[p->cur_status][p->stack_top->type];\n");
    fprintf(fp, "    if( stw->type==PERROR ) {\n");
    fprintf(fp, "        memset(p->log, 0, p->log_len);\n");
    fprintf(fp, "        snprintf(p->log, p->log_len, \"%%s:%%d Illegal symbol before '%%s', last type:%%d.\\n\", \\\n");
    fprintf(fp, "        p->pls.file, p->lookahead->line, (p->lookahead->type==ENDFILE)?\"end of file\":p->lookahead->content, p->stack_top->type);\n");
    fprintf(fp, "        return -1;\n");
    fprintf(fp, "    } else if( stw->type==PREDUCE ) {\n");
    fprintf(fp, "        if( rfunc_tbl[stw->seq](p)<0 ) return -1;\n");
    fprintf(fp, "    } else if( stw->type==PACCEPT ) {\n");
    fprintf(fp, "        p->ptr = (NCPL_%s *)niffic_alloc(p->pool, sizeof(NCPL_%s));\n", \
    cst->rule->left->token->lex->content, cst->rule->left->token->lex->content);
    fprintf(fp, "        STACK *stack, *eof = pop(p);");
    if( !isIgnore(((cst->rule->right)[cst->rule->nr_right - 1])->token->lex, cst) )
        fprintf(fp, "p->ptr->u.%s_0.ncpl_0_%d = eof->ptr;\n", \
        cst->rule->left->token->lex->content, cst->rule->nr_right - 1);
    fprintf(fp, "        free_stack_node(p, eof);\n");
    CHARA **c, **cend = cst->rule->right + cst->rule->nr_right - 2;
    for(c = cst->rule->right; cend>=c; cend--) {
        fprintf(fp, "        stack = pop(p); p->ptr->u.%s_0.ncpl_0_%ld = stack->ptr;\n", \
        cst->rule->left->token->lex->content, cend - cst->rule->right);
        fprintf(fp, "        free_stack_node(p, stack);\n");
    }
    fprintf(fp, "        return 1;\n");
    fprintf(fp, "    } else {\n");
    fprintf(fp, "        p->cur_status = stw->seq;\n");
    fprintf(fp, "        if( p->store!=NULL ) {p->store->in_status_no = p->cur_status; push(p->store, p); p->store = NULL;}\n");
    fprintf(fp, "        else {\n");   
    fprintf(fp, "            stack = create_stack_node(p, p->lookahead->type, p->lookahead, p->cur_status);\n");
    fprintf(fp, "            push(stack, p);\n");
    fprintf(fp, "            p->lookahead = ncpl_token(&(p->pls));\n");
    fprintf(fp, "            if( p->lookahead==NULL ) return -1;\n");
    fprintf(fp, "        }\n");
    fprintf(fp, "    }\n");
    fprintf(fp, "    return 0;\n");
    fprintf(fp, "}\n");
}

static void build_visit_declarations(FILE *fp, CONSTRUCTOR *cst)
{
    fprintf(fp, "extern NCPL_RETVAL *ncpl_lex_visit(NCPL_PARSER *, NCPL_LEX *);\n");
    RULE *r, *rend = cst->rule + cst->nr_rule, *back;
    for(r = cst->rule; r<rend; r++) {
        for(back = r - 1; back>=cst->rule; back--) {
            if( back->left==r->left ) break;
        }
        if( back>=cst->rule ) continue;
        fprintf(fp, "extern NCPL_RETVAL *ncpl_%s_visit(NCPL_PARSER *, NCPL_%s *);\n", \
        r->left->token->lex->content, r->left->token->lex->content);
    }
}

static void create_visit_file(CONSTRUCTOR *cst)
{
    if( access(visit_file, F_OK)>=0 ) {
        fprintf(stderr, "%s(): '%s' existed.\n", __FUNCTION__, visit_file);
        return ;
    }
    FILE *fp = fopen(visit_file, "w");
    if( fp==NULL ) {
        fprintf(stderr, "%s(): fopen error. %s\n", \
                     __FUNCTION__, strerror(errno));
        exit(1);
    }
    build_include(fp);
    fprintf(fp, "#include\"ncpl_tool.h\"\n");
    PRINT_TITLE(fp, "visit");
    build_visit(fp, cst);
    fclose(fp);
}

static void build_visit(FILE *fp, CONSTRUCTOR *cst)
{
    fprintf(fp, "\n\
static NCPL_RETVAL *ncpl_new_retval(NCPL_PARSER *p)\n\
{\n\
    NCPL_RETVAL *rv = (NCPL_RETVAL *)niffic_alloc(p->pool, sizeof(NCPL_RETVAL));\n\
    assert(rv); return rv;\n\
}\n");
    fprintf(fp, "\n\
static void ncpl_free_retval(NCPL_RETVAL *rv)\n\
{\n\
    niffic_free(rv);\n\
}\n\n");
    fprintf(fp, "NCPL_RETVAL *ncpl_lex_visit(NCPL_PARSER *p, NCPL_LEX *ptr)\n{\n");
    fprintf(fp, "    NCPL_RETVAL *rv = ncpl_new_retval(p);\n");
    fprintf(fp, "    if( ptr==NULL ) {rv->type = -1; return rv;}\n");
    fprintf(fp, "    printf(\"[%%s]\\n\", ptr->content);\n");
    fprintf(fp, "    rv->type = ptr->type; return rv;\n");
    fprintf(fp, "}\n\n");
    RULE *r, *rend = cst->rule + cst->nr_rule, *back;
    for(r = cst->rule; r<rend; r++) {
        for(back = r - 1; back>=cst->rule; back--) {
            if( back->left==r->left ) break;
        }
        if( back>=cst->rule ) continue;
        build_visit_nonterminal(fp, cst, r);
    }
    fprintf(fp, "int ncpl_visit(NCPL_PARSER *p)\n{\n");
    fprintf(fp, "    NCPL_RETVAL *rv = ncpl_%s_visit(p, p->ptr);\n", \
    cst->rule->left->token->lex->content);
    fprintf(fp, "    if( rv==NULL ) return -1; ncpl_free_retval(rv); return 0;\n}\n\n");
}

static void build_visit_nonterminal(FILE *fp, CONSTRUCTOR *cst, RULE *rule)
{
    fprintf(fp, "NCPL_RETVAL *ncpl_%s_visit(NCPL_PARSER *p, NCPL_%s *ptr)\n{\n",\
    rule->left->token->lex->content, rule->left->token->lex->content);
    fprintf(fp, "    NCPL_RETVAL *rv = ncpl_new_retval(p);\n");
    fprintf(fp, "    if( ptr==NULL ) { rv->type = -1; return rv;}\n");
    fprintf(fp, "    switch( ptr->type ) {\n");
    RULE *r, *rend = cst->rule + cst->nr_rule;
    for(r = cst->rule; r<rend; r++) {
        if( r->left==rule->left && r->nr_right ) {
            fprintf(fp, "        case %ld: {\n", r - cst->rule);
            build_visit_rule_right(fp, cst, r);
            fprintf(fp, "            break;\n        }\n");
        }
    }
    fprintf(fp, "        default: fprintf(stdout, \"%%s(): fatal error.\\n\", __FUNCTION__); exit(1);\n");
    fprintf(fp, "    }\n");
    fprintf(fp, "    return rv;\n");
    fprintf(fp, "}\n\n");
}

static void build_visit_rule_right(FILE *fp, CONSTRUCTOR *cst, RULE *rule)
{
    CHARA **c, **cend = rule->right + rule->nr_right;
    for(c = rule->right; c<cend; c++) {
        if( isTerminal(*c, cst) ) {
            if( isIgnore((*c)->token->lex, cst) ) continue;
            fprintf(fp, "            NCPL_RETVAL *rv_%ld_%ld = ncpl_lex_visit(p, ptr->u.%s_%ld.ncpl_%ld_%ld);\n", \
            rule - cst->rule, c - rule->right, rule->left->token->lex->content, \
            rule - cst->rule, rule - cst->rule, c - rule->right);
        } else {
            fprintf(fp, "            NCPL_RETVAL *rv_%ld_%ld = ncpl_%s_visit(p, ptr->u.%s_%ld.ncpl_%ld_%ld);\n", \
            rule - cst->rule, c - rule->right, (*c)->token->lex->content, \
            rule->left->token->lex->content, rule - cst->rule, rule - cst->rule, c - rule->right);
        }
        fprintf(fp, "            if( rv_%ld_%ld==NULL ) return NULL;\n", rule - cst->rule, c - rule->right);
        fprintf(fp, "            if( rv_%ld_%ld->type>=0 ) ptr->line = ptr->u.%s_%ld.ncpl_%ld_%ld->line;\n", \
        rule - cst->rule, c - rule->right, rule->left->token->lex->content, rule - cst->rule, \
        rule - cst->rule, c - rule->right);
        fprintf(fp, "            if( rv_%ld_%ld!=NULL ) ncpl_free_retval(rv_%ld_%ld);\n", 
        rule - cst->rule, c - rule->right, rule - cst->rule, c - rule->right);
    }
}

static void build_escape_declarations(FILE *fp, CONSTRUCTOR *cst)
{
    fprintf(fp, "static int ncpl_lex_escape(NCPL_PARSER *, NCPL_LEX *);\n");
    RULE *r, *rend = cst->rule + cst->nr_rule, *back;
    for(r = cst->rule; r<rend; r++) {
        for(back = r - 1; back>=cst->rule; back--) {
            if( back->left==r->left ) break;
        }
        if( back>=cst->rule ) continue;
        fprintf(fp, "static int ncpl_%s_escape(NCPL_PARSER *, NCPL_%s *);\n", \
        r->left->token->lex->content, r->left->token->lex->content);
    }
}

static void create_escape_file(CONSTRUCTOR *cst)
{
    if( access(esc_file, F_OK)>=0 ) {
        fprintf(stderr, "%s(): '%s' existed.\n", __FUNCTION__, esc_file);
        return ;
    }
    FILE *fp = fopen(esc_file, "w");
    if( fp==NULL ) {
        fprintf(stderr, "%s(): fopen error. %s\n", \
                     __FUNCTION__, strerror(errno));
        exit(1);
    }
    build_include(fp);
    build_escape_declarations(fp, cst);
    PRINT_TITLE(fp, "escape");
    build_escape(fp, cst);
    fclose(fp);
}

static void build_escape(FILE *fp, CONSTRUCTOR *cst)
{
    fprintf(fp, "static int ncpl_lex_escape(NCPL_PARSER *p, NCPL_LEX *ptr)\n{\n");
    fprintf(fp, "    if( ptr==NULL ) return 0;\n");
    fprintf(fp, "    printf(\"[%%s]\\n\", ptr->content);\n");
    fprintf(fp, "    return ptr->type;\n");
    fprintf(fp, "}\n\n");
    RULE *r, *rend = cst->rule + cst->nr_rule, *back;
    for(r = cst->rule; r<rend; r++) {
        for(back = r - 1; back>=cst->rule; back--) {
            if( back->left==r->left ) break;
        }
        if( back>=cst->rule ) continue;
        build_escape_nonterminal(fp, cst, r);
    }
    fprintf(fp, "int ncpl_findescape(NCPL_PARSER *p)\n{\n");
    fprintf(fp, "    return ncpl_%s_escape(p, p->ptr);\n}\n\n", \
    cst->rule->left->token->lex->content);
}

static void build_escape_nonterminal(FILE *fp, CONSTRUCTOR *cst, RULE *rule)
{
    fprintf(fp, "static int ncpl_%s_escape(NCPL_PARSER *p, NCPL_%s *ptr)\n{\n",\
    rule->left->token->lex->content, rule->left->token->lex->content);
    fprintf(fp, "    if( ptr==NULL ) return 0;\n");
    fprintf(fp, "    switch( ptr->type ) {\n");
    RULE *r, *rend = cst->rule + cst->nr_rule;
    for(r = cst->rule; r<rend; r++) {
        if( r->left==rule->left && r->nr_right ) {
            fprintf(fp, "        case %ld: {\n", r - cst->rule);
            build_escape_rule_right(fp, cst, r);
            fprintf(fp, "            break;\n        }\n");
        }
    }
    fprintf(fp, "        default: fprintf(stdout, \"%%s(): fatal error.\\n\", __FUNCTION__); exit(1);\n");
    fprintf(fp, "    }\n");
    fprintf(fp, "    return 0;\n");
    fprintf(fp, "}\n\n");
}

static void build_escape_rule_right(FILE *fp, CONSTRUCTOR *cst, RULE *rule)
{
    CHARA **c, **cend = rule->right + rule->nr_right;
    for(c = rule->right; c<cend; c++) {
        if( isTerminal(*c, cst) ) {
            if( isIgnore((*c)->token->lex, cst) ) continue;
            fprintf(fp, "            int type_%ld_%ld = ncpl_lex_escape(p, ptr->u.%s_%ld.ncpl_%ld_%ld);\n", \
            rule - cst->rule, c - rule->right, rule->left->token->lex->content, \
            rule - cst->rule, rule - cst->rule, c - rule->right);
        } else {
            fprintf(fp, "            int type_%ld_%ld = ncpl_%s_escape(p, ptr->u.%s_%ld.ncpl_%ld_%ld);\n", \
            rule - cst->rule, c - rule->right, (*c)->token->lex->content, \
            rule->left->token->lex->content, rule - cst->rule, rule - cst->rule, c - rule->right);
        }
        fprintf(fp, "            if( type_%ld_%ld<0 ) return -1;\n", rule - cst->rule, c - rule->right);
        fprintf(fp, "            if( type_%ld_%ld ) ptr->line = ptr->u.%s_%ld.ncpl_%ld_%ld->line;\n", \
        rule - cst->rule, c - rule->right, rule->left->token->lex->content, rule - cst->rule, \
        rule - cst->rule, c - rule->right);
    }
}

/*structures*/
    /*TOKEN*/
CREATE_NODE(TOKEN, create_token_node);
    /*SET*/
CREATE_NODE(SET, create_set_node);
ADD_NODE(SET, add_set_node);
DEL_NODE(SET, del_set_node);
    /*CHARA*/
CREATE_NODE(CHARA, create_chara_node);
ADD_NODE(CHARA, add_chara_node);
DEL_NODE(CHARA, del_chara_node);
    /*RULE*/
CREATE_NODE(RULE, create_rule_node);
    /*ITEM*/
ITEM *create_item_node(void)
{
    ITEM *i = (ITEM *)calloc(1, sizeof(ITEM));
    assert(i);
    i->gotoi = -1;
    return i;
}
ADD_NODE(ITEM, add_item_node);
DEL_NODE(ITEM, del_item_node);
CLEAN_CHAIN(ITEM, clean_item_chain);
    /*STATUS*/
CREATE_NODE(STATUS, create_status_node);
ADD_NODE(STATUS, add_status_node);
DEL_NODE(STATUS, del_status_node);

